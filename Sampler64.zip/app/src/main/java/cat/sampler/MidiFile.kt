package cat.sampler

import java.nio.ByteBuffer
import kotlin.math.min

/** Lector de fitxers MIDI estàndard (SMF 0/1). Retorna notes i controladors (sustain, all-notes-off) en frames a `sr`. */
object MidiFile {
    private class Raw(val tick: Long, val st: Int, val a: Int, val b: Int, val order: Int)

    fun parse(bytes: ByteArray, sr: Int): List<Ev> {
        val b = ByteBuffer.wrap(bytes)
        require(bytes.size >= 14 && b.getInt(0) == 0x4D546864) { "No és un fitxer MIDI" }        // 'MThd'
        val ntrks = b.getShort(10).toInt() and 0xFFFF
        val div = b.getShort(12).toInt() and 0xFFFF
        val smpte = (div and 0x8000) != 0
        val tps = if (smpte) (-(div shr 8).toByte().toInt()) * (div and 0xFF) else div            // ticks per segon (SMPTE) o per negra
        require(tps > 0) { "Divisió MIDI no vàlida" }

        val evs = ArrayList<Raw>()
        val tempos = ArrayList<Pair<Long, Int>>()
        var p = 14
        for (t in 0 until ntrks) {
            if (p + 8 > bytes.size) break
            val id = b.getInt(p); val len = b.getInt(p + 4); p += 8
            val end = min(bytes.size, p + len)
            if (id != 0x4D54726B) { p = end; continue }                                         // 'MTrk'
            var tick = 0L; var run = 0
            fun vlq(): Int {
                var v = 0
                while (p < end) { val x = bytes[p++].toInt() and 0xFF; v = (v shl 7) or (x and 0x7F); if (x and 0x80 == 0) break }
                return v
            }
            while (p < end) {
                tick += vlq()
                if (p >= end) break
                var s = bytes[p].toInt() and 0xFF
                if (s < 0x80) s = run else { p++; run = if (s < 0xF0) s else 0 }
                if (s == 0) break
                when {
                    s == 0xFF -> {
                        val type = bytes[p++].toInt() and 0xFF
                        val l = vlq()
                        if (type == 0x51 && l == 3 && p + 3 <= bytes.size)
                            tempos.add(tick to (((bytes[p].toInt() and 0xFF) shl 16) or ((bytes[p + 1].toInt() and 0xFF) shl 8) or (bytes[p + 2].toInt() and 0xFF)))
                        p += l
                    }
                    s == 0xF0 || s == 0xF7 -> { val l = vlq(); p += l }
                    else -> {
                        val hi = s and 0xF0
                        val a = bytes[p++].toInt() and 0x7F
                        val c = if (hi == 0xC0 || hi == 0xD0) 0 else bytes[p++].toInt() and 0x7F
                        if (hi == 0x80 || hi == 0x90 || hi == 0xB0) evs.add(Raw(tick, s, a, c, evs.size))
                    }
                }
            }
            p = end
        }

        // tick -> segons segons el mapa de tempos
        val segTick = ArrayList<Long>(); val segSec = ArrayList<Double>(); val segUs = ArrayList<Int>()
        segTick.add(0L); segSec.add(0.0); segUs.add(500000)
        var curTick = 0L; var curSec = 0.0; var cur = 500000
        for ((tk, us) in tempos.sortedBy { it.first }) {
            curSec += (tk - curTick) * cur / 1e6 / tps; curTick = tk; cur = us
            segTick.add(tk); segSec.add(curSec); segUs.add(us)
        }
        val sorted = evs.sortedWith(compareBy<Raw>({ it.tick }, { it.order }))
        val out = ArrayList<Ev>(sorted.size)
        var si = 0
        for (e in sorted) {
            while (si + 1 < segTick.size && segTick[si + 1] <= e.tick) si++
            val sec = if (smpte) e.tick.toDouble() / tps else segSec[si] + (e.tick - segTick[si]) * segUs[si] / 1e6 / tps
            out.add(Ev((sec * sr).toLong(), e.st, e.a, e.b))
        }
        return out
    }
}
