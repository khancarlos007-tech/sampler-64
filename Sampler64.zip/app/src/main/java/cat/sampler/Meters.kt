package cat.sampler

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import kotlin.math.min

/**
 * Vúmetre horitzontal. level = 0..1.
 * Mode normal: verd fins 0,80, groc fins 0,95 i vermell a partir d'aquí (marques a –12, –3 dB).
 * Mode gr = true (reducció del compressor): barra ambre.
 */
class MeterView(ctx: Context, private val label: String, private val gr: Boolean = false) : View(ctx) {
    var level = 0.0
    var text = ""
    var hot = false
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val r = RectF()

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(MeasureSpec.getSize(w), (30 * d).toInt())

    private fun bar(c: Canvas, x0: Float, x1: Float, y0: Float, y1: Float, col: Int) {
        if (x1 <= x0) return
        p.color = col; r.set(x0, y0, x1, y1); c.drawRoundRect(r, 3 * d, 3 * d, p)
    }

    override fun onDraw(c: Canvas) {
        val x0 = 52 * d; val x1 = width - 76 * d; val y0 = 5 * d; val y1 = height - 5 * d
        val w = x1 - x0; val lv = level.coerceIn(0.0, 1.0)
        p.style = Paint.Style.FILL
        bar(c, x0, x1, y0, y1, 0xFF0A0C10.toInt())
        if (gr) bar(c, x0, x0 + w * lv.toFloat(), y0, y1, 0xFFFFB020.toInt())
        else {
            bar(c, x0, x0 + w * min(lv, 0.80).toFloat(), y0, y1, 0xFF2ED573.toInt())
            if (lv > 0.80) bar(c, x0 + w * 0.80f, x0 + w * min(lv, 0.95).toFloat(), y0, y1, 0xFFFFD43B.toInt())
            if (lv > 0.95) bar(c, x0 + w * 0.95f, x0 + w * lv.toFloat(), y0, y1, 0xFFFF4D4F.toInt())
            p.color = 0x55FFFFFF; for (t in doubleArrayOf(0.5, 0.8, 0.95)) c.drawRect(x0 + w * t.toFloat() - 0.5f * d, y0, x0 + w * t.toFloat() + 0.5f * d, y1, p)
        }
        p.color = 0xFFB8C2D6.toInt(); p.textSize = 12 * d; p.isFakeBoldText = true
        c.drawText(label, 4 * d, y1 - 3 * d, p)
        p.color = if (hot) 0xFFFF4D4F.toInt() else 0xFFECEFF4.toInt(); p.textAlign = Paint.Align.RIGHT
        c.drawText(text, width - 4 * d, y1 - 3 * d, p)
        p.textAlign = Paint.Align.LEFT; p.isFakeBoldText = false
    }
}
