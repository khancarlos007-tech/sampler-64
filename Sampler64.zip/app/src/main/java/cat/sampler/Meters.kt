package cat.sampler

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View
import kotlin.math.min

/**
 * Vúmetre horitzontal. level = 0..1.
 * Mode normal (sortida): verd fins 0,80, groc fins 0,95 i vermell a partir d'aquí.
 * Mode gr = true (reducció del compressor): barra ambre.
 */
class MeterView(ctx: Context, private val label: String, private val gr: Boolean = false) : View(ctx) {
    var level = 0.0
    var text = ""
    var hot = false                      // text en vermell (CLIP)
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(MeasureSpec.getSize(w), (26 * d).toInt())

    override fun onDraw(c: Canvas) {
        val x0 = 58 * d
        val x1 = width - 84 * d
        val y0 = 4 * d
        val y1 = height - 4 * d
        val w = x1 - x0
        val lv = level.coerceIn(0.0, 1.0)
        p.style = Paint.Style.FILL
        p.color = 0xFF2A2A2A.toInt(); c.drawRect(x0, y0, x1, y1, p)
        if (gr) {
            p.color = 0xFFFFA000.toInt(); c.drawRect(x0, y0, x0 + w * lv.toFloat(), y1, p)
        } else {
            p.color = 0xFF2ECC40.toInt(); c.drawRect(x0, y0, x0 + w * min(lv, 0.80).toFloat(), y1, p)
            if (lv > 0.80) { p.color = 0xFFFFDC00.toInt(); c.drawRect(x0 + w * 0.80f, y0, x0 + w * min(lv, 0.95).toFloat(), y1, p) }
            if (lv > 0.95) { p.color = 0xFFFF4136.toInt(); c.drawRect(x0 + w * 0.95f, y0, x0 + w * lv.toFloat(), y1, p) }
        }
        p.color = 0xFFAAAAAA.toInt(); p.textSize = 12 * d
        c.drawText(label, 4 * d, y1 - 2 * d, p)
        p.color = if (hot) 0xFFFF4136.toInt() else 0xFFDDDDDD.toInt()
        p.textAlign = Paint.Align.RIGHT
        c.drawText(text, width - 4 * d, y1 - 2 * d, p)
        p.textAlign = Paint.Align.LEFT
    }
}
