package cat.sampler

import kotlin.math.*

/**
 * Processador de transients independent del nivell, amb saturació (estil Couture), per pista.
 *
 * Detecció: dos seguidors d'envolupant (ràpid i lent) sobre el senyal de detecció (Flat / Human / Sybil).
 * La relació ràpid/lent en dB és independent del nivell absolut:
 *   > 0 dB  = atac (transient)  -> guany = sharpen  * excés
 *   < 0 dB  = caiguda (cua)     -> guany = sustain  * 3 * defecte
 * El guany total es limita a -24..+12 dB.
 * Després, saturació opcional (BIT, RECT, FUZZ, SIN, BASS, TUBE) i guany de sortida. Tot en double.
 */
class TransientShaper(private val sr: Double) {
    @Volatile var on = false
    @Volatile var sharpen = 0.0      // -1..1  (atac: <0 suavitza, >0 accentua)
    @Volatile var sustain = 0.0      // -1..1  (cua: <0 l'acurta, >0 l'allarga)
    @Volatile var speed = 0.5        // 0..1   (velocitat del detector, ~0,2–4 ms)
    @Volatile var detect = 1         // 0 Flat, 1 Human, 2 Sybil
    @Volatile var drive = 0.0        // 0..1   (0 = saturació apagada)
    @Volatile var shape = 3          // 0 BIT, 1 RECT, 2 FUZZ, 3 SIN, 4 BASS, 5 TUBE
    @Volatile var outDb = 0.0

    private var fast = 0.0; private var slow = 0.0; private var gain = 1.0
    private var h1 = 0.0; private var h2 = 0.0; private var h3 = 0.0
    private val bassLp = DoubleArray(2); private val dcX = DoubleArray(2); private val dcY = DoubleArray(2)
    private var pre = 1.0; private var wet = 0.0; private var levels = 1.0; private var aB = 0.0
    private var shapeNow = 3
    private var dcR = 0.999
    private var tubeNorm = 1.0

    fun copyFrom(o: TransientShaper) {
        on = o.on; sharpen = o.sharpen; sustain = o.sustain; speed = o.speed; detect = o.detect
        drive = o.drive; shape = o.shape; outDb = o.outDb
    }

    private fun coef(fc: Double) = exp(-2 * PI * fc / sr)

    private fun sat(x: Double, c: Int): Double {
        val y = when (shapeNow) {
            0 -> Math.rint(x * levels) / levels
            1 -> { val m = 0.7 * drive; (1 - m) * x + m * abs(x) }
            2 -> sign(x) * (1 - exp(-3 * pre * abs(x))) / (1 - exp(-3 * pre))
            3 -> sin(max(-1.0, min(1.0, pre * x)) * PI / 2)
            4 -> { bassLp[c] += (1 - aB) * (x - bassLp[c]); x - bassLp[c] + 0.7 * tanh(pre * bassLp[c]) / tanh(pre) }
            else -> (tanh(pre * x + 0.3) - tanh(0.3)) / tubeNorm
        }
        val d = y - dcX[c] + dcR * dcY[c]            // bloqueig de contínua (~5 Hz)
        dcX[c] = y; dcY[c] = d
        return x + wet * (d - x)
    }

    fun process(l: DoubleArray, r: DoubleArray, n: Int) {
        if (!on) return
        val sh = sharpen; val su = sustain; val dr = drive
        val tf = 0.0002 * 10.0.pow(speed * 1.3)
        val cfa = exp(-1.0 / (tf * sr)); val cfr = exp(-1.0 / (4 * tf * sr))
        val csa = exp(-1.0 / (12 * tf * sr)); val csr = exp(-1.0 / (24 * tf * sr))
        val gc = 1 - exp(-1.0 / (0.0003 * sr))
        val aHp = coef(150.0); val aLp = coef(6000.0); val aS = coef(3000.0)
        val det = detect
        shapeNow = shape
        pre = 1 + dr * 15; wet = min(1.0, dr * 4); levels = 2.0.pow(15 - 12 * dr); aB = coef(200.0)
        dcR = exp(-2 * PI * 5.0 / sr)
        tubeNorm = max(abs(tanh(pre + 0.3) - tanh(0.3)), abs(tanh(-pre + 0.3) - tanh(0.3)))
        val og = 10.0.pow(outDb / 20)
        for (i in 0 until n) {
            val mid = 0.5 * (l[i] + r[i])
            val z = when (det) {
                0 -> mid
                1 -> { h1 += (1 - aHp) * (mid - h1); h2 += (1 - aLp) * ((mid - h1) - h2); h2 }
                else -> { h1 += (1 - aS) * (mid - h1); val y = mid - h1; h3 += (1 - aS) * (y - h3); y - h3 }
            }
            val e = abs(z)
            fast = if (e > fast) e + cfa * (fast - e) else e + cfr * (fast - e)
            slow = if (e > slow) e + csa * (slow - e) else e + csr * (slow - e)
            var gdb = 0.0
            if (slow > 1e-7) {
                val rdb = 20 * log10((fast + 1e-9) / (slow + 1e-9))
                gdb = (if (rdb > 0) sh * min(rdb, 18.0) else su * 3.0 * min(-rdb, 8.0)).coerceIn(-24.0, 12.0)
            }
            gain += (exp(gdb * 0.1151292546497023) - gain) * gc
            var x = l[i] * gain; var y = r[i] * gain
            if (dr > 0) { x = sat(x, 0); y = sat(y, 1) }
            l[i] = x * og; r[i] = y * og
        }
    }
}
