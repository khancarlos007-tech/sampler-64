package cat.sampler

import java.io.Closeable
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.floor
import kotlin.random.Random

private const val RIFF = 0x46464952
private const val WAVE = 0x45564157
private const val FMT = 0x20746d66
private const val FACT = 0x74636166
private const val DATA = 0x61746164

/** Mostra en 64 bits (doubles). Si és mono, r === l. */
class Sample(val l: DoubleArray, val r: DoubleArray, val rate: Int) {
    val size get() = l.size
}

object WavReader {
    /** Llegeix PCM 8/16/24/32 i IEEE float 32/64 (també WAVE_FORMAT_EXTENSIBLE). */
    fun read(bytes: ByteArray): Sample {
        val b = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        require(bytes.size > 44 && b.getInt(0) == RIFF && b.getInt(8) == WAVE) { "No és un WAV" }
        var p = 12; var tag = 1; var ch = 1; var rate = 44100; var bits = 16; var ds = -1; var dl = 0
        while (p + 8 <= bytes.size) {
            val id = b.getInt(p); val len = b.getInt(p + 4); val body = p + 8
            if (id == FMT) {
                tag = b.getShort(body).toInt() and 0xFFFF
                ch = b.getShort(body + 2).toInt()
                rate = b.getInt(body + 4)
                bits = b.getShort(body + 14).toInt()
                if (tag == 0xFFFE && len >= 26) tag = b.getShort(body + 24).toInt() and 0xFFFF
            } else if (id == DATA) {
                ds = body
                dl = minOf(len.toLong() and 0xFFFFFFFFL, (bytes.size - body).toLong()).toInt()
                break
            }
            p = body + len + (len and 1)
        }
        require(ds >= 0 && ch >= 1) { "WAV sense dades" }
        val bps = bits / 8
        val frames = dl / (bps * ch)
        val l = DoubleArray(frames)
        val r = if (ch > 1) DoubleArray(frames) else l
        for (f in 0 until frames) for (c in 0 until minOf(ch, 2)) {
            val o = ds + (f * ch + c) * bps
            val v = if (tag == 3) {
                if (bits == 64) b.getDouble(o) else b.getFloat(o).toDouble()
            } else when (bits) {
                8 -> ((b.get(o).toInt() and 255) - 128) / 128.0
                16 -> b.getShort(o) / 32768.0
                24 -> ((b.get(o + 2).toInt() shl 16) or ((b.get(o + 1).toInt() and 255) shl 8) or
                        (b.get(o).toInt() and 255)) / 8388608.0
                32 -> b.getInt(o) / 2147483648.0
                else -> error("Resolució no suportada: $bits")
            }
            if (c == 0) l[f] = v else r[f] = v
        }
        return Sample(l, r, rate)
    }
}

/** Escriu WAV estèreo: 16/24/32 enters (amb dither TPDF a ≤24) o float 32/64. */
class WavWriter(file: File, private val rate: Int, private val bits: Int, private val float: Boolean) : Closeable {
    private val raf = RandomAccessFile(file, "rw")
    private val bps = bits / 8
    private val hdr = if (float) 56 else 44
    private var frames = 0L
    private val buf = ByteBuffer.allocate(4096 * 2 * bps).order(ByteOrder.LITTLE_ENDIAN)
    private val scale = Math.pow(2.0, bits - 1.0)

    init { raf.setLength(0); raf.write(ByteArray(hdr)) }

    private fun put(v: Double) {
        if (buf.remaining() < bps) flush()
        if (float) { if (bits == 64) buf.putDouble(v) else buf.putFloat(v.toFloat()); return }
        var x = v * scale
        if (bits <= 24) x += Random.nextDouble() - Random.nextDouble()      // dither TPDF
        val q = floor(x + 0.5).coerceIn(-scale, scale - 1).toLong()
        when (bits) {
            16 -> buf.putShort(q.toShort())
            24 -> { buf.put(q.toByte()); buf.put((q shr 8).toByte()); buf.put((q shr 16).toByte()) }
            else -> buf.putInt(q.toInt())
        }
    }

    fun write(l: DoubleArray, r: DoubleArray, n: Int) {
        for (i in 0 until n) { put(l[i]); put(r[i]) }
        frames += n
    }

    private fun flush() { raf.write(buf.array(), 0, buf.position()); buf.clear() }

    override fun close() {
        flush()
        val data = frames * 2 * bps
        val h = ByteBuffer.allocate(hdr).order(ByteOrder.LITTLE_ENDIAN)
        h.putInt(RIFF).putInt((hdr - 8 + data).toInt()).putInt(WAVE)
        h.putInt(FMT).putInt(16).putShort(if (float) 3 else 1).putShort(2).putInt(rate)
            .putInt(rate * 2 * bps).putShort((2 * bps).toShort()).putShort(bits.toShort())
        if (float) h.putInt(FACT).putInt(4).putInt(frames.toInt())
        h.putInt(DATA).putInt(data.toInt())
        raf.seek(0); raf.write(h.array()); raf.close()
    }
}
