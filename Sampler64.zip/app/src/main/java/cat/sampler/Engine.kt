package cat.sampler

import java.io.File
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.math.*

/** Mapa de tecles: 7 octaves, C1..B7 (MIDI 24..107; C4 = 60). */
class SampleBank {
    class Zone(val s: Sample, val root: Int)
    val keys = arrayOfNulls<Zone>(128)

    companion object {
        const val LOW = 24
        const val HIGH = 107
        private val NOTE = Regex("(?:^|[_\\-\\s])([A-Ga-g])([#sb]?)[_\\-\\s]?(-?\\d)$")
        private val SEMI = mapOf('C' to 0, 'D' to 2, 'E' to 4, 'F' to 5, 'G' to 7, 'A' to 9, 'B' to 11)

        /** "C3", "piano_F#4", "Bb2", "Wav_A_5" o un número MIDI ("60"). */
        fun parseNote(file: String): Int? {
            val n = file.substringBeforeLast('.')
            n.toIntOrNull()?.let { return if (it in 0..127) it else null }
            val m = NOTE.find(n) ?: return null
            var s = SEMI[m.groupValues[1][0].uppercaseChar()]!!
            when (m.groupValues[2]) { "#", "s" -> s++; "b" -> s-- }
            return (m.groupValues[3].toInt() + 1) * 12 + s
        }
    }

    /** Si cap fitxer porta nota al nom, es reparteixen uniformement per ordre alfabètic. */
    fun build(files: List<Pair<String, Sample>>) {
        keys.fill(null)
        if (files.isEmpty()) return
        var roots = files.mapNotNull { (n, s) -> parseNote(n)?.let { it to s } }
        if (roots.isEmpty()) {
            val span = (HIGH - LOW + 1).toDouble() / files.size
            roots = files.sortedBy { it.first }.mapIndexed { i, f -> (LOW + (i + .5) * span).toInt() to f.second }
        }
        for (k in LOW..HIGH) {
            val z = roots.minByOrNull { abs(it.first - k) }!!
            keys[k] = Zone(z.second, z.first)
        }
    }
}

/**
 * Interpolador sinc de 16 punts (finestra de Kaiser β=9, 256 fases amb interpolació lineal entre fases).
 * Substitueix la interpolació cúbica (Hermite), que deformava les freqüències altes en reconvertir 44,1 → 48 kHz:
 * sobre la C4 real l'error global passa de –78 a –104 dB i a 10–16 kHz de –18 a –62 dB.
 */
object Sinc {
    const val TAPS = 16
    const val PH = 256
    private val tab = DoubleArray((PH + 1) * TAPS)

    init {
        val h = TAPS / 2; val beta = 9.0
        fun i0(x: Double): Double { var sum = 1.0; var t = 1.0; for (k in 1 until 40) { t *= (x / (2 * k)) * (x / (2 * k)); sum += t }; return sum }
        val i0b = i0(beta)
        for (p in 0..PH) {
            val fr = p.toDouble() / PH; var sum = 0.0
            for (k in 0 until TAPS) {
                val d = (k - h + 1) - fr
                val w = i0(beta * sqrt(max(0.0, 1 - (d / h) * (d / h)))) / i0b
                val sinc = if (abs(d) < 1e-12) 1.0 else sin(PI * d) / (PI * d)
                tab[p * TAPS + k] = sinc * w; sum += sinc * w
            }
            for (k in 0 until TAPS) tab[p * TAPS + k] /= sum
        }
    }

    /** Valor de x a la posició ip + f (f ∈ [0,1)); fora dels límits de la mostra = 0. */
    fun at(x: DoubleArray, ip: Int, f: Double): Double {
        val ph = f * PH; val p0 = ph.toInt(); val a = ph - p0
        val b0 = p0 * TAPS; val b1 = b0 + TAPS
        val s0 = ip - TAPS / 2 + 1
        var acc = 0.0
        if (s0 >= 0 && s0 + TAPS <= x.size) {
            for (k in 0 until TAPS) acc += (tab[b0 + k] + a * (tab[b1 + k] - tab[b0 + k])) * x[s0 + k]
        } else {
            for (k in 0 until TAPS) { val j = s0 + k; if (j >= 0 && j < x.size) acc += (tab[b0 + k] + a * (tab[b1 + k] - tab[b0 + k])) * x[j] }
        }
        return acc
    }
}

class Voice {
    var s: Sample? = null
    var pos = 0.0; var step = 0.0; var g = 0.0; var env = 1.0; var relK = 0.0
    var note = -1; var on = false; var rel = false; var held = false; var age = 0L

    fun start(s: Sample, ratio: Double, vel: Double, note: Int, age: Long, sr: Double) {
        this.s = s; pos = 0.0; step = ratio * s.rate / sr; g = vel; env = 1.0
        this.note = note; on = true; rel = false; held = false; this.age = age
    }

    fun release(sr: Double) { rel = true; relK = exp(-1.0 / (0.12 * sr)) }

    /** Còpia de l'estat d'una veu per fer-la desaparèixer amb un fade curt (3 ms) en lloc d'un tall sec. */
    fun ghostOf(o: Voice, sr: Double) {
        s = o.s; pos = o.pos; step = o.step; g = o.g; env = o.env; note = o.note; held = false; age = o.age
        on = true; rel = true; relK = exp(-1.0 / (0.003 * sr))
    }

    fun render(l: DoubleArray, r: DoubleArray, n: Int, gl: Double, gr: Double) {
        val s = s ?: return
        val mono = s.r === s.l
        for (i in 0 until n) {
            val ip = pos.toInt()
            if (ip >= s.size - 1 || env < 1e-4) { on = false; return }          // –80 dB: la veu allibera el forat abans
            val f = pos - ip
            val a = Sinc.at(s.l, ip, f)
            val b = if (mono) a else Sinc.at(s.r, ip, f)
            val k = g * env
            l[i] += a * k * gl; r[i] += b * k * gr
            pos += step
            if (rel) env *= relK
        }
    }
}

class Track(private val sr: Double) {
    @Volatile var bank = SampleBank()
    @Volatile var vol = 0.8
    @Volatile var pan = 0.0
    @Volatile var mute = false
    @Volatile var channel = 0          // canal MIDI 0..15 (mostrat com 1..16)
    val fx = TransientShaper(sr)             // processador de transients + saturació (insert de la pista)
    private val bl = DoubleArray(512)
    private val br = DoubleArray(512)
    private val voices = Array(32) { Voice() }
    private val ghosts = Array(8) { Voice() }
    private var clock = 0L
    private var sus = false
    @Volatile var steals = 0

    fun activeVoices(): Int { var c = 0; for (v in voices) if (v.on) c++; return c }

    /** Veu lliure; si no n'hi ha, roba la alliberada de menys nivell (o la més antiga) i en fa un fade curt. */
    private fun pick(): Voice {
        for (v in voices) if (!v.on) return v
        var best: Voice? = null
        for (c in voices) if (c.rel && (best == null || c.env * c.g < best.env * best.g)) best = c
        val v = best ?: voices.minByOrNull { it.age }!!
        steals++
        if (v.env * v.g > 0.002) for (gh in ghosts) if (!gh.on) { gh.ghostOf(v, sr); break }
        return v
    }

    fun noteOn(n: Int, vel: Int) {
        if (vel == 0) { noteOff(n); return }
        val z = bank.keys.getOrNull(n) ?: return
        pick().start(z.s, 2.0.pow((n - z.root) / 12.0), vel / 127.0, n, ++clock, sr)
    }

    fun noteOff(n: Int) {
        for (v in voices) if (v.on && v.note == n && !v.rel) if (sus) v.held = true else v.release(sr)
    }

    fun sustain(d: Boolean) {
        sus = d
        if (!d) for (v in voices) if (v.held) { v.held = false; if (v.on) v.release(sr) }
    }

    fun allOff() { for (v in voices) if (v.on) v.release(sr) }

    fun render(l: DoubleArray, r: DoubleArray, n: Int) {
        if (mute) return
        val a = (pan + 1) * PI / 4
        if (!fx.on) {                                   // camí directe (sense insert)
            val gl = cos(a) * vol; val gr = sin(a) * vol
            for (v in voices) if (v.on) v.render(l, r, n, gl, gr)
            for (v in ghosts) if (v.on) v.render(l, r, n, gl, gr)
            return
        }
        var off = 0                                     // amb insert: veus -> transients -> volum -> bus
        while (off < n) {
            val m = min(bl.size, n - off)
            bl.fill(0.0, 0, m); br.fill(0.0, 0, m)
            for (v in voices) if (v.on) v.render(bl, br, m, cos(a), sin(a))
            for (v in ghosts) if (v.on) v.render(bl, br, m, cos(a), sin(a))
            fx.process(bl, br, m)
            val vv = vol
            for (i in 0 until m) { l[off + i] += bl[i] * vv; r[off + i] += br[i] * vv }
            off += m
        }
    }
}

/**
 * Compressor tipus UREI 1176: ràtios 4/8/12/20 + "all buttons", llindar fix (l'Input
 * empeny el senyal), atac 20–800 µs, release 50–1100 ms amb release dependent del programa.
 * Detecció stereo-linked, tot en double.
 */
class Urei1176(private val sr: Double) {
    @Volatile var inputDb = 0.0
    @Volatile var outputDb = 0.0
    @Volatile var ratioIdx = 0       // 0..3 = 4,8,12,20 ; 4 = all buttons
    @Volatile var attackUs = 200.0
    @Volatile var releaseMs = 300.0
    @Volatile var bypass = false
    private var gr = 0.0
    @Volatile var grDb = 0.0          // reducció de guany màxima del darrer bloc (dB, ≥ 0), per al vúmetre
    private val ln10_20 = ln(10.0) / 20

    fun process(l: DoubleArray, r: DoubleArray, n: Int) {
        if (bypass) { grDb = 0.0; return }
        var maxGr = 0.0
        val all = ratioIdx == 4
        val ra = if (all) 20.0 else doubleArrayOf(4.0, 8.0, 12.0, 20.0)[ratioIdx]
        val knee = if (all) 1.5 else 6.0
        val thr = -18.0
        val ig = exp(inputDb * ln10_20); val og = exp(outputDb * ln10_20)
        val att = (if (all) attackUs * 0.5 else attackUs) * 1e-6
        for (i in 0 until n) {
            val x = l[i] * ig; val y = r[i] * ig
            val lvl = 20 * log10(max(max(abs(x), abs(y)), 1e-12))
            val over = lvl - thr
            val target = when {
                2 * over < -knee -> 0.0
                2 * abs(over) <= knee -> (1 - 1 / ra) * (over + knee / 2).pow(2) / (2 * knee)
                else -> (1 - 1 / ra) * over
            }
            val tau = if (target > gr) att else releaseMs * 1e-3 * (1 + gr / 10)
            val k = exp(-1.0 / (tau * sr))
            gr = target + k * (gr - target)
            if (gr > maxGr) maxGr = gr
            val g = exp(-gr * ln10_20) * og
            l[i] = x * g; r[i] = y * g
        }
        grDb = maxGr
    }
}

/**
 * Compressor optoelectrònic (estil T4/LA-2A). Detector RMS ~10 ms, genoll suau de 10 dB, 3:1 (compress) o 10:1 (limit).
 * La reducció té dues fases: una de ràpida (atac 10 ms, alliberament 60 ms) i una de lenta (atac 40 ms) l'alliberament
 * de la qual va de 0,4 a 4 s segons la "calor" de la cèl·lula (memòria de la compressió dels darrers ~5 s).
 * Estèreo enllaçat. `color` afegeix una saturació suau tipus vàlvula (transparent a nivells baixos).
 */
class OptoComp(private val sr: Double) {
    @Volatile var on = false
    @Volatile var peakRed = 0.5         // 0..1  (llindar = -36 dB · peakRed)
    @Volatile var gainDb = 0.0
    @Volatile var limit = false
    @Volatile var color = 0.0
    @Volatile var grDb = 0.0            // reducció màxima del darrer bloc (per al vúmetre)
    private var e = 0.0; private var gf = 0.0; private var gs = 0.0; private var heat = 0.0

    fun copyFrom(o: OptoComp) { on = o.on; peakRed = o.peakRed; gainDb = o.gainDb; limit = o.limit; color = o.color }

    fun process(l: DoubleArray, r: DoubleArray, n: Int) {
        if (!on) { grDb = 0.0; return }
        val thr = -peakRed * 36.0; val knee = 10.0; val ra = if (limit) 10.0 else 3.0
        val ce = exp(-1 / (0.010 * sr)); val crf = exp(-1 / (0.060 * sr)); val cas = exp(-1 / (0.040 * sr)); val ch = 1 / (5.0 * sr)
        val mk = 10.0.pow(gainDb / 20); val a = 1 + 1.5 * color
        var maxGr = 0.0
        for (i in 0 until n) {
            val x = max(abs(l[i]), abs(r[i])); e = x * x * (1 - ce) + ce * e
            val over = 10 * log10(e + 1e-12) - thr
            val tg = when {
                2 * over < -knee -> 0.0
                2 * abs(over) <= knee -> (1 - 1 / ra) * (over + knee / 2).pow(2) / (2 * knee)
                else -> (1 - 1 / ra) * over
            }
            val tf = 0.5 * tg; val ts = 0.5 * tg
            gf = tf + (if (tf > gf) ce else crf) * (gf - tf)
            val crs = exp(-1 / ((0.4 + 3.6 * heat) * sr))
            gs = ts + (if (ts > gs) cas else crs) * (gs - ts)
            val gr = gf + gs
            heat += (min(1.0, gr / 12.0) - heat) * ch
            if (gr > maxGr) maxGr = gr
            val g = exp(-gr * 0.1151292546497023) * mk
            var xl = l[i] * g; var xr = r[i] * g
            if (color > 0) { xl = tanh(a * xl) / a; xr = tanh(a * xr) / a }
            l[i] = xl; r[i] = xr
        }
        grDb = maxGr
    }
}

data class Ev(val frame: Long, val st: Int, val a: Int, val b: Int)

class Engine(val sr: Int) {
    companion object { const val TRACKS = 7 }

    val tracks = Array(TRACKS) { Track(sr.toDouble()) }
    val comp = Urei1176(sr.toDouble())
    val reverb = Reverb(sr)
    val opto = OptoComp(sr.toDouble())
    @Volatile var optoPos = 0             // 0 = abans de l'UREI, 1 = després
    @Volatile var peakL = 0.0         // pic de sortida des de l'última lectura (lineal, 1.0 = 0 dBFS)
    @Volatile var peakR = 0.0
    @Volatile var master = 1.0
    @Volatile var seq: ArrayList<Ev>? = null          // gravació d'esdeveniments MIDI
    @Volatile var seqStart = 0L
    @Volatile var frames = 0L
    private val q = ConcurrentLinkedQueue<IntArray>()

    // reproducció de seqüència (esdeveniments en frames a `sr`)
    @Volatile var playSeq: List<Ev> = emptyList()
    @Volatile var playCmd = 0                // 1 = engega, 2 = atura
    @Volatile var playing = false
    @Volatile var loop = false
    @Volatile var playFrame = 0L
    @Volatile var playStart = 0L             // frame des d'on s'engega la reproducció
    @Volatile var playEnd = Long.MAX_VALUE   // frame on s'atura (marcador OUT)
    @Volatile var loopStart = 0L             // on torna en mode bucle (marcador IN)
    private var playIdx = 0

    private fun firstAt(seq: List<Ev>, f: Long): Int {
        var lo = 0; var hi = seq.size
        while (lo < hi) { val m = (lo + hi) ushr 1; if (seq[m].frame < f) lo = m + 1 else hi = m }
        return lo
    }

    private fun advanceSeq(n: Int) {
        when (playCmd) {
            1 -> { for (t in tracks) t.allOff(); playIdx = firstAt(playSeq, playStart); playFrame = playStart; playing = playSeq.isNotEmpty(); playCmd = 0 }
            2 -> { playing = false; playCmd = 0; for (t in tracks) t.allOff() }
        }
        if (!playing) return
        val seq = playSeq
        val end = playFrame + n
        val lim = min(end, playEnd)
        while (playIdx < seq.size && seq[playIdx].frame < lim) { val e = seq[playIdx++]; dispatch(e.st, e.a, e.b) }
        playFrame = end
        if (playFrame >= playEnd || (playIdx >= seq.size && playEnd == Long.MAX_VALUE)) {
            for (t in tracks) t.allOff()
            if (loop) { playIdx = firstAt(seq, loopStart); playFrame = loopStart } else playing = false
        }
    }

    init { tracks.forEachIndexed { i, t -> t.channel = i } }

    /** Cada pista escolta el seu canal MIDI (per defecte pista n = canal n). Es pot cridar des de qualsevol fil. */
    fun midi(st: Int, a: Int, b: Int) { q.add(intArrayOf(st, a, b)) }

    fun dispatch(st: Int, a: Int, b: Int) {
        val ch = st and 15
        for (t in tracks) if (t.channel == ch) when (st and 0xF0) {
            0x90 -> t.noteOn(a, b)
            0x80 -> t.noteOff(a)
            0xB0 -> if (a == 64) t.sustain(b >= 64) else if (a == 123 || a == 120) t.allOff()
        }
    }

    /** Mesclador: suma les 7 pistes → compressor 1176 → master. Tot en double. */
    fun mix(l: DoubleArray, r: DoubleArray, n: Int) {
        l.fill(0.0, 0, n); r.fill(0.0, 0, n)
        for (t in tracks) t.render(l, r, n)
        reverb.process(l, r, n)
        if (optoPos == 0) opto.process(l, r, n)
        comp.process(l, r, n)
        if (optoPos == 1) opto.process(l, r, n)
        val m = master
        var pl = 0.0; var pr = 0.0
        for (i in 0 until n) {
            l[i] *= m; r[i] *= m
            val a = abs(l[i]); if (a > pl) pl = a
            val b = abs(r[i]); if (b > pr) pr = b
        }
        if (pl > peakL) peakL = pl
        if (pr > peakR) peakR = pr
        frames += n
    }

    fun render(l: DoubleArray, r: DoubleArray, n: Int) {
        while (true) {
            val e = q.poll() ?: break
            dispatch(e[0], e[1], e[2])
            seq?.add(Ev(frames - seqStart, e[0], e[1], e[2]))
        }
        advanceSeq(n)
        mix(l, r, n)
    }

    /** Llegeix i reinicia els pics de sortida (per al vúmetre). */
    fun activeVoices(): Int { var c = 0; for (t in tracks) c += t.activeVoices(); return c }
    fun steals(): Int { var c = 0; for (t in tracks) c += t.steals; return c }
    fun resetSteals() { for (t in tracks) t.steals = 0 }

    fun takePeaks(): DoubleArray { val a = doubleArrayOf(peakL, peakR); peakL = 0.0; peakR = 0.0; return a }

    fun cloneFor(newSr: Int): Engine {
        val e = Engine(newSr)
        for (i in 0 until TRACKS) e.tracks[i].let { t -> val s = tracks[i]; t.channel = s.channel; t.fx.copyFrom(s.fx); t.bank = s.bank; t.vol = s.vol; t.pan = s.pan; t.mute = s.mute }
        e.comp.inputDb = comp.inputDb; e.comp.outputDb = comp.outputDb; e.comp.ratioIdx = comp.ratioIdx
        e.comp.attackUs = comp.attackUs; e.comp.releaseMs = comp.releaseMs; e.comp.bypass = comp.bypass
        e.master = master
        e.reverb.mix = reverb.mix; e.reverb.enabled = reverb.enabled
        e.opto.copyFrom(opto); e.optoPos = optoPos
        reverb.raw?.let { e.reverb.load(it) }          // reconstrueix l'IR a la freqüència del render
        return e
    }
}

/** Renderitzat offline (més ràpid que temps real) a qualsevol freqüència i resolució. */
object Renderer {
    /** Renderitza la música (7 pistes + reverb + compressor, tot en double) a memòria, a la freqüència del motor. */
    fun renderBuffers(src: Engine, events: List<Ev>, frames: Int, progress: (Double) -> Unit, into: Array<DoubleArray>? = null): Array<DoubleArray> {
        val e = src.cloneFor(src.sr)
        val evs = events.sortedBy { it.frame }
        val outL = into?.get(0) ?: DoubleArray(frames); val outR = into?.get(1) ?: DoubleArray(frames)
        val b = 512; val l = DoubleArray(b); val r = DoubleArray(b)
        var pos = 0; var i = 0
        while (pos < frames) {
            while (i < evs.size && evs[i].frame <= pos) { e.dispatch(evs[i].st, evs[i].a, evs[i].b); i++ }
            var n = min(b, frames - pos)
            if (i < evs.size) n = min(n, (evs[i].frame - pos).toInt())
            e.mix(l, r, n)
            System.arraycopy(l, 0, outL, pos, n); System.arraycopy(r, 0, outR, pos, n)
            pos += n
            if ((pos / b) % 64 == 0) progress(pos.toDouble() / frames)
        }
        return arrayOf(outL, outR)
    }

    fun render(src: Engine, events: List<Ev>, outRate: Int, file: File, bits: Int, float: Boolean,
               tailSec: Double, progress: (Double) -> Unit) {
        val e = src.cloneFor(outRate)
        val k = outRate.toDouble() / src.sr
        val evs = events.map { it.copy(frame = (it.frame * k).toLong()) }.sortedBy { it.frame }
        val total = (evs.lastOrNull()?.frame ?: 0L) + (tailSec * outRate).toLong()
        val B = 512
        val l = DoubleArray(B); val r = DoubleArray(B)
        WavWriter(file, outRate, bits, float).use { w ->
            var pos = 0L; var i = 0
            while (pos < total) {
                while (i < evs.size && evs[i].frame <= pos) { e.dispatch(evs[i].st, evs[i].a, evs[i].b); i++ }
                var n = min(B.toLong(), total - pos)
                if (i < evs.size) n = min(n, evs[i].frame - pos)
                e.mix(l, r, n.toInt())
                w.write(l, r, n.toInt())
                pos += n
                progress(pos.toDouble() / total)
            }
        }
    }
}
