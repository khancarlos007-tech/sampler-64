package cat.sampler

import java.io.File
import java.util.concurrent.ConcurrentLinkedQueue
import kotlin.math.*

/** Mapa de tecles: 7 octaves, C1..B7 (MIDI 24..107; C4 = 60). */
class SampleBank {
    class Zone(val s: Sample, val root: Int)
    val keys = arrayOfNulls<Zone>(128)

    companion object {
        const val LOW = 24
        const val HIGH = 107
        private val NOTE = Regex("(?:^|[_\\-\\s])([A-Ga-g])([#sb]?)[_\\-\\s]?(-?\\d)$")
        private val SEMI = mapOf('C' to 0, 'D' to 2, 'E' to 4, 'F' to 5, 'G' to 7, 'A' to 9, 'B' to 11)

        /** "C3", "piano_F#4", "Bb2", "Wav_A_5" o un número MIDI ("60"). */
        fun parseNote(file: String): Int? {
            val n = file.substringBeforeLast('.')
            n.toIntOrNull()?.let { return if (it in 0..127) it else null }
            val m = NOTE.find(n) ?: return null
            var s = SEMI[m.groupValues[1][0].uppercaseChar()]!!
            when (m.groupValues[2]) { "#", "s" -> s++; "b" -> s-- }
            return (m.groupValues[3].toInt() + 1) * 12 + s
        }
    }

    /** Si cap fitxer porta nota al nom, es reparteixen uniformement per ordre alfabètic. */
    fun build(files: List<Pair<String, Sample>>) {
        keys.fill(null)
        if (files.isEmpty()) return
        var roots = files.mapNotNull { (n, s) -> parseNote(n)?.let { it to s } }
        if (roots.isEmpty()) {
            val span = (HIGH - LOW + 1).toDouble() / files.size
            roots = files.sortedBy { it.first }.mapIndexed { i, f -> (LOW + (i + .5) * span).toInt() to f.second }
        }
        for (k in LOW..HIGH) {
            val z = roots.minByOrNull { abs(it.first - k) }!!
            keys[k] = Zone(z.second, z.first)
        }
    }
}

class Voice {
    var s: Sample? = null
    var pos = 0.0; var step = 0.0; var g = 0.0; var env = 1.0; var relK = 0.0
    var note = -1; var on = false; var rel = false; var held = false; var age = 0L

    fun start(s: Sample, ratio: Double, vel: Double, note: Int, age: Long, sr: Double) {
        this.s = s; pos = 0.0; step = ratio * s.rate / sr; g = vel; env = 1.0
        this.note = note; on = true; rel = false; held = false; this.age = age
    }

    fun release(sr: Double) { rel = true; relK = exp(-1.0 / (0.12 * sr)) }

    private fun herm(x: DoubleArray, i: Int, f: Double): Double {
        val n = x.size
        val y0 = x[max(i - 1, 0)]; val y1 = x[i]; val y2 = x[min(i + 1, n - 1)]; val y3 = x[min(i + 2, n - 1)]
        val c1 = .5 * (y2 - y0); val c2 = y0 - 2.5 * y1 + 2 * y2 - .5 * y3; val c3 = .5 * (y3 - y0) + 1.5 * (y1 - y2)
        return ((c3 * f + c2) * f + c1) * f + y1
    }

    fun render(l: DoubleArray, r: DoubleArray, n: Int, gl: Double, gr: Double) {
        val s = s ?: return
        val mono = s.r === s.l
        for (i in 0 until n) {
            val ip = pos.toInt()
            if (ip >= s.size - 1 || env < 1e-6) { on = false; return }
            val f = pos - ip
            val a = herm(s.l, ip, f)
            val b = if (mono) a else herm(s.r, ip, f)
            val k = g * env
            l[i] += a * k * gl; r[i] += b * k * gr
            pos += step
            if (rel) env *= relK
        }
    }
}

class Track(private val sr: Double) {
    @Volatile var bank = SampleBank()
    @Volatile var vol = 0.8
    @Volatile var pan = 0.0
    @Volatile var mute = false
    @Volatile var channel = 0          // canal MIDI 0..15 (mostrat com 1..16)
    val fx = TransientShaper(sr)             // processador de transients + saturació (insert de la pista)
    private val bl = DoubleArray(512)
    private val br = DoubleArray(512)
    private val voices = Array(16) { Voice() }
    private var clock = 0L
    private var sus = false

    fun noteOn(n: Int, vel: Int) {
        if (vel == 0) { noteOff(n); return }
        val z = bank.keys.getOrNull(n) ?: return
        val v = voices.firstOrNull { !it.on } ?: voices.minByOrNull { it.age }!!
        v.start(z.s, 2.0.pow((n - z.root) / 12.0), vel / 127.0, n, ++clock, sr)
    }

    fun noteOff(n: Int) {
        for (v in voices) if (v.on && v.note == n && !v.rel) if (sus) v.held = true else v.release(sr)
    }

    fun sustain(d: Boolean) {
        sus = d
        if (!d) for (v in voices) if (v.held) { v.held = false; if (v.on) v.release(sr) }
    }

    fun allOff() { for (v in voices) if (v.on) v.release(sr) }

    fun render(l: DoubleArray, r: DoubleArray, n: Int) {
        if (mute) return
        val a = (pan + 1) * PI / 4
        if (!fx.on) {                                   // camí directe (sense insert)
            val gl = cos(a) * vol; val gr = sin(a) * vol
            for (v in voices) if (v.on) v.render(l, r, n, gl, gr)
            return
        }
        var off = 0                                     // amb insert: veus -> transients -> volum -> bus
        while (off < n) {
            val m = min(bl.size, n - off)
            bl.fill(0.0, 0, m); br.fill(0.0, 0, m)
            for (v in voices) if (v.on) v.render(bl, br, m, cos(a), sin(a))
            fx.process(bl, br, m)
            val vv = vol
            for (i in 0 until m) { l[off + i] += bl[i] * vv; r[off + i] += br[i] * vv }
            off += m
        }
    }
}

/**
 * Compressor tipus UREI 1176: ràtios 4/8/12/20 + "all buttons", llindar fix (l'Input
 * empeny el senyal), atac 20–800 µs, release 50–1100 ms amb release dependent del programa.
 * Detecció stereo-linked, tot en double.
 */
class Urei1176(private val sr: Double) {
    @Volatile var inputDb = 0.0
    @Volatile var outputDb = 0.0
    @Volatile var ratioIdx = 0       // 0..3 = 4,8,12,20 ; 4 = all buttons
    @Volatile var attackUs = 200.0
    @Volatile var releaseMs = 300.0
    @Volatile var bypass = false
    private var gr = 0.0
    @Volatile var grDb = 0.0          // reducció de guany màxima del darrer bloc (dB, ≥ 0), per al vúmetre
    private val ln10_20 = ln(10.0) / 20

    fun process(l: DoubleArray, r: DoubleArray, n: Int) {
        if (bypass) { grDb = 0.0; return }
        var maxGr = 0.0
        val all = ratioIdx == 4
        val ra = if (all) 20.0 else doubleArrayOf(4.0, 8.0, 12.0, 20.0)[ratioIdx]
        val knee = if (all) 1.5 else 6.0
        val thr = -18.0
        val ig = exp(inputDb * ln10_20); val og = exp(outputDb * ln10_20)
        val att = (if (all) attackUs * 0.5 else attackUs) * 1e-6
        for (i in 0 until n) {
            val x = l[i] * ig; val y = r[i] * ig
            val lvl = 20 * log10(max(max(abs(x), abs(y)), 1e-12))
            val over = lvl - thr
            val target = when {
                2 * over < -knee -> 0.0
                2 * abs(over) <= knee -> (1 - 1 / ra) * (over + knee / 2).pow(2) / (2 * knee)
                else -> (1 - 1 / ra) * over
            }
            val tau = if (target > gr) att else releaseMs * 1e-3 * (1 + gr / 10)
            val k = exp(-1.0 / (tau * sr))
            gr = target + k * (gr - target)
            if (gr > maxGr) maxGr = gr
            val g = exp(-gr * ln10_20) * og
            l[i] = x * g; r[i] = y * g
        }
        grDb = maxGr
    }
}

data class Ev(val frame: Long, val st: Int, val a: Int, val b: Int)

class Engine(val sr: Int) {
    companion object { const val TRACKS = 7 }

    val tracks = Array(TRACKS) { Track(sr.toDouble()) }
    val comp = Urei1176(sr.toDouble())
    val reverb = Reverb(sr)
    @Volatile var peakL = 0.0         // pic de sortida des de l'última lectura (lineal, 1.0 = 0 dBFS)
    @Volatile var peakR = 0.0
    @Volatile var master = 1.0
    @Volatile var seq: ArrayList<Ev>? = null          // gravació d'esdeveniments MIDI
    @Volatile var seqStart = 0L
    @Volatile var frames = 0L
    private val q = ConcurrentLinkedQueue<IntArray>()

    // reproducció de seqüència (esdeveniments en frames a `sr`)
    @Volatile var playSeq: List<Ev> = emptyList()
    @Volatile var playCmd = 0                // 1 = engega, 2 = atura
    @Volatile var playing = false
    @Volatile var loop = false
    @Volatile var playFrame = 0L
    private var playIdx = 0

    private fun advanceSeq(n: Int) {
        when (playCmd) {
            1 -> { playIdx = 0; playFrame = 0; playing = playSeq.isNotEmpty(); playCmd = 0 }
            2 -> { playing = false; playCmd = 0; for (t in tracks) t.allOff() }
        }
        if (!playing) return
        val seq = playSeq
        val end = playFrame + n
        while (playIdx < seq.size && seq[playIdx].frame < end) { val e = seq[playIdx++]; dispatch(e.st, e.a, e.b) }
        playFrame = end
        if (playIdx >= seq.size) {
            if (loop) { playIdx = 0; playFrame = 0 } else playing = false
        }
    }

    init { tracks.forEachIndexed { i, t -> t.channel = i } }

    /** Cada pista escolta el seu canal MIDI (per defecte pista n = canal n). Es pot cridar des de qualsevol fil. */
    fun midi(st: Int, a: Int, b: Int) { q.add(intArrayOf(st, a, b)) }

    fun dispatch(st: Int, a: Int, b: Int) {
        val ch = st and 15
        for (t in tracks) if (t.channel == ch) when (st and 0xF0) {
            0x90 -> t.noteOn(a, b)
            0x80 -> t.noteOff(a)
            0xB0 -> if (a == 64) t.sustain(b >= 64) else if (a == 123 || a == 120) t.allOff()
        }
    }

    /** Mesclador: suma les 7 pistes → compressor 1176 → master. Tot en double. */
    fun mix(l: DoubleArray, r: DoubleArray, n: Int) {
        l.fill(0.0, 0, n); r.fill(0.0, 0, n)
        for (t in tracks) t.render(l, r, n)
        reverb.process(l, r, n)
        comp.process(l, r, n)
        val m = master
        var pl = 0.0; var pr = 0.0
        for (i in 0 until n) {
            l[i] *= m; r[i] *= m
            val a = abs(l[i]); if (a > pl) pl = a
            val b = abs(r[i]); if (b > pr) pr = b
        }
        if (pl > peakL) peakL = pl
        if (pr > peakR) peakR = pr
        frames += n
    }

    fun render(l: DoubleArray, r: DoubleArray, n: Int) {
        while (true) {
            val e = q.poll() ?: break
            dispatch(e[0], e[1], e[2])
            seq?.add(Ev(frames - seqStart, e[0], e[1], e[2]))
        }
        advanceSeq(n)
        mix(l, r, n)
    }

    /** Llegeix i reinicia els pics de sortida (per al vúmetre). */
    fun takePeaks(): DoubleArray { val a = doubleArrayOf(peakL, peakR); peakL = 0.0; peakR = 0.0; return a }

    fun cloneFor(newSr: Int): Engine {
        val e = Engine(newSr)
        for (i in 0 until TRACKS) e.tracks[i].let { t -> val s = tracks[i]; t.channel = s.channel; t.fx.copyFrom(s.fx); t.bank = s.bank; t.vol = s.vol; t.pan = s.pan; t.mute = s.mute }
        e.comp.inputDb = comp.inputDb; e.comp.outputDb = comp.outputDb; e.comp.ratioIdx = comp.ratioIdx
        e.comp.attackUs = comp.attackUs; e.comp.releaseMs = comp.releaseMs; e.comp.bypass = comp.bypass
        e.master = master
        e.reverb.mix = reverb.mix; e.reverb.enabled = reverb.enabled
        reverb.raw?.let { e.reverb.load(it) }          // reconstrueix l'IR a la freqüència del render
        return e
    }
}

/** Renderitzat offline (més ràpid que temps real) a qualsevol freqüència i resolució. */
object Renderer {
    /** Renderitza la música (7 pistes + reverb + compressor, tot en double) a memòria, a la freqüència del motor. */
    fun renderBuffers(src: Engine, events: List<Ev>, frames: Int, progress: (Double) -> Unit): Array<DoubleArray> {
        val e = src.cloneFor(src.sr)
        val evs = events.sortedBy { it.frame }
        val outL = DoubleArray(frames); val outR = DoubleArray(frames)
        val b = 512; val l = DoubleArray(b); val r = DoubleArray(b)
        var pos = 0; var i = 0
        while (pos < frames) {
            while (i < evs.size && evs[i].frame <= pos) { e.dispatch(evs[i].st, evs[i].a, evs[i].b); i++ }
            var n = min(b, frames - pos)
            if (i < evs.size) n = min(n, (evs[i].frame - pos).toInt())
            e.mix(l, r, n)
            System.arraycopy(l, 0, outL, pos, n); System.arraycopy(r, 0, outR, pos, n)
            pos += n
            if ((pos / b) % 64 == 0) progress(pos.toDouble() / frames)
        }
        return arrayOf(outL, outR)
    }

    fun render(src: Engine, events: List<Ev>, outRate: Int, file: File, bits: Int, float: Boolean,
               tailSec: Double, progress: (Double) -> Unit) {
        val e = src.cloneFor(outRate)
        val k = outRate.toDouble() / src.sr
        val evs = events.map { it.copy(frame = (it.frame * k).toLong()) }.sortedBy { it.frame }
        val total = (evs.lastOrNull()?.frame ?: 0L) + (tailSec * outRate).toLong()
        val B = 512
        val l = DoubleArray(B); val r = DoubleArray(B)
        WavWriter(file, outRate, bits, float).use { w ->
            var pos = 0L; var i = 0
            while (pos < total) {
                while (i < evs.size && evs[i].frame <= pos) { e.dispatch(evs[i].st, evs[i].a, evs[i].b); i++ }
                var n = min(B.toLong(), total - pos)
                if (i < evs.size) n = min(n, evs[i].frame - pos)
                e.mix(l, r, n.toInt())
                w.write(l, r, n.toInt())
                pos += n
                progress(pos.toDouble() / total)
            }
        }
    }
}
