package cat.sampler

import org.json.JSONObject
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.min

/** Memòria cau del render de música (float64 estèreo) amb signatura: només es reutilitza si res no ha canviat. */
class MusicCache(dir: File) {
    private val data = File(dir, "music.f64")
    private val meta = File(dir, "music.meta")

    fun info(): Pair<String, Int>? = try {
        if (!data.exists()) null else JSONObject(meta.readText()).let { it.getString("sig") to it.getInt("frames") }
    } catch (_: Throwable) { null }

    fun valid(sig: String) = info()?.first == sig
    fun sizeMb() = if (data.exists()) data.length() / 1048576.0 else 0.0

    fun save(l: DoubleArray, r: DoubleArray, frames: Int, sig: String) {
        meta.delete()
        RandomAccessFile(data, "rw").use { f -> f.setLength(0); write(f, l, frames); write(f, r, frames) }
        meta.writeText(JSONObject().put("sig", sig).put("frames", frames).toString())
    }

    private fun write(f: RandomAccessFile, a: DoubleArray, n: Int) {
        val bb = ByteBuffer.allocate(8192 * 8).order(ByteOrder.LITTLE_ENDIAN); var i = 0
        while (i < n) {
            val m = min(8192, n - i); bb.clear()
            for (k in 0 until m) bb.putDouble(a[i + k])
            f.write(bb.array(), 0, m * 8); i += m
        }
    }

    /** Llegeix [start, start+len) de cada canal cap a l, r a partir de l'índex `dst`; el que cau fora del cau queda a zero. */
    fun read(l: DoubleArray, r: DoubleArray, start: Int, len: Int, dst: Int = 0) {
        val fr = info()?.second ?: return
        RandomAccessFile(data, "r").use { f -> readCh(f, 0L, fr, l, start, len, dst); readCh(f, fr * 8L, fr, r, start, len, dst) }
    }

    private fun readCh(f: RandomAccessFile, base: Long, fr: Int, a: DoubleArray, start: Int, len: Int, dst: Int) {
        val n = max(0, min(len, fr - start)); if (n <= 0) return
        f.seek(base + start * 8L)
        val bb = ByteBuffer.allocate(8192 * 8).order(ByteOrder.LITTLE_ENDIAN); var i = 0
        while (i < n) {
            val m = min(8192, n - i); f.readFully(bb.array(), 0, m * 8); bb.clear()
            for (k in 0 until m) a[dst + i + k] = bb.getDouble()
            i += m
        }
    }

    fun delete() { data.delete(); meta.delete() }
}
