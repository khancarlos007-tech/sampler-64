package cat.sampler

import kotlin.math.*

const val VSR = 48000.0
private const val LN10_20 = 0.1151292546497023

/** Biquad Butterworth de 2n ordre (RBJ), amb estat. Servei en flux o amb fase zero (endavant + endarrere). */
class Bq(private val b0: Double, private val b1: Double, private val b2: Double, private val a1: Double, private val a2: Double) {
    private var x1 = 0.0; private var x2 = 0.0; private var y1 = 0.0; private var y2 = 0.0
    fun reset() { x1 = 0.0; x2 = 0.0; y1 = 0.0; y2 = 0.0 }
    fun step(x: Double): Double {
        val y = b0 * x + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2
        x2 = x1; x1 = x; y2 = y1; y1 = y
        return y
    }
    fun fwd(x: DoubleArray) { reset(); for (i in x.indices) x[i] = step(x[i]) }
    fun bwd(x: DoubleArray) { reset(); var i = x.size - 1; while (i >= 0) { x[i] = step(x[i]); i-- } }
    fun zp(x: DoubleArray) { fwd(x); bwd(x) }

    companion object {
        private fun rbj(hp: Boolean, f: Double): Bq {
            val w = 2 * PI * f / VSR; val c = cos(w); val al = sin(w) / (2 * 0.7071067811865476); val a0 = 1 + al
            return if (hp) Bq((1 + c) / 2 / a0, -(1 + c) / a0, (1 + c) / 2 / a0, -2 * c / a0, (1 - al) / a0)
            else Bq((1 - c) / 2 / a0, (1 - c) / a0, (1 - c) / 2 / a0, -2 * c / a0, (1 - al) / a0)
        }
        fun hp(f: Double) = rbj(true, f)
        fun lp(f: Double) = rbj(false, f)
        /** Ponderació K de la BS.1770 (coeficients a 48 kHz). */
        fun kWeight() = arrayOf(
            Bq(1.53512485958697, -2.69169618940638, 1.19839281085285, -1.69065929318241, 0.73248077421585),
            Bq(1.0, -2.0, 1.0, -1.99004745483398, 0.99007225036621))
    }
}

/** Interpolació lineal de guanys per frame (centres a (k+0.5)·H), accés monòton. */
class Up(private val g: DoubleArray, private val h: Int) {
    private var k = 0
    fun at(i: Int): Double {
        if (g.isEmpty()) return 0.0
        val pos = i.toDouble()
        if (pos <= 0.5 * h) return g[0]
        while (k + 1 < g.size && (k + 1.5) * h <= pos) k++
        if (k + 1 >= g.size) return g[g.size - 1]
        return g[k] + (g[k + 1] - g[k]) * (pos - (k + 0.5) * h) / h
    }
}

object VU {
    fun db(p: Double) = 10 * log10(p + 1e-20)
    fun dbArr(a: DoubleArray) = DoubleArray(a.size) { db(a[it]) }
    fun lufsMs(ms: Double) = -0.691 + 10 * log10(ms + 1e-20)

    /** Mitjana quadràtica per frames de H mostres, passant opcionalment per una cadena de filtres. */
    fun fms(x: DoubleArray, h: Int, vararg chain: Bq): DoubleArray {
        for (f in chain) f.reset()
        val n = x.size / h
        val o = DoubleArray(n)
        for (k in 0 until n) {
            var s = 0.0
            for (i in k * h until (k + 1) * h) { var v = x[i]; for (f in chain) v = f.step(v); s += v * v }
            o[k] = s / h
        }
        return o
    }

    fun sm3(x: DoubleArray): DoubleArray {
        val n = x.size
        return DoubleArray(n) { (x[max(it - 1, 0)] + x[it] + x[min(it + 1, n - 1)]) / 3 }
    }

    /** Percentil amb interpolació lineal (com numpy); ordena `a` in situ. */
    fun pctInPlace(a: DoubleArray, p: Double): Double {
        if (a.isEmpty()) return 0.0
        a.sort()
        val pos = p / 100 * (a.size - 1); val lo = floor(pos).toInt(); val hi = min(lo + 1, a.size - 1)
        return a[lo] + (a[hi] - a[lo]) * (pos - lo)
    }
    fun pct(a: DoubleArray, p: Double) = pctInPlace(a.copyOf(), p)

    fun masked(a: DoubleArray, keep: BooleanArray): DoubleArray {
        var c = 0; for (b in keep) if (b) c++
        val o = DoubleArray(c); var j = 0
        for (i in a.indices) if (keep[i]) o[j++] = a[i]
        return o
    }

    /** Suavitzat asimètric d'una corba en dB: `ta` frames cap avall (atac), `tr` frames cap amunt. */
    fun smooth(t: DoubleArray, ta: Double, tr: Double): DoubleArray {
        val o = DoubleArray(t.size); if (t.isEmpty()) return o
        val ca = exp(-1 / max(ta, 1e-9)); val cr = exp(-1 / max(tr, 1e-9))
        var g = t[0]
        for (i in t.indices) { val v = t[i]; val c = if (v < g) ca else cr; g = v + c * (g - v); o[i] = g }
        return o
    }

    /** Sonoritat integrada BS.1770-4 (K-weighting, porta absoluta –70 i relativa –10 LU). Streaming, sense còpies. */
    fun lufsIntegrated(l: DoubleArray, r: DoubleArray?, gain: Double = 1.0, g: DoubleArray? = null): Double {
        val hop = 4800; val nh = l.size / hop
        if (nh < 4) return -70.0
        val z = DoubleArray(nh)
        for (ch in 0 until (if (r == null) 1 else 2)) {
            val src = if (ch == 0) l else r!!
            val kf = Bq.kWeight()
            for (k in 0 until nh) {
                var s = 0.0
                for (i in k * hop until (k + 1) * hop) {
                    val x = src[i] * gain * (g?.get(i) ?: 1.0)
                    val v = kf[1].step(kf[0].step(x)); s += v * v
                }
                z[k] += s / hop
            }
        }
        val nb = nh - 3
        val blk = DoubleArray(nb) { (z[it] + z[it + 1] + z[it + 2] + z[it + 3]) / 4 }
        var sum = 0.0; var cnt = 0
        for (b in blk) if (-0.691 + 10 * log10(b + 1e-20) > -70) { sum += b; cnt++ }
        if (cnt == 0) return -70.0
        val rel = -0.691 + 10 * log10(sum / cnt) - 10
        sum = 0.0; cnt = 0
        for (b in blk) { val l2 = -0.691 + 10 * log10(b + 1e-20); if (l2 > -70 && l2 > rel) { sum += b; cnt++ } }
        return if (cnt == 0) -70.0 else -0.691 + 10 * log10(sum / cnt)
    }

    /**
     * Limitador brickwall amb lookahead (zero latència en fitxer): mínim endavant + mitjana mòbil + alliberament.
     * Retorna el guany per mostra (≤ 1). `scale` s'aplica abans de detectar pics.
     */
    fun limiterGain(a: DoubleArray, b: DoubleArray?, scale: Double, ceilDb: Double, laMs: Double, relMs: Double): DoubleArray {
        val n = a.size; val g = DoubleArray(n); if (n == 0) return g
        val c = 10.0.pow(ceilDb / 20); val la = max(1, (laMs * VSR / 1000).toInt())
        for (i in 0 until n) {
            var p = abs(a[i]); if (b != null) p = max(p, abs(b[i]))
            g[i] = min(1.0, c / max(p * scale, 1e-12))
        }
        val cap = la + 2; val dqI = IntArray(cap); val dqV = DoubleArray(cap)
        var h = 0; var cnt = 0; var nextPush = 0
        for (i in 0 until n) {
            val end = min(n - 1, i + la)
            while (nextPush <= end) {
                val v = g[nextPush]
                while (cnt > 0 && dqV[(h + cnt - 1) % cap] >= v) cnt--
                val pos = (h + cnt) % cap; dqI[pos] = nextPush; dqV[pos] = v; cnt++; nextPush++
            }
            while (dqI[h] < i) { h = (h + 1) % cap; cnt-- }
            g[i] = dqV[h]
        }
        val ring = DoubleArray(la); ring.fill(g[0]); var sum = g[0] * la; var rp = 0
        val cr = exp(-1.0 / (relMs * VSR / 1000)); var go = 1.0
        for (i in 0 until n) {
            val gm = g[i]; sum += gm - ring[rp]; ring[rp] = gm; rp = (rp + 1) % la
            go = min(sum / la, go + (1 - go) * (1 - cr)); g[i] = go
        }
        return g
    }
}

/** Mòduls de neteja de veu (tots in situ sobre el senyal de 48 kHz, en 64 bits). */
object VoiceDsp {
    /** Lowend: passa-alts 80 Hz + control de plosives (crossfade dinàmic cap a un passa-alts de 250 Hz). */
    fun lowend(x: DoubleArray) {
        val h = 48
        Bq.hp(80.0).fwd(x)
        val eL = VU.sm3(VU.dbArr(VU.fms(x, h, Bq.lp(160.0))))
        val eM = VU.sm3(VU.dbArr(VU.fms(x, h, Bq.hp(300.0), Bq.lp(3000.0))))
        val nf = eL.size; if (nf == 0) return
        val ratio = DoubleArray(nf) { eL[it] - eM[it] }
        val thrA = VU.pct(eM, 95.0) - 40
        val act = VU.masked(ratio, BooleanArray(nf) { eM[it] > thrA })
        val base = if (act.isNotEmpty()) VU.pct(act, 50.0) else 0.0
        val g = VU.smooth(DoubleArray(nf) { -((ratio[it] - (base + 9)) * 0.8).coerceIn(0.0, 15.0) }, 2.0, 40.0)
        val y2 = x.copyOf(); Bq.hp(250.0).fwd(y2)
        val up = Up(g, h)
        for (i in x.indices) { val m = (-up.at(i) / 15).coerceIn(0.0, 1.0); x[i] = x[i] * (1 - m) + y2[i] * m }
    }

    /** Mouth noise: clics curts d'alta freqüència (aïllats) reparats per interpolació lineal. */
    fun declick(x: DoubleArray) {
        val h1 = Bq.hp(4000.0); val h2 = Bq.hp(4000.0)
        val c = exp(-1 / (0.020 * VSR)); var env = 0.0
        val n = x.size
        var inCl = false; var s = 0; var e = 0; var last = -1000
        fun finish() {
            if (e - s <= 144 && s > 60 && e + 120 < n) {
                val n0 = s - 24; val n1 = e + 48; val v0 = x[n0 - 1]; val v1 = x[n1 + 1]
                for (j in n0..n1) x[j] = v0 + (v1 - v0) * (j - n0) / (n1 - n0).toDouble()
            }
        }
        for (i in 0 until n) {
            val a = abs(h2.step(h1.step(x[i])))
            val envPrev = env
            env = (1 - c) * a + c * env
            val th = max(8 * (if (i == 0) env else envPrev), 6e-3)
            if (a > th) {
                if (inCl && i - last <= 24) e = i else { if (inCl) finish(); inCl = true; s = i; e = i }
                last = i
            }
        }
        if (inCl) finish()
    }

    /** Clean: reducció de soroll espectral (STFT finestra sinus 1024/512). El perfil de soroll és el percentil 10 per bin. */
    fun clean(x: DoubleArray, redDb: Double, prog: (Double) -> Unit) {
        val nn = 1024; val hop = 512; val nb = nn / 2 + 1; val n = x.size
        val nfr = (n + hop) / hop + 1
        val win = DoubleArray(nn) { sin(PI * (it + 0.5) / nn) }
        val fft = FFT(nn); val re = DoubleArray(nn); val im = DoubleArray(nn)
        fun load(i: Int) {
            val s = i * hop - hop
            for (j in 0 until nn) { val q = s + j; re[j] = if (q in 0 until n) x[q] * win[j] else 0.0; im[j] = 0.0 }
            fft.transform(re, im, false)
        }
        val mags = FloatArray(nfr * nb)
        for (i in 0 until nfr) {
            load(i)
            for (b in 0 until nb) mags[i * nb + b] = hypot(re[b], im[b]).toFloat()
            if (i % 256 == 0) prog(0.4 * i / nfr)
        }
        val noise = DoubleArray(nb); val col = DoubleArray(nfr)
        for (b in 0 until nb) {
            for (i in 0 until nfr) col[i] = mags[i * nb + b].toDouble()
            noise[b] = 2.7 * VU.pctInPlace(col, 10.0)
        }
        prog(0.5)
        val floorG = 10.0.pow(-redDb / 20); val alpha = 1.3
        val prev = DoubleArray(nb); val gs = DoubleArray(nb); val gf = DoubleArray(nb); val acc = DoubleArray(nn)
        for (i in 0 until nfr) {
            load(i)
            for (b in 0 until nb) {
                val g = max(floorG, 1 - alpha * noise[b] / (mags[i * nb + b] + 1e-12))
                gs[b] = if (i == 0) g else if (g > prev[b]) g else 0.6 * prev[b] + 0.4 * g
                prev[b] = gs[b]
            }
            for (b in 0 until nb) gf[b] = (gs[max(b - 1, 0)] + gs[b] + gs[min(b + 1, nb - 1)]) / 3
            for (b in 0 until nb) {
                re[b] *= gf[b]; im[b] *= gf[b]
                if (b in 1 until nn / 2) { re[nn - b] *= gf[b]; im[nn - b] *= gf[b] }
            }
            fft.transform(re, im, true)
            for (j in 0 until nn) acc[j] += re[j] * win[j]
            val s0 = i * hop - hop
            for (j in 0 until hop) { val q = s0 + j; if (q in 0 until n) x[q] = acc[j] }
            System.arraycopy(acc, hop, acc, 0, nn - hop); java.util.Arrays.fill(acc, nn - hop, nn, 0.0)
            if (i % 256 == 0) prog(0.5 + 0.5 * i / nfr)
        }
    }

    /** Breath: frames sense to (autocorrelació a 8 kHz), de nivell mitjà-baix i de 120–1200 ms s'atenuen. */
    fun breath(x: DoubleArray, amountDb: Double) {
        val h = 480; val nf = x.size / h; if (nf < 3) return
        val lvl = VU.dbArr(VU.fms(x, h))
        val l1 = Bq.lp(3000.0); val l2 = Bq.lp(3000.0)
        val d = DoubleArray((x.size + 5) / 6)
        for (i in x.indices) { val v = l2.step(l1.step(x[i])); if (i % 6 == 0) d[i / 6] = v }
        val per = DoubleArray(nf)
        for (i in 0 until nf) {
            val o = i * 80; if (o + 160 > d.size) break
            var best = 0.0
            for (lag in 16..100) {
                var uv = 0.0; var uu = 0.0; var vv = 0.0
                for (j in 0 until 160 - lag) { val u = d[o + j]; val v = d[o + j + lag]; uv += u * v; uu += u * u; vv += v * v }
                best = max(best, uv / (sqrt(uu * vv) + 1e-20))
            }
            per[i] = best
        }
        val voicedL = ArrayList<Double>()
        for (i in 0 until nf) if (per[i] > 0.7) voicedL.add(lvl[i])
        val ref = if (voicedL.size > 5) VU.pct(voicedL.toDoubleArray(), 90.0) else VU.pct(lvl, 90.0)
        val noise = VU.pct(lvl, 10.0)
        val cand = BooleanArray(nf) { per[it] < 0.5 && lvl[it] > ref - 38 && lvl[it] < ref - 12 && lvl[it] > noise + 6 }
        val c0 = cand.copyOf()
        for (i in 0 until nf) {
            if (!c0[i]) {
                var left = false; var right = false
                for (j in max(0, i - 3) until i) if (c0[j]) left = true
                for (j in i + 1 until min(nf, i + 4)) if (c0[j]) right = true
                if (left && right) cand[i] = true
            }
        }
        val tgt = DoubleArray(nf); var i = 0
        while (i < nf) {
            if (cand[i]) {
                var j = i; while (j + 1 < nf && cand[j + 1]) j++
                if (j - i + 1 in 12..120) for (k in i..j) tgt[k] = -amountDb
                i = j + 1
            } else i++
        }
        val up = Up(VU.smooth(tgt, 1.5, 1.5), h)
        for (k in x.indices) x[k] *= exp(up.at(k) * LN10_20)
    }

    /** Gate: expansor descendent automàtic (llindar = soroll+9 dB, hold 80 ms, lookahead 5 ms). */
    fun gate(x: DoubleArray, rangeDb: Double) {
        val h = 48; val e = VU.fms(x, h); val nf = e.size; if (nf == 0) return
        val pre = DoubleArray(nf + 1); for (i in 0 until nf) pre[i + 1] = pre[i] + e[i]
        val lvl = DoubleArray(nf) { val lo = max(0, it - 5); val hi = min(nf - 1, it + 4); VU.db((pre[hi + 1] - pre[lo]) / 10) }
        val thr = min(VU.pct(lvl, 10.0) + 9, VU.pct(lvl, 90.0) - 30)
        val op = BooleanArray(nf); var st = false; var hold = 0
        for (i in 0 until nf) {
            if (lvl[i] > thr) { st = true; hold = 80 }
            else if (st && lvl[i] < thr - 3) { hold--; if (hold <= 0) st = false }
            op[i] = st
        }
        val tgt = DoubleArray(nf) { i -> var any = false; for (j in i until min(nf, i + 6)) if (op[j]) any = true; if (any) 0.0 else -rangeDb }
        val up = Up(VU.smooth(tgt, 150.0, 3.0), h)
        for (i in x.indices) x[i] *= exp(up.at(i) * LN10_20)
    }

    /** De-esser: redueix dinàmicament la banda 4,5–12 kHz (fase zero) quan sobresurt respecte al nivell de banda ample. */
    fun deess(x: DoubleArray, maxRed: Double) {
        val h = 48
        val band = x.copyOf(); Bq.hp(4500.0).zp(band); Bq.lp(12000.0).zp(band)
        val eB = VU.sm3(VU.dbArr(VU.fms(band, h))); val eF = VU.sm3(VU.dbArr(VU.fms(x, h)))
        val nf = eF.size; if (nf == 0) return
        val ratio = DoubleArray(nf) { eB[it] - eF[it] }
        val thrA = VU.pct(eF, 90.0) - 25
        val act = VU.masked(ratio, BooleanArray(nf) { eF[it] > thrA })
        val base = if (act.isNotEmpty()) VU.pct(act, 50.0) else 0.0
        val g = VU.smooth(DoubleArray(nf) { -((ratio[it] - (base + 5)) * 0.9).coerceIn(0.0, maxRed) }, 1.0, 25.0)
        val up = Up(g, h)
        for (i in x.indices) x[i] -= band[i] * (1 - exp(up.at(i) * LN10_20))
    }

    /** Leveler: guany lent cap a un objectiu en LUFS (només sobre parts amb veu) + captura de pics (–2 dBFS). */
    fun leveler(x: DoubleArray, target: Double, speed: Double, smoothing: Double) {
        val f = 4800
        val ms = VU.fms(x, f, *Bq.kWeight()); val lu = VU.dbArr(VU.fms(x, f)); val n = ms.size; if (n == 0) return
        val thr = max(VU.pct(lu, 10.0) + 12, VU.pct(lu, 90.0) - 30)
        val pn = DoubleArray(n + 1); val pd = DoubleArray(n + 1)
        for (i in 0 until n) { val a = if (lu[i] > thr) 1.0 else 0.0; pn[i + 1] = pn[i] + ms[i] * a; pd[i + 1] = pd[i] + a }
        val win = max(1, (speed * 10).roundToInt()); val off = (win - 1) / 2
        val gdb = DoubleArray(n); var last = Double.NaN
        for (i in 0 until n) {
            val lo = max(0, i + off - (win - 1)); val hi = min(n - 1, i + off)
            val den = pd[hi + 1] - pd[lo]
            if (den > 0) last = VU.lufsMs(2 * (pn[hi + 1] - pn[lo]) / den)
            gdb[i] = (target - (if (last.isNaN()) target else last)).coerceIn(-12.0, 12.0)
        }
        val k = 0.5 + smoothing
        val up = Up(VU.smooth(gdb, 0.25 * speed * 10 * k, 0.6 * speed * 10 * k), f)
        for (i in x.indices) x[i] *= exp(up.at(i) * LN10_20)
        val g = VU.limiterGain(x, null, 1.0, -2.0, 2.0, 60.0)
        for (i in x.indices) x[i] *= g[i]
    }
}

class VoiceParams {
    var lowend = true; var declick = true; var clean = true; var cleanDb = 12.0
    var breath = true; var breathDb = 10.0; var gate = true; var gateDb = 20.0
    var deess = true; var deessMax = 10.0
    var dynamics = true; var speed = 1.0; var smoothing = 0.5
    var prevalence = 0.5          // 0 = veu integrada, 1 = veu dominant
    var targetLufs = -14.0; var ceilingDb = -1.0
}

class MixReport(val text: String, val lufs: Double, val peak: Double)

/**
 * Mescla automàtica: neteja la veu, mesura la música (post reverb + compressor) sota la veu,
 * nivella la veu cap a un objectiu relatiu a la música, abaixa la música (banda vocal 300–4k) segons
 * l'avantatge espectral que falti, suma i maximitza al final (guany + limitador brickwall).
 * `music` es modifica in situ i conté la mescla final; `voice` es consumeix.
 */
object VoiceMixer {
    private fun bandCopy(x: DoubleArray): DoubleArray { val b = x.copyOf(); Bq.hp(300.0).zp(b); Bq.lp(4000.0).zp(b); return b }

    fun process(music: Array<DoubleArray>, voice: DoubleArray, p: VoiceParams, prog: (String, Double) -> Unit): MixReport {
        val n = voice.size; val f = 4800
        val sb = StringBuilder()
        if (p.declick) { prog("Mouth noise…", 0.02); VoiceDsp.declick(voice) }
        if (p.lowend) { prog("Lowend…", 0.05); VoiceDsp.lowend(voice) }
        if (p.clean) { VoiceDsp.clean(voice, p.cleanDb) { prog("Clean (reducció de soroll)…", 0.08 + 0.22 * it) } }
        if (p.breath) { prog("Breath…", 0.32); VoiceDsp.breath(voice, p.breathDb) }
        if (p.gate) { prog("Gate…", 0.38); VoiceDsp.gate(voice, p.gateDb) }
        if (p.deess) { prog("De-esser…", 0.42); VoiceDsp.deess(voice, p.deessMax) }

        prog("Analitzant música i veu…", 0.48)
        val lu = VU.dbArr(VU.fms(voice, f)); val nfr = lu.size
        val thr = max(VU.pct(lu, 10.0) + 12, VU.pct(lu, 90.0) - 30)
        val act = BooleanArray(nfr) { lu[it] > thr }
        val kl = VU.fms(music[0], f, *Bq.kWeight()); val kr = VU.fms(music[1], f, *Bq.kWeight())
        var sa = 0.0; var ca = 0; var sAll = 0.0
        for (i in 0 until nfr) { val m = kl[i] + kr[i]; sAll += m; if (act[i]) { sa += m; ca++ } }
        val lm = if (ca > 0) VU.lufsMs(sa / ca) else VU.lufsMs(sAll / max(1, nfr))
        val pv = p.prevalence
        val tv = if (lm < -70) -20.0 else lm + (-1 + 4 * pv)
        sb.append("Música sota la veu: %.1f LUFS\n".format(lm))

        if (p.dynamics) { prog("Nivellant la veu…", 0.55); VoiceDsp.leveler(voice, tv, p.speed, p.smoothing) }
        val lu2 = VU.dbArr(VU.fms(voice, f)); val thr2 = max(VU.pct(lu2, 10.0) + 12, VU.pct(lu2, 90.0) - 30)
        val act2 = BooleanArray(lu2.size) { lu2[it] > thr2 }
        sb.append("Veu nivellada cap a %.1f LUFS (%s)\n".format(tv, if (p.dynamics) "leveler actiu" else "leveler apagat"))

        prog("Calculant màscara espectral…", 0.62)
        var ev = 0.0; var em = 0.0; var c2 = 0
        run {
            val vb = bandCopy(voice); val ev0 = VU.fms(vb, f)
            val eml = VU.fms(bandCopy(music[0]), f); val emr = VU.fms(bandCopy(music[1]), f)
            for (i in act2.indices) if (act2[i]) { ev += ev0[i]; em += (eml[i] + emr[i]) / 2; c2++ }
        }
        val aex = if (c2 > 0) 10 * log10((ev / c2) / (em / c2 + 1e-20)) else 0.0
        val dmid = ((3 + 6 * pv) - aex).coerceIn(0.0, 9.0); val dbr = 0.35 * dmid
        sb.append("Avantatge veu/música a 300–4k: %.1f dB → la música s'abaixa %.1f dB (mitjos) i %.1f dB (resta) quan parla la veu\n".format(aex, dmid, dbr))

        prog("Aplicant ducking i sumant…", 0.70)
        val g10 = 480; val l10 = VU.dbArr(VU.fms(voice, g10)); val on = BooleanArray(l10.size) { l10[it] > thr2 }
        val tgt = DoubleArray(on.size) { i -> var any = false; for (j in i until min(on.size, i + 4)) if (on[j]) any = true; if (any) -1.0 else 0.0 }
        val e = VU.smooth(tgt, 3.0, 30.0)                      // -1 = veu activa
        for (k in 0..1) {
            val c = music[k]; val m = bandCopy(c); val up = Up(e, g10)
            for (i in 0 until n) {
                val ef = -up.at(i)
                val gm = exp(-dmid * ef * LN10_20); val gb = exp(-dbr * ef * LN10_20)
                c[i] = c[i] - (c[i] - m[i]) * (1 - gb) - m[i] * (1 - gm) + voice[i]
            }
        }

        prog("Maximitzant (guany + limitador)…", 0.82)
        val ceil = 10.0.pow(p.ceilingDb / 20)
        val pre = VU.lufsIntegrated(music[0], music[1])
        var gain = 10.0.pow((p.targetLufs - pre) / 20)
        var g = VU.limiterGain(music[0], music[1], gain, p.ceilingDb, 5.0, 80.0); var lo = pre
        for (it in 0 until 6) {
            lo = VU.lufsIntegrated(music[0], music[1], gain, g)
            if (abs(p.targetLufs - lo) < 0.1) break
            gain *= 10.0.pow((p.targetLufs - lo) / 20)
            g = VU.limiterGain(music[0], music[1], gain, p.ceilingDb, 5.0, 80.0)
        }
        var mgr = 0.0; for (v in g) mgr += -20 * log10(v); mgr /= max(1, g.size)
        var note = ""
        if (mgr > 8.0) {                                        // massa limitació: retrocedeix per no destrossar la dinàmica
            gain *= 10.0.pow(-(mgr - 8.0) / 20); g = VU.limiterGain(music[0], music[1], gain, p.ceilingDb, 5.0, 80.0)
            lo = VU.lufsIntegrated(music[0], music[1], gain, g)
            mgr = 0.0; for (v in g) mgr += -20 * log10(v); mgr /= max(1, g.size)
            note = " (limitat per no passar de 8 dB de reducció mitjana)"
        }
        var pk = 0.0
        for (k in 0..1) { val c = music[k]; for (i in 0 until n) { val y = (c[i] * gain * g[i]).coerceIn(-ceil, ceil); c[i] = y; pk = max(pk, abs(y)) } }
        val pkDb = 20 * log10(max(pk, 1e-12))
        sb.append("Final: %.1f LUFS-I (objectiu %.1f)%s · pic %.2f dBFS · guany %+.1f dB · reducció mitjana del limitador %.2f dB"
            .format(lo, p.targetLufs, note, pkDb, 20 * log10(gain), mgr))
        prog("Fet", 1.0)
        return MixReport(sb.toString(), lo, pkDb)
    }
}
