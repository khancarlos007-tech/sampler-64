package cat.sampler

import android.annotation.SuppressLint
import android.content.Context
import android.media.*
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Gravador de la pista de veu: AudioRecord en float de 32 bits, mono, des de la interfície USB triada. */
class VoiceRecorder {
    @Volatile var recording = false
    @Volatile var frames = 0L
    @Volatile var peak = 0.0
    private var chunks = ArrayList<FloatArray>()
    private var th: Thread? = null

    @SuppressLint("MissingPermission")
    fun start(dev: AudioDeviceInfo?, sr: Int, maxFrames: Long): String? {
        if (recording) return null
        val fmt = AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
            .setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_IN_MONO).build()
        val minBuf = AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_FLOAT)
        if (minBuf <= 0) return "Format d'entrada no suportat ($sr Hz, float)"
        var rec: AudioRecord? = null
        // UNPROCESSED evita AGC i processat del sistema; si el dispositiu no ho admet, es prova MIC
        for (src in intArrayOf(MediaRecorder.AudioSource.UNPROCESSED, MediaRecorder.AudioSource.MIC)) {
            try {
                val r = AudioRecord.Builder().setAudioSource(src).setAudioFormat(fmt)
                    .setBufferSizeInBytes(max(minBuf, sr * 4)).build()
                if (r.state == AudioRecord.STATE_INITIALIZED) { rec = r; break } else r.release()
            } catch (_: Throwable) { }
        }
        val ar = rec ?: return "No es pot obrir l'entrada d'àudio (permís de micròfon?)"
        if (dev != null) ar.setPreferredDevice(dev)
        chunks = ArrayList(); frames = 0; peak = 0.0
        recording = true
        th = Thread {
            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_URGENT_AUDIO)
            val buf = FloatArray(2048)
            ar.startRecording()
            while (recording) {
                val n = ar.read(buf, 0, buf.size, AudioRecord.READ_BLOCKING)
                if (n < 0) break
                if (n == 0) continue
                chunks.add(buf.copyOf(n)); frames += n
                var p = 0.0
                for (i in 0 until n) p = max(p, abs(buf[i]).toDouble())
                if (p > peak) peak = p
                if (frames >= maxFrames) recording = false
            }
            ar.stop(); ar.release()
            recording = false
        }.also { it.start() }
        return null
    }

    fun stop() { recording = false; th?.join(); th = null }

    /** Desa la gravació (float32 LE) perquè sobrevisqui al tancament de l'app. */
    fun saveTo(f: java.io.File) {
        java.io.BufferedOutputStream(java.io.FileOutputStream(f)).use { o ->
            val bb = java.nio.ByteBuffer.allocate(8192 * 4).order(java.nio.ByteOrder.LITTLE_ENDIAN)
            for (c in chunks) {
                var i = 0
                while (i < c.size) {
                    val n = min(8192, c.size - i); bb.clear()
                    for (k in 0 until n) bb.putFloat(c[i + k])
                    o.write(bb.array(), 0, n * 4); i += n
                }
            }
        }
    }

    fun loadFrom(f: java.io.File) {
        if (!f.exists() || recording) return
        val list = ArrayList<FloatArray>(); var total = 0L
        java.io.BufferedInputStream(java.io.FileInputStream(f)).use { ins ->
            val buf = ByteArray(8192 * 4)
            while (true) {
                var filled = 0
                while (filled < buf.size) { val r = ins.read(buf, filled, buf.size - filled); if (r < 0) break; filled += r }
                val n = filled / 4; if (n <= 0) break
                val ch = FloatArray(n)
                java.nio.ByteBuffer.wrap(buf, 0, n * 4).order(java.nio.ByteOrder.LITTLE_ENDIAN).asFloatBuffer().get(ch)
                list.add(ch); total += n
                if (filled < buf.size) break
            }
        }
        chunks = list; frames = total
    }
    fun takePeak(): Double { val p = peak; peak = 0.0; return p }

    /** Còpia en 64 bits de tot el que s'ha gravat. */
    fun toDoubles(): DoubleArray {
        val out = DoubleArray(frames.toInt()); var p = 0
        for (c in chunks) { for (v in c) { if (p < out.size) out[p++] = v.toDouble() } }
        return out
    }
}

/** Reprodueix la mescla final des de memòria (float 32 bits al maquinari d'àudio). */
class MixPlayer {
    @Volatile private var run = false
    val playing get() = run

    fun play(l: DoubleArray, r: DoubleArray, sr: Int, onDone: () -> Unit) {
        run = false
        val b = 4096
        val minBuf = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_FLOAT)
        val at = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_FLOAT).setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build())
            .setBufferSizeInBytes(max(minBuf, b * 8)).build()
        run = true
        Thread {
            val o = FloatArray(b * 2); var pos = 0
            at.play()
            while (run && pos < l.size) {
                val n = min(b, l.size - pos)
                for (i in 0 until n) { o[2 * i] = l[pos + i].toFloat(); o[2 * i + 1] = r[pos + i].toFloat() }
                at.write(o, 0, n * 2, AudioTrack.WRITE_BLOCKING); pos += n
            }
            at.stop(); at.release(); run = false; onDone()
        }.start()
    }

    fun stop() { run = false }
}

object AudioDevices {
    private fun typeName(t: Int) = when (t) {
        AudioDeviceInfo.TYPE_USB_DEVICE -> "USB"
        AudioDeviceInfo.TYPE_USB_HEADSET -> "USB headset"
        AudioDeviceInfo.TYPE_WIRED_HEADSET -> "jack"
        AudioDeviceInfo.TYPE_BUILTIN_MIC -> "micro del mòbil"
        AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> "Bluetooth"
        else -> "tipus $t"
    }
    fun inputs(ctx: Context): List<AudioDeviceInfo> =
        (ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager).getDevices(AudioManager.GET_DEVICES_INPUTS).toList()
    fun label(d: AudioDeviceInfo) = "${d.productName} (${typeName(d.type)})"
}
