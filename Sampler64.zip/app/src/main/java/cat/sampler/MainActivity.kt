package cat.sampler

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioDeviceInfo
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.documentfile.provider.DocumentFile
import org.json.JSONObject
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min

/** Estat persistent: tots els controls (clau estable -> valor) i 4 snapshots manuals. */
class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("sampler64", Context.MODE_PRIVATE)
    val state = LinkedHashMap<String, String>()
    private val h = Handler(Looper.getMainLooper())
    private val saver = Runnable { saveNow() }

    init {
        try { val j = JSONObject(sp.getString("state", "{}")!!); for (k in j.keys()) state[k] = j.getString(k) } catch (_: Throwable) { }
    }

    fun get(k: String): String? = state[k]
    fun put(k: String, v: String?) {
        if (v == null) state.remove(k) else state[k] = v
        h.removeCallbacks(saver); h.postDelayed(saver, 600)
    }
    fun saveNow() { h.removeCallbacks(saver); sp.edit().putString("state", JSONObject(state as Map<*, *>).toString()).apply() }
    fun saveSnapshot(i: Int) {
        sp.edit().putString("snap$i", JSONObject(state as Map<*, *>).toString())
            .putString("snapT$i", SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date())).apply()
    }
    fun snapshot(i: Int): JSONObject? = try { sp.getString("snap$i", null)?.let { JSONObject(it) } } catch (_: Throwable) { null }
    fun snapshotTime(i: Int): String? = sp.getString("snapT$i", null)
    fun getLong(k: String, def: Long) = sp.getLong(k, def)
    fun putLong(k: String, v: Long) { sp.edit().putLong(k, v).apply() }
    fun clearState() { state.clear(); sp.edit().remove("state").apply() }
}

class MainActivity : ComponentActivity() {
    // ---- paleta
    private val BG = Color.parseColor("#0E1116"); private val PANEL = Color.parseColor("#141922"); private val CARD = Color.parseColor("#1A202B")
    private val CARD2 = Color.parseColor("#252D3B"); private val TXT = Color.parseColor("#ECEFF4"); private val SUB = Color.parseColor("#9AA5B8")
    private val ORANGE = Color.parseColor("#FF9F1C"); private val TEAL = Color.parseColor("#2EC4B6"); private val VIOLET = Color.parseColor("#8B7BFF")
    private val PINK = Color.parseColor("#FF4D8D"); private val BLUE = Color.parseColor("#4DA3FF"); private val RED = Color.parseColor("#E5484D"); private val GREEN = Color.parseColor("#30A46C")

    private val engine = Engine(48000)
    private val audio = AudioOut(engine)
    private lateinit var midi: MidiIn
    private lateinit var status: TextView
    private lateinit var store: Store
    private val setters = HashMap<String, (String) -> Unit>()
    private var scope = ""
    private var accent = ORANGE

    private val fmts = listOf("16 bit int" to (16 to false), "24 bit int" to (24 to false), "32 bit int" to (32 to false),
        "32 bit float" to (32 to true), "64 bit float (IEEE)" to (64 to true))
    private val rates = listOf(44100, 48000, 88200, 96000, 192000)
    private var fmtSel = 4
    private var rateSel = 1
    private var target = -1
    private var events: List<Ev> = emptyList()
    private var live: LiveRecorder? = null
    private lateinit var seqInfo: TextView
    private lateinit var audioBtn: Button
    private lateinit var diagText: TextView
    private var autoPause = true
    private var diagTick = 0

    // transport, marcadors, previa i memòria cau
    private var markIn = 0L
    private var markOut = -1L                  // -1 = final de la seqüència
    private var cursor = 0L
    private var userStopped = false
    private var wasPlaying = false
    private lateinit var timeline: TimelineView
    private lateinit var timeText: TextView
    private lateinit var markText: TextView
    private lateinit var rangeText: TextView
    private lateinit var cacheInfo: TextView
    private lateinit var meterOpto: MeterView
    private var dispOpto = 0.0
    private val cache by lazy { MusicCache(filesDir) }
    private var keepCache = true
    private var previewMix: Array<DoubleArray>? = null
    private var previewStart = 0
    private val dirLabels = HashMap<String, TextView>()

    // pista de veu
    private val vp = VoiceParams()
    private val recorder = VoiceRecorder()
    private val player = MixPlayer()
    private var devs: List<AudioDeviceInfo> = emptyList()
    private val devNames = ArrayList<String>()
    private lateinit var devAdapter: ArrayAdapter<String>
    private lateinit var devSpinner: Spinner
    private lateinit var voiceInfo: TextView
    private lateinit var voiceReport: TextView
    private var dispIn = 0.0
    private var latencyMs = 0
    private var syncSeq = true
    private var finalMix: Array<DoubleArray>? = null
    @Volatile private var busy = false

    // vúmetres
    private lateinit var meterL: MeterView
    private lateinit var meterR: MeterView
    private lateinit var meterGr: MeterView
    private lateinit var meterIn: MeterView
    private val ui = Handler(Looper.getMainLooper())
    private var dispL = 0.0
    private var dispR = 0.0
    private var dispGr = 0.0

    // biblioteca d'IR
    private var irFiles: List<DocumentFile> = emptyList()
    private val irNames = ArrayList<String>()
    private lateinit var irAdapter: ArrayAdapter<String>
    private lateinit var irSpinner: Spinner
    private var loadedIr: Uri? = null

    private val tick = object : Runnable {
        override fun run() {
            val pk = engine.takePeaks()
            dispL = max(pk[0], dispL * 0.93); dispR = max(pk[1], dispR * 0.93)
            showOut(meterL, dispL); showOut(meterR, dispR)
            val g = engine.comp.grDb
            dispGr = if (g > dispGr) g else dispGr * 0.85 + g * 0.15
            meterGr.level = dispGr / 24.0; meterGr.text = "-%.1f dB".format(dispGr); meterGr.invalidate()
            val go = engine.opto.grDb
            dispOpto = if (go > dispOpto) go else dispOpto * 0.9 + go * 0.1
            meterOpto.level = dispOpto / 24.0; meterOpto.text = "-%.1f dB".format(dispOpto); meterOpto.invalidate()
            val pl = engine.playing
            if (pl) cursor = engine.playFrame
            else if (wasPlaying) { if (!userStopped) cursor = inF(); userStopped = false }
            wasPlaying = pl
            updateTransportUi()
            if (++diagTick % 8 == 0) diagText.text = diagString()
            seqInfo.text = seqText()
            dispIn = max(recorder.takePeak(), dispIn * 0.93); showOut(meterIn, dispIn)
            voiceInfo.text = if (recorder.recording) "● Gravant veu: %.1f s".format(recorder.frames / engine.sr.toDouble())
                             else "Veu gravada: %.1f s".format(recorder.frames / engine.sr.toDouble())
            ui.postDelayed(this, 33)
        }
    }

    private fun seqText(): String {
        val len = (events.lastOrNull()?.frame ?: 0L) / engine.sr.toDouble()
        return if (engine.playing) "▶ %.1f / %.1f s".format(engine.playFrame / engine.sr.toDouble(), len)
        else "Seqüència: ${events.size} esdeveniments, %.1f s".format(len)
    }

    private fun showOut(m: MeterView, peak: Double) {
        val db = 20 * log10(max(peak, 1e-6))
        m.level = (db + 60) / 60; m.hot = peak >= 1.0
        m.text = if (peak >= 1.0) "CLIP" else "%.1f dB".format(db)
        m.invalidate()
    }

    private val askMic = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startVoice() else status.text = "Cal el permís de micròfon per gravar la veu"
    }
    private val pickMidi = registerForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let { u -> loadMidi(u) } }
    private val pickIr = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { it?.let { u -> scanIrs(u, true) } }
    private val pick = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { it?.let { u -> loadDir(target, u, true) } }

    // ------------------------------------------------------------------ helpers de disseny
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(c: Int, r: Int = 14) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
    private fun lp(w: Int, h: Int, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0, weight: Float = 0f) =
        LinearLayout.LayoutParams(w, h, weight).apply { setMargins(l, t, r, b) }
    private fun tv(text: CharSequence, size: Float = 14f, color: Int = TXT, bold: Boolean = false) =
        TextView(this).apply { this.text = text; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD }

    private fun card(parent: LinearLayout, title: String): LinearLayout {
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rounded(CARD, 16); setPadding(dp(14), dp(12), dp(14), dp(14)) }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL }
        head.addView(View(this).apply { background = rounded(accent, 3) }, lp(dp(5), dp(20), r = dp(10)))
        head.addView(tv(title, 15f, accent, true))
        c.addView(head)
        parent.addView(c, lp(-1, -2, b = dp(12)))
        return c
    }

    private fun mkBtn(text: String, color: Int, f: () -> Unit) = Button(this).apply {
        this.text = text; isAllCaps = false; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; textSize = 14f
        background = rounded(color, 14); minHeight = dp(46); minimumHeight = dp(46); setPadding(dp(12), 0, dp(12), 0)
        setOnClickListener { f() }
    }
    private fun btn(p: LinearLayout, text: String, color: Int = CARD2, f: () -> Unit): Button =
        mkBtn(text, color, f).also { p.addView(it, lp(-1, -2, t = dp(8))) }
    private fun act(text: String, color: Int, f: () -> Unit) = Triple(text, color, f)
    private fun btnRow(p: LinearLayout, vararg items: Triple<String, Int, () -> Unit>) {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((i, item) in items.withIndex()) r.addView(mkBtn(item.first, item.second, item.third), lp(0, -2, l = if (i > 0) dp(8) else 0, weight = 1f))
        p.addView(r, lp(-1, -2, t = dp(8)))
    }

    private fun slider(p: LinearLayout, label: String, max: Int, def: Int, fmt: (Int) -> String = { it.toString() }, cb: (Int) -> Unit): SeekBar {
        val key = scope + label
        val init = (store.get(key)?.toIntOrNull() ?: def).coerceIn(0, max)
        val value = tv(fmt(init), 13f, accent, true)
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        head.addView(tv(label, 13f, SUB), lp(0, -2, weight = 1f)); head.addView(value)
        val sb = SeekBar(this).apply {
            this.max = max; progress = init
            progressTintList = ColorStateList.valueOf(accent); thumbTintList = ColorStateList.valueOf(accent)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, v: Int, u: Boolean) { value.text = fmt(v); store.put(key, v.toString()); cb(v) }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }
        setters[key] = { v -> v.toIntOrNull()?.let { sb.progress = it.coerceIn(0, max) } }
        p.addView(head, lp(-1, -2, t = dp(8))); p.addView(sb)
        cb(init)
        return sb
    }

    private fun chk(p: LinearLayout, label: String, def: Boolean, cb: (Boolean) -> Unit): CheckBox {
        val key = scope + label
        val init = store.get(key)?.let { it == "1" } ?: def
        val c = CheckBox(this).apply {
            text = label; setTextColor(TXT); buttonTintList = ColorStateList.valueOf(accent); isChecked = init
            setOnCheckedChangeListener { _, v -> store.put(key, if (v) "1" else "0"); cb(v) }
        }
        setters[key] = { v -> c.isChecked = (v == "1") }
        p.addView(c); cb(init)
        return c
    }

    private fun spin(p: LinearLayout, items: List<String>, def: Int, cb: (Int) -> Unit): Spinner {
        val key = scope + "spin:" + items.first()
        val init = (store.get(key)?.toIntOrNull() ?: def).coerceIn(0, items.size - 1)
        val s = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
            background = rounded(CARD2, 10); setSelection(init)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(a: AdapterView<*>?, v: View?, pos: Int, id: Long) { store.put(key, pos.toString()); cb(pos) }
                override fun onNothingSelected(a: AdapterView<*>?) {}
            }
        }
        setters[key] = { v -> v.toIntOrNull()?.let { s.setSelection(it.coerceIn(0, items.size - 1)) } }
        p.addView(s, lp(-1, -2, t = dp(8))); cb(init)
        return s
    }

    private fun dirLabel(p: LinearLayout, key: String) {
        val l = tv(dirName(key), 12f, SUB); dirLabels[key] = l; p.addView(l, lp(-1, -2, t = dp(4)))
    }
    private fun dirName(key: String): String {
        val u = store.get(key) ?: return "📁 (cap directori)"
        return "📁 " + (try { DocumentFile.fromTreeUri(this, Uri.parse(u))?.name } catch (_: Throwable) { null } ?: "?")
    }

    // ------------------------------------------------------------------ construcció de la interfície
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        store = Store(this)
        window.decorView.setBackgroundColor(BG)

        // panell fix superior: títol, àudio, vúmetres i estat
        val top = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(PANEL); setPadding(dp(14), dp(8), dp(14), dp(6)) }
        val title = SpannableStringBuilder("SAMPLER64").apply { setSpan(ForegroundColorSpan(ORANGE), 7, 9, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE) }
        val headRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL }
        headRow.addView(tv(title, 20f, TXT, true), lp(0, -2, weight = 1f))
        audioBtn = mkBtn("ÀUDIO: OFF", CARD2) { toggleAudio() }
        headRow.addView(audioBtn, lp(-2, dp(40)))
        top.addView(headRow, lp(-1, -2))
        meterL = MeterView(this, "OUT L"); meterR = MeterView(this, "OUT R"); meterGr = MeterView(this, "GR", gr = true); meterIn = MeterView(this, "MIC"); meterOpto = MeterView(this, "OPT", gr = true)
        for (m in listOf(meterL, meterR, meterGr, meterOpto, meterIn)) top.addView(m, lp(-1, -2))
        status = tv("Llest. Connecta un teclat MIDI o fes servir el teclat en pantalla.", 12f, SUB)
        top.addView(status, lp(-1, -2, t = dp(2)))

        // pestanyes
        val tabs = listOf("TOCAR" to ORANGE, "PISTES" to TEAL, "EFECTES" to VIOLET, "VEU" to PINK, "SISTEMA" to BLUE)
        val tabBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(8), dp(6), dp(8), dp(6)); setBackgroundColor(PANEL) }
        val pagesBox = FrameLayout(this)
        val pages = ArrayList<ScrollView>(); val tabBtns = ArrayList<Button>()
        fun select(i: Int) {
            for (j in pages.indices) {
                pages[j].visibility = if (j == i) View.VISIBLE else View.GONE
                tabBtns[j].background = rounded(if (j == i) tabs[j].second else CARD2, 10)
                tabBtns[j].setTextColor(if (j == i) Color.BLACK else SUB)
            }
            store.put("tab", i.toString())
        }
        for ((i, t) in tabs.withIndex()) {
            val b = mkBtn(t.first, CARD2) { select(i) }.apply { textSize = 12f; minHeight = dp(40); minimumHeight = dp(40); setPadding(0, 0, 0, 0) }
            tabBtns.add(b); tabBar.addView(b, lp(0, -2, l = if (i > 0) dp(6) else 0, weight = 1f))
        }
        fun page(color: Int): LinearLayout {
            accent = color
            val inner = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(12), dp(12), dp(24)) }
            val sv = ScrollView(this).apply { addView(inner); visibility = View.GONE }
            pages.add(sv); pagesBox.addView(sv, FrameLayout.LayoutParams(-1, -1))
            return inner
        }

        // ================= PÀGINA TOCAR
        var pg = page(ORANGE)
        scope = "kb."
        var c = card(pg, "Teclat en pantalla")
        var kbTrack = 0
        spin(c, (1..Engine.TRACKS).map { "Teclat → pista $it" }, 0) { kbTrack = it }
        val piano = PianoView(this) { n, down ->
            val ch = engine.tracks[kbTrack].channel
            engine.midi((if (down) 0x90 else 0x80) or ch, n, if (down) 100 else 0)
        }
        val scv = HorizontalScrollView(this).apply { addView(piano); setBackgroundColor(BG) }
        c.addView(scv, lp(-1, -2, t = dp(8)))
        slider(c, "Desplaça el teclat (7 octaves)", 100, 0) { scv.scrollTo(((piano.width - scv.width).coerceAtLeast(0)) * it / 100, 0) }

        scope = "tr."
        c = card(pg, "Transport")
        timeText = tv("0:00.000 / 0:00.000", 22f, TXT, true).apply { typeface = Typeface.MONOSPACE; gravity = android.view.Gravity.CENTER }
        c.addView(timeText, lp(-1, -2, t = dp(6)))
        timeline = TimelineView(this).apply { sr = engine.sr; onSeek = { f -> seek(f) } }
        c.addView(timeline, lp(-1, -2, t = dp(6)))
        slider(c, "Zoom de la línia de temps", 39, 0, { "×${it + 1}" }) { timeline.zoom = (it + 1).toDouble(); timeline.invalidate() }
        btnRow(c, act("⏮ IN", CARD2) { seek(inF()) }, act("▶ / ⏸", GREEN) { togglePlay() },
            act("⏹", CARD2) { userStopped = true; stopPlay() }, act("OUT ⏭", CARD2) { seek(outF()) })
        c.addView(tv("Cursor · moviment fi", 12f, SUB), lp(-1, -2, t = dp(10)))
        btnRow(c, act("−1 s", CARD2) { nudge(-1000) }, act("−100", CARD2) { nudge(-100) }, act("−10", CARD2) { nudge(-10) },
            act("+10", CARD2) { nudge(10) }, act("+100", CARD2) { nudge(100) }, act("+1 s", CARD2) { nudge(1000) })
        c.addView(tv("Marcadors · decideixen des d'on i fins on sona la seqüència (gravació de veu i mescla final)", 12f, SUB), lp(-1, -2, t = dp(10)))
        btnRow(c, act("IN ⟵ aquí", TEAL) { setIn(cursor) }, act("OUT ⟵ aquí", RED) { setOut(cursor) })
        btnRow(c, act("IN −10 ms", CARD2) { setIn(inF() - 10L * engine.sr / 1000) }, act("IN +10 ms", CARD2) { setIn(inF() + 10L * engine.sr / 1000) },
            act("OUT −10 ms", CARD2) { setOut(outF() - 10L * engine.sr / 1000) }, act("OUT +10 ms", CARD2) { setOut(outF() + 10L * engine.sr / 1000) })
        markText = tv("", 13f, SUB); c.addView(markText, lp(-1, -2, t = dp(6)))
        btn(c, "Rang = tota la seqüència", CARD2) { markIn = 0; markOut = -1; engine.playEnd = outF(); engine.loopStart = inF(); saveSeq() }
        chk(c, "Repetir en bucle (IN → OUT)", false) { engine.loop = it }

        scope = "seq."
        c = card(pg, "Seqüència MIDI")
        btnRow(c, act("● Gravar", RED) {
            engine.seqStart = engine.frames; engine.seq = ArrayList(); status.text = "Gravant MIDI…"
        }, act("■ Aturar", CARD2) {
            events = engine.seq?.toList() ?: emptyList(); engine.seq = null; resetRange()
            status.text = "Seqüència: ${events.size} esdeveniments"
        })
        btn(c, "Carregar fitxer MIDI (.mid)") { pickMidi.launch(arrayOf("audio/midi", "audio/mid", "audio/x-midi", "application/x-midi", "*/*")) }
        seqInfo = tv("Seqüència: buida", 13f, SUB); c.addView(seqInfo, lp(-1, -2, t = dp(6)))
        btn(c, "Renderitzar seqüència → WAV (offline)", ORANGE) {
            val (bits, fl) = fmts[fmtSel].second
            val f = outFile("render"); val rate = rates[rateSel]
            val was = pauseForRender()
            val evs = rangeEvents()
            thread {
                try {
                    val irSec = engine.reverb.raw?.let { it.ch[0].size / it.rate.toDouble() } ?: 0.0
                    Renderer.render(engine, evs, rate, f, bits, fl, 3.0 + irSec) { p -> runOnUiThread { status.text = "Renderitzant ${(p * 100).toInt()}%" } }
                    runOnUiThread { status.text = "Fet (rang IN–OUT): ${f.absolutePath}" }
                } catch (e: Throwable) {
                    runOnUiThread { status.text = "Error en el render: ${e.message ?: e.javaClass.simpleName}" }
                } finally { resumeAfterRender(was) }
            }
        }
        btn(c, "● / ■ Gravar la sortida en viu (WAV)", RED) {
            val l = live
            if (l == null) {
                val (bits, fl) = fmts[fmtSel].second
                val f = outFile("live")
                live = LiveRecorder(f, engine.sr, bits, fl).also { audio.rec = it }
                status.text = "Gravant en viu → ${f.name} (a ${engine.sr} Hz)"
            } else {
                audio.rec = null; thread { l.finish(); runOnUiThread { status.text = "Gravació tancada" } }; live = null
            }
        }

        // ================= PÀGINA PISTES
        pg = page(TEAL)
        scope = "all."
        c = card(pg, "Mostres")
        btn(c, "📁 Directori de mostres → TOTES les pistes", TEAL) { target = -1; pick.launch(null) }
        dirLabel(c, "dir.all")
        c.addView(tv("Noms de fitxer: C3.wav, F#4.wav, 60.wav… (C4 = 60). Sense nota al nom, es reparteixen per ordre alfabètic.", 11f, SUB), lp(-1, -2, t = dp(4)))
        for (i in 0 until Engine.TRACKS) {
            val t = engine.tracks[i]
            scope = "t$i."
            c = card(pg, "PISTA ${i + 1}")
            spin(c, (1..16).map { "Canal MIDI $it" }, i) { t.channel = it }
            slider(c, "Volum", 100, 80, { "$it %" }) { t.vol = it / 100.0 }
            slider(c, "Pan", 200, 100, { val v = it - 100; if (v == 0) "centre" else if (v < 0) "E ${-v}" else "D $v" }) { t.pan = (it - 100) / 100.0 }
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val a = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; val b2 = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            chk(a, "Mute", false) { t.mute = it }; chk(b2, "Transients ON", false) { t.fx.on = it }
            row.addView(a, lp(0, -2, weight = 1f)); row.addView(b2, lp(0, -2, weight = 1f)); c.addView(row, lp(-1, -2, t = dp(4)))
            val fxBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
            btn(c, "Transients / saturació (pista ${i + 1}) ▾", CARD2) { fxBox.visibility = if (fxBox.visibility == View.GONE) View.VISIBLE else View.GONE }
            spin(fxBox, listOf("Detecció: Flat", "Detecció: Human", "Detecció: Sybil"), 1) { t.fx.detect = it }
            slider(fxBox, "Sharpen (atac)", 200, 100, { "${it - 100} %" }) { t.fx.sharpen = (it - 100) / 100.0 }
            slider(fxBox, "Sustain (cua)", 200, 100, { "${it - 100} %" }) { t.fx.sustain = (it - 100) / 100.0 }
            slider(fxBox, "Speed (detector)", 100, 50, { "$it %" }) { t.fx.speed = it / 100.0 }
            spin(fxBox, listOf("Saturació: BIT", "Saturació: RECT", "Saturació: FUZZ", "Saturació: SIN", "Saturació: BASS", "Saturació: TUBE"), 3) { t.fx.shape = it }
            slider(fxBox, "Drive (0 = saturació apagada)", 100, 0, { "$it %" }) { t.fx.drive = it / 100.0 }
            slider(fxBox, "Sortida de l'insert", 24, 12, { "${it - 12} dB" }) { t.fx.outDb = it - 12.0 }
            c.addView(fxBox)
            btn(c, "📁 Directori de mostres per a aquesta pista") { target = i; pick.launch(null) }
            dirLabel(c, "dir.t$i")
        }

        // ================= PÀGINA EFECTES
        pg = page(VIOLET)
        scope = "rev."
        c = card(pg, "Reverb de convolució")
        btn(c, "📁 Directori de convolucions (.wir / .wav)", VIOLET) { pickIr.launch(null) }
        dirLabel(c, "dir.ir")
        irAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, irNames)
        irSpinner = Spinner(this).apply {
            adapter = irAdapter; background = rounded(CARD2, 10)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(a: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                    irFiles.getOrNull(pos)?.let { store.put("ir.file", it.uri.toString()); loadIr(it) }
                }
                override fun onNothingSelected(a: AdapterView<*>?) {}
            }
        }
        c.addView(irSpinner, lp(-1, -2, t = dp(8)))
        chk(c, "Reverb activada", true) { engine.reverb.enabled = it }
        slider(c, "Nivell de reverb", 100, 25, { "$it %" }) { engine.reverb.mix = it / 100.0 }

        scope = "comp."
        c = card(pg, "Compressor UREI 1176 · 64 bit")
        spin(c, listOf("4:1", "8:1", "12:1", "20:1", "ALL"), 0) { engine.comp.ratioIdx = it }
        slider(c, "Input", 30, 0, { "+$it dB" }) { engine.comp.inputDb = it.toDouble() }
        slider(c, "Output", 40, 20, { "${it - 20} dB" }) { engine.comp.outputDb = it - 20.0 }
        slider(c, "Attack", 78, 18, { "${20 + it * 10} µs" }) { engine.comp.attackUs = 20.0 + it * 10 }
        slider(c, "Release", 105, 25, { "${50 + it * 10} ms" }) { engine.comp.releaseMs = 50.0 + it * 10 }

        scope = "opto."
        c = card(pg, "Compressor òptic · insert del master")
        c.addView(tv("Estil cèl·lula T4 (LA-2A): alliberament en dues fases amb memòria. Útil per anivellar la mescla amb suavitat.", 11f, SUB))
        chk(c, "Compressor òptic activat", false) { engine.opto.on = it }
        spin(c, listOf("Compress (3:1)", "Limit (10:1)"), 0) { engine.opto.limit = it == 1 }
        slider(c, "Peak Reduction", 100, 50, { "$it" }) { engine.opto.peakRed = it / 100.0 }
        slider(c, "Gain", 24, 6, { "${it - 6} dB" }) { engine.opto.gainDb = it - 6.0 }
        slider(c, "Calidesa (vàlvula)", 100, 0, { "$it %" }) { engine.opto.color = it / 100.0 }
        spin(c, listOf("Posició: abans de l'UREI 1176", "Posició: després de l'UREI 1176"), 0) { engine.optoPos = it }

        // ================= PÀGINA VEU
        pg = page(PINK)
        scope = "voz."
        c = card(pg, "Entrada i gravació")
        devAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, devNames)
        devSpinner = Spinner(this).apply { adapter = devAdapter; background = rounded(CARD2, 10) }
        btn(c, "Actualitza dispositius d'entrada (interfície USB)") { refreshDevs() }
        c.addView(devSpinner, lp(-1, -2, t = dp(8))); refreshDevs()
        chk(c, "Gravar sincronitzat amb la seqüència", true) { syncSeq = it }
        slider(c, "Compensació de latència", 300, 0, { "$it ms" }) { latencyMs = it }
        btnRow(c, act("● Gravar veu", RED) {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startVoice()
            else askMic.launch(Manifest.permission.RECORD_AUDIO)
        }, act("■ Aturar", CARD2) { stopVoice() })
        voiceInfo = tv("Veu gravada: 0.0 s", 13f, SUB); c.addView(voiceInfo, lp(-1, -2, t = dp(6)))

        c = card(pg, "COS · proximitat (micros dinàmics: Shure 588SB, SM58…)")
        c.addView(tv("Un micro cardioide dóna els greus (cos) només a prop: a 5 cm +11 dB a 150 Hz, a 25 cm gairebé res. Aquest filtre restitueix la proximitat segons la física.", 11f, SUB))
        chk(c, "Cos activat", false) { vp.body = it }
        slider(c, "Distància real del micro", 38, 18, { "${2 + it} cm" }) { vp.bodyActualCm = 2.0 + it }
        slider(c, "Distància objectiu", 13, 3, { "${2 + it} cm" }) { vp.bodyTargetCm = 2.0 + it }
        slider(c, "Increment màxim als greus", 12, 9, { "+$it dB" }) { vp.bodyMaxDb = it.toDouble() }

        c = card(pg, "Neteja de la veu")
        chk(c, "Mouth noise (clics de boca)", true) { vp.declick = it }
        chk(c, "Lowend (passa-alts + plosives)", true) { vp.lowend = it }
        chk(c, "Clean (reducció de soroll)", true) { vp.clean = it }
        slider(c, "Reducció de soroll", 18, 6, { "${6 + it} dB" }) { vp.cleanDb = 6.0 + it }
        chk(c, "Breath (respiracions)", true) { vp.breath = it }
        slider(c, "Reducció de respiracions", 24, 9, { "${6 + it} dB" }) { vp.breathDb = 6.0 + it }
        chk(c, "Gate", true) { vp.gate = it }
        slider(c, "Rang del gate", 34, 14, { "${6 + it} dB" }) { vp.gateDb = 6.0 + it }
        chk(c, "Sibilance (de-esser)", true) { vp.deess = it }
        slider(c, "De-esser: reducció màxima", 12, 7, { "${3 + it} dB" }) { vp.deessMax = 3.0 + it }
        chk(c, "Dynamics (nivellador de veu)", true) { vp.dynamics = it }

        c = card(pg, "AIR · vida per a la banda alta del micro")
        c.addView(tv("Recrea els aguts que un micro fosc no capta: genera harmònics a partir de 2,5–7 kHz i hi afegeix un shelf suau. No excita el soroll de les pauses.", 11f, SUB))
        chk(c, "AIR activat", true) { vp.air = it }
        slider(c, "Harmònics (generació d'aguts)", 100, 60, { "$it %" }) { vp.airHarm = it / 100.0 }
        slider(c, "Shelf d'aguts (9 kHz)", 9, 3, { "+$it dB" }) { vp.airShelf = it.toDouble() }
        slider(c, "Freqüència d'inici dels aguts", 16, 6, { "${(6000 + it * 500) / 1000.0} kHz" }) { vp.airFreq = 6000.0 + it * 500 }

        scope = "voz."
        c = card(pg, "Rang de la seqüència · previa · memòria")
        rangeText = tv("", 13f, TXT); c.addView(rangeText)
        c.addView(tv("Els marcadors IN/OUT de la pestanya TOCAR decideixen des d'on i fins on sona la seqüència mentre graves la veu i a la mescla final.", 11f, SUB), lp(-1, -2, t = dp(4)))
        slider(c, "Previa: inici dins del rang", 1200, 0, { "${it / 2.0} s" }) { previewStart = it }
        btn(c, "⚡ Generar previa de 10 s (no destructiva)", PINK) { makePreview() }
        btnRow(c, act("▶ Escoltar previa", GREEN) {
            val m = previewMix
            if (m == null) status.text = "Encara no hi ha previa" else player.play(m[0], m[1], engine.sr) { runOnUiThread { status.text = "Escolta de la previa acabada" } }
        }, act("■ Parar", CARD2) { player.stop() })
        cacheInfo = tv("", 12f, SUB)
        chk(c, "Conservar la veu gravada i el render de música", true) { keepCache = it; onKeepCacheChanged(it) }
        c.addView(cacheInfo, lp(-1, -2, t = dp(2)))
        btn(c, "Esborra el render de música desat", CARD2) { cache.delete(); refreshCacheInfo(); status.text = "Render de música esborrat" }
        refreshCacheInfo()

        c = card(pg, "Mescla amb la música")
        slider(c, "Prevalença de la veu", 100, 50, { if (it < 15) "$it % · integrada" else if (it > 85) "$it % · dominant" else "$it %" }) { vp.prevalence = it / 100.0 }
        slider(c, "Sonoritat final objectiu", 16, 10, { "${-24 + it} LUFS" }) { vp.targetLufs = -24.0 + it }
        btn(c, "⚙ Analitzar i mesclar → WAV", PINK) { processVoice() }
        btnRow(c, act("▶ Escoltar", GREEN) {
            val m = finalMix
            if (m == null) status.text = "Encara no hi ha mescla final"
            else player.play(m[0], m[1], engine.sr) { runOnUiThread { status.text = "Escolta acabada" } }
        }, act("■ Parar", CARD2) { player.stop() })
        voiceReport = tv("", 12f, TXT); c.addView(voiceReport, lp(-1, -2, t = dp(8)))

        // ================= PÀGINA SISTEMA
        pg = page(BLUE)
        scope = "sys."
        c = card(pg, "Format de la gravació WAV")
        spin(c, fmts.map { it.first }, fmtSel) { fmtSel = it }
        spin(c, rates.map { "$it Hz" }, rateSel) { rateSel = it }

        c = card(pg, "Snapshots (paràmetres + directoris)")
        c.addView(tv("L'app desa sola tot l'estat en sortir i el recupera en obrir-la. Aquí pots guardar-ne còpies manuals.", 11f, SUB))
        for (i in 1..4) {
            val info = tv(snapText(i), 12f, SUB)
            c.addView(info, lp(-1, -2, t = dp(10)))
            btnRow(c, act("Desa $i", BLUE) { store.saveSnapshot(i); info.text = snapText(i); status.text = "Snapshot $i desat" },
                act("Carrega $i", CARD2) {
                    val j = store.snapshot(i)
                    if (j == null) status.text = "El snapshot $i és buit" else { applySnapshot(j); status.text = "Snapshot $i carregat" }
                })
        }
        c = card(pg, "Rendiment (si sents talls d'àudio)")
        c.addView(tv("Prova per ordre: àudio Equilibrat o Segur, interpolació Ràpida, convolució 2048, menys fils o una IR de 2 canals (xcd1/mcd1).", 11f, SUB))
        spin(c, listOf("Àudio: mínima latència (128)", "Àudio: equilibrat (256)", "Àudio: segur (512, efectes pesats)"), 1) { applyAudioMode(it) }
        spin(c, listOf("Interpolació: alta (sinc 16)", "Interpolació: ràpida (cúbica)"), 0) { engine.setHq(it == 0) }
        spin(c, listOf("Convolució: partició 512 (21 ms)", "Convolució: partició 1024 (43 ms)", "Convolució: partició 2048 (85 ms, lleuger)"), 0) { setPartition(it) }
        spin(c, listOf("Reverb: 1 fil de treball", "Reverb: 2 fils de treball", "Reverb: 3 fils de treball"), 1) { setWorkers(it + 1) }
        chk(c, "Pausa l'àudio en directe durant renders i previes", true) { autoPause = it }

        c = card(pg, "Protecció i diagnòstic de l'àudio")
        chk(c, "Protecció suau contra retallada de sortida", true) { audio.protect = it }
        diagText = tv("", 12f, TXT).apply { typeface = Typeface.MONOSPACE }
        c.addView(diagText, lp(-1, -2, t = dp(8)))
        c.addView(tv("Toca l'acord problemàtic uns segons i mira quin comptador puja: CPU alta, underruns (talls), pics per sobre de 0 dBFS o veus robades.", 11f, SUB), lp(-1, -2, t = dp(6)))
        btn(c, "Reinicia els comptadors", CARD2) { audio.resetDiag(); engine.resetSteals() }

        c = card(pg, "Estat de l'app")
        c.addView(tv("Memòria disponible per a veu: ~${maxVoiceFrames() / engine.sr} s", 12f, SUB))
        btn(c, "Restaura els valors per defecte", RED) { store.clearState(); File(filesDir, "seq.bin").delete(); recreate() }

        // ---- muntatge final
        val rootView = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG) }
        rootView.addView(top, lp(-1, -2)); rootView.addView(tabBar, lp(-1, -2)); rootView.addView(pagesBox, lp(-1, 0, weight = 1f))
        setContentView(rootView)
        select((store.get("tab")?.toIntOrNull() ?: 0).coerceIn(0, tabs.size - 1))

        // ---- recuperació de l'estat anterior
        setters["dir.all"] = { v -> loadDir(-1, Uri.parse(v), false) }
        for (i in 0 until Engine.TRACKS) setters["dir.t$i"] = { v -> loadDir(i, Uri.parse(v), false) }
        setters["dir.ir"] = { v -> scanIrs(Uri.parse(v), false) }
        setters["ir.file"] = { v ->
            val idx = irFiles.indexOfFirst { it.uri.toString() == v }
            if (idx >= 0) { irSpinner.setSelection(idx); loadIr(irFiles[idx]) } else store.put("ir.file", v)
        }
        loadSeq()
        thread { try { recorder.loadFrom(File(filesDir, "voice.f32")) } catch (_: Throwable) { } }
        restoreDirs()
        midi = MidiIn(this, engine).also { it.start() }
        if (store.get("sys.audio") == "1") startAudio()
        ui.post(tick)
    }

    override fun onPause() { store.saveNow(); super.onPause() }
    override fun onStop() { store.saveNow(); super.onStop() }
    override fun onDestroy() { ui.removeCallbacks(tick); store.saveNow(); audio.stop(); super.onDestroy() }

    // ------------------------------------------------------------------ àudio
    private fun startAudio() { audio.start(); audioBtn.text = "ÀUDIO: ON"; audioBtn.background = rounded(GREEN, 14); store.put("sys.audio", "1") }
    private fun toggleAudio() {
        if (audio.running) { audio.stop(); audioBtn.text = "ÀUDIO: OFF"; audioBtn.background = rounded(CARD2, 14); store.put("sys.audio", "0") }
        else startAudio()
    }

    // ------------------------------------------------------------------ persistència
    private fun diagString(): String =
        ("CPU del bloc : mitjana %3.0f %%  màxim %3.0f %%  (bloc de %d mostres = %.1f ms)\nUnderruns    : %d\nMostres > 0 dBFS : %d\n" +
         "Veus actives : %d   robades: %d\nReverb: blocs perduts %d · nuclis del mòbil: %d")
            .format(audio.diagLoadAvg * 100, audio.diagLoadMax * 100, audio.blockFrames, audio.blockFrames * 1000.0 / engine.sr,
                audio.diagUnderruns, audio.diagOvers, engine.activeVoices(), engine.steals(), engine.reverb.misses, Runtime.getRuntime().availableProcessors())

    // ------------------------------------------------------------------ rendiment
    private fun applyAudioMode(m: Int) {
        audio.configure(m)
        if (audio.running) { audio.stop(); audio.start() }
    }
    private fun reloadReverb() { if (engine.reverb.raw == null) return; thread { try { engine.reverb.reload() } catch (_: Throwable) { } } }
    private fun setPartition(i: Int) { val p = intArrayOf(512, 1024, 2048)[i]; if (engine.reverb.partition != p) { engine.reverb.partition = p; reloadReverb() } }
    private fun setWorkers(n: Int) { if (engine.reverb.workers != n) { engine.reverb.workers = n; reloadReverb() } }

    /** Mentre es renderitza, l'àudio en directe es pausa: així el render té tot el processador i no es compten talls falsos. */
    private fun pauseForRender(): Boolean {
        if (!autoPause || !audio.running) return false
        audio.stop(); audioBtn.text = "ÀUDIO: pausa (render)"; audioBtn.background = rounded(ORANGE, 14)
        return true
    }
    private fun resumeAfterRender(was: Boolean) { if (was) runOnUiThread { startAudio() } }

    private fun snapText(i: Int) = "Snapshot $i · " + (store.snapshotTime(i) ?: "buit")

    private fun applySnapshot(j: JSONObject) {
        val m = LinkedHashMap<String, String>()
        for (k in j.keys()) m[k] = j.getString(k)
        fun prio(k: String) = when { k == "dir.all" -> 0; k.startsWith("dir.t") -> 1; k.startsWith("dir.") -> 2; k == "ir.file" -> 4; else -> 3 }
        for (k in m.keys.sortedBy { prio(it) }) {
            val v = m[k]!!
            if (k == "tab" || k == "sys.audio") continue
            store.put(k, v)
            setters[k]?.invoke(v)
        }
    }

    private fun restoreDirs() {
        val all = store.get("dir.all"); val per = (0 until Engine.TRACKS).map { it to store.get("dir.t$it") }; val ir = store.get("dir.ir")
        thread {
            try {
                all?.let { val (bank, _) = loadBank(Uri.parse(it)); engine.tracks.forEach { t -> t.bank = bank } }
                for ((i, u) in per) u?.let { val (bank, _) = loadBank(Uri.parse(it)); engine.tracks[i].bank = bank }
                runOnUiThread { status.text = "Estat anterior restaurat" }
            } catch (e: Throwable) { runOnUiThread { status.text = "No s'ha pogut llegir un directori desat (torna a triar-lo)" } }
            ir?.let { runOnUiThread { scanIrs(Uri.parse(it), false) } }
        }
    }

    private fun saveSeq() {
        try {
            DataOutputStream(File(filesDir, "seq.bin").outputStream().buffered()).use { o ->
                o.writeInt(events.size)
                for (e in events) { o.writeLong(e.frame); o.writeByte(e.st); o.writeByte(e.a); o.writeByte(e.b) }
                o.writeLong(markIn); o.writeLong(markOut)
            }
        } catch (_: Throwable) { }
    }

    private fun loadSeq() {
        val f = File(filesDir, "seq.bin"); if (!f.exists()) return
        try {
            DataInputStream(f.inputStream().buffered()).use { i ->
                val n = i.readInt(); val l = ArrayList<Ev>(n)
                repeat(n) { l.add(Ev(i.readLong(), i.readUnsignedByte(), i.readUnsignedByte(), i.readUnsignedByte())) }
                events = l
                try { markIn = i.readLong(); markOut = i.readLong() } catch (_: Throwable) { markIn = 0; markOut = -1 }
            }
        } catch (_: Throwable) { }
        cursor = inF()
    }

    private fun resetRange() { markIn = 0; markOut = -1; cursor = 0; engine.playEnd = outF(); engine.loopStart = 0; saveSeq() }

    // ------------------------------------------------------------------ MIDI, fitxers, mostres, IR
    private fun loadMidi(uri: Uri) {
        status.text = "Llegint MIDI…"
        thread {
            try {
                val ev = MidiFile.parse(contentResolver.openInputStream(uri)!!.use { it.readBytes() }, engine.sr)
                runOnUiThread {
                    events = ev; resetRange()
                    val notes = ev.count { (it.st and 0xF0) == 0x90 && it.b > 0 }
                    status.text = "MIDI carregat: $notes notes, %.1f s (canals 1–7 → pistes segons el seu canal)".format((ev.lastOrNull()?.frame ?: 0L) / engine.sr.toDouble())
                }
            } catch (e: Throwable) { runOnUiThread { status.text = "Error MIDI: ${e.message ?: e.javaClass.simpleName}" } }
        }
    }

    private fun outFile(tag: String) = File(getExternalFilesDir(Environment.DIRECTORY_MUSIC), "${tag}_${System.currentTimeMillis()}.wav")

    private fun loadBank(uri: Uri): Pair<SampleBank, Int> {
        val list = DocumentFile.fromTreeUri(this, uri)!!.listFiles()
            .filter { it.name?.endsWith(".wav", true) == true }
            .mapNotNull { f -> try { f.name!! to WavReader.read(contentResolver.openInputStream(f.uri)!!.use { it.readBytes() }) } catch (e: Throwable) { null } }
        return SampleBank().also { it.build(list) } to list.size
    }

    private fun loadDir(t: Int, uri: Uri, userPicked: Boolean) {
        if (userPicked) try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Throwable) { }
        status.text = "Carregant mostres…"
        val key = if (t < 0) "dir.all" else "dir.t$t"
        store.put(key, uri.toString())
        if (t < 0) for (i in 0 until Engine.TRACKS) { store.put("dir.t$i", null); dirLabels["dir.t$i"]?.text = dirName("dir.t$i") }
        dirLabels[key]?.text = dirName(key)
        thread {
            try {
                val (bank, n) = loadBank(uri)
                if (t < 0) engine.tracks.forEach { it.bank = bank } else engine.tracks[t].bank = bank
                runOnUiThread { status.text = "$n mostres carregades (${if (t < 0) "totes les pistes" else "pista ${t + 1}"})" }
            } catch (e: Throwable) { runOnUiThread { status.text = "No es pot llegir el directori: torna a triar-lo" } }
        }
    }

    private fun scanIrs(uri: Uri, userPicked: Boolean) {
        if (userPicked) try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Throwable) { }
        store.put("dir.ir", uri.toString()); dirLabels["dir.ir"]?.text = dirName("dir.ir")
        status.text = "Cercant IR…"
        thread {
            val out = ArrayList<DocumentFile>()
            fun walk(d: DocumentFile, depth: Int) {
                for (f in d.listFiles()) {
                    if (f.isDirectory) { if (depth < 2) walk(f, depth + 1) }
                    else { val n = f.name?.lowercase() ?: continue; if (n.endsWith(".wir") || n.endsWith(".wav")) out.add(f) }
                }
            }
            try { DocumentFile.fromTreeUri(this, uri)?.let { walk(it, 0) } } catch (_: Throwable) { }
            out.sortBy { it.name }
            runOnUiThread {
                irFiles = out
                irNames.clear(); irNames.addAll(out.map { it.name ?: "?" }); irAdapter.notifyDataSetChanged()
                status.text = "${out.size} IR trobades"
                if (out.isNotEmpty()) {
                    val want = store.get("ir.file")
                    val idx = out.indexOfFirst { it.uri.toString() == want }.let { if (it < 0) 0 else it }
                    irSpinner.setSelection(idx, false); loadIr(out[idx])
                }
            }
        }
    }

    private fun loadIr(f: DocumentFile) {
        if (f.uri == loadedIr) return
        loadedIr = f.uri
        runOnUiThread { status.text = "Carregant IR ${f.name}…" }
        thread {
            try {
                val raw = IrLoader.load(contentResolver.openInputStream(f.uri)!!.use { it.readBytes() }, f.name ?: "IR")
                engine.reverb.load(raw)
                val sec = raw.ch[0].size / raw.rate.toDouble()
                runOnUiThread { status.text = "IR: ${raw.name} · ${raw.ch.size} can. · ${raw.rate} Hz · %.2f s".format(sec) }
            } catch (e: Throwable) {
                loadedIr = null
                runOnUiThread { status.text = "Error carregant IR: ${e.message ?: e.javaClass.simpleName}" }
            }
        }
    }

    // ------------------------------------------------------------------ pista de veu
    private fun refreshDevs() {
        devs = AudioDevices.inputs(this)
        devNames.clear(); devNames.add("Entrada per defecte del sistema")
        devNames.addAll(devs.map { AudioDevices.label(it) })
        devAdapter.notifyDataSetChanged()
    }

    private fun maxVoiceFrames(): Long = (Runtime.getRuntime().maxMemory() * 0.6 / 44).toLong()

    // ------------------------------------------------------------------ transport i rang
    private fun seqEnd(): Long = events.lastOrNull()?.frame ?: 0L
    private fun outF(): Long = if (markOut < 0) seqEnd() else markOut
    private fun inF(): Long = min(markIn, outF())
    private fun ft(f: Long): String { val ms = f * 1000 / engine.sr; return "%d:%02d.%03d".format(ms / 60000, (ms / 1000) % 60, ms % 1000) }

    private fun updateTransportUi() {
        val last = max(seqEnd(), outF())
        timeline.total = max(last + engine.sr, 1L); timeline.cursor = cursor; timeline.markIn = inF(); timeline.markOut = outF(); timeline.invalidate()
        timeText.text = "${ft(cursor)} / ${ft(last)}"
        val len = (outF() - inF()) / engine.sr.toDouble()
        markText.text = "IN ${ft(inF())}   OUT ${ft(outF())}   (%.3f s)".format(len)
        rangeText.text = "Rang: IN ${ft(inF())} → OUT ${ft(outF())}  (%.2f s)".format(len)
    }

    private fun playFrom(pos: Long) {
        startAudio()
        engine.playSeq = events; engine.playStart = pos; engine.loopStart = inF(); engine.playEnd = outF(); engine.playCmd = 1
    }
    private fun togglePlay() {
        if (engine.playing) { cursor = engine.playFrame; userStopped = true; engine.playCmd = 2 }
        else {
            if (events.isEmpty()) { status.text = "No hi ha seqüència (grava'n una o carrega un .mid)"; return }
            if (cursor >= outF() || cursor < inF()) cursor = inF()
            playFrom(cursor)
        }
    }
    private fun stopPlay() { engine.playCmd = 2; cursor = inF() }
    private fun seek(f: Long) { cursor = f.coerceIn(0, max(seqEnd(), outF())); if (engine.playing) playFrom(cursor) }
    private fun nudge(ms: Long) = seek(cursor + ms * engine.sr / 1000)
    private fun setIn(f: Long) { markIn = f.coerceIn(0, outF()); engine.loopStart = inF(); saveSeq() }
    private fun setOut(f: Long) { markOut = max(f, inF()); engine.playEnd = outF(); saveSeq() }

    /** Events del rang [IN, OUT) desplaçats a t = 0, més un "all notes off" al final perquè no quedin notes penjades. */
    private fun rangeEvents(): List<Ev> {
        val a = inF(); val b = outF()
        val out = ArrayList<Ev>()
        for (e in events) if (e.frame >= a && e.frame < b) out.add(Ev(e.frame - a, e.st, e.a, e.b))
        for (ch in 0 until 16) out.add(Ev(b - a, 0xB0 or ch, 123, 0))
        return out
    }

    private fun tailFrames(): Int = ((3.0 + (engine.reverb.raw?.let { it.ch[0].size / it.rate.toDouble() } ?: 0.0)) * engine.sr).toInt()

    /** Signatura de tot el que condiciona el render de la música (pistes, reverb, compressors, directoris, events i rang). */
    private fun signature(evs: List<Ev>, frames: Int): String {
        val md = MessageDigest.getInstance("SHA-256")
        md.update("v1|$frames|${engine.sr}|".toByteArray())
        val rel = Regex("^(t\\d\\.|rev\\.|comp\\.|opto\\.|dir\\.|ir\\.file).*")
        for ((k, v) in store.state.toSortedMap()) if (rel.matches(k)) md.update("$k=$v;".toByteArray())
        val bb = java.nio.ByteBuffer.allocate(11)
        for (e in evs) { bb.clear(); bb.putLong(e.frame); bb.put(e.st.toByte()); bb.put(e.a.toByte()); bb.put(e.b.toByte()); md.update(bb.array(), 0, 11) }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    private fun refreshCacheInfo() {
        if (!::cacheInfo.isInitialized) return
        val i = cache.info()
        cacheInfo.text = if (i == null) "Render de música desat: cap" else "Render de música desat: %.0f MB · %.1f s".format(cache.sizeMb(), i.second / engine.sr.toDouble())
    }

    private fun onKeepCacheChanged(on: Boolean) {
        if (!on) { cache.delete(); File(filesDir, "voice.f32").delete() }
        else if (recorder.frames > 0) thread { try { recorder.saveTo(File(filesDir, "voice.f32")) } catch (_: Throwable) { } }
        refreshCacheInfo()
    }

    // ------------------------------------------------------------------ pista de veu
    private fun startVoice() {
        if (busy) return
        startAudio()
        val dev = devs.getOrNull(devSpinner.selectedItemPosition - 1)
        val err = recorder.start(dev, engine.sr, maxVoiceFrames())
        if (err != null) { status.text = err; return }
        store.putLong("voice.recIn", inF())               // la veu enregistrada correspon a la seqüència a partir d'IN
        if (syncSeq && events.isNotEmpty()) { cursor = inF(); playFrom(inF()) }
        status.text = "Gravant veu des de ${ft(inF())} (màxim ${maxVoiceFrames() / engine.sr} s)…"
    }

    private fun stopVoice() {
        recorder.stop(); engine.playCmd = 2; userStopped = true; cursor = inF()
        status.text = "Veu gravada: %.1f s".format(recorder.frames / engine.sr.toDouble())
        if (keepCache) thread { try { recorder.saveTo(File(filesDir, "voice.f32")) } catch (_: Throwable) { } }
    }

    /** Mostra de la gravació que correspon al t = 0 de la mescla (compensa el rang actual respecte al de la gravació i la latència). */
    private fun voiceOffset(): Long = (inF() - store.getLong("voice.recIn", 0L)) + latencyMs.toLong() * engine.sr / 1000

    private fun processVoice() {
        if (busy) return
        if (recorder.recording) stopVoice()
        if (recorder.frames == 0L) { status.text = "Primer grava la veu"; return }
        busy = true; finalMix = null; player.stop()
        val was = pauseForRender()
        val sr = engine.sr
        val vOff = voiceOffset()
        val musicFrames = (outF() - inF()).toInt() + tailFrames()
        val voiceLen = (recorder.frames - vOff).toInt()
        val total = max(musicFrames, voiceLen)
        val evs = rangeEvents()
        thread {
            try {
                if (total.toLong() * 8 * 6 > Runtime.getRuntime().maxMemory() * 0.85) {
                    runOnUiThread { status.text = "Massa llarg per a la memòria d'aquest dispositiu (${total / sr} s, màxim ~${(Runtime.getRuntime().maxMemory() * 0.85 / 48 / sr).toLong()} s)" }
                    return@thread
                }
                val music = arrayOf(DoubleArray(total), DoubleArray(total))
                val sig = signature(evs, musicFrames)
                if (keepCache && cache.valid(sig)) {
                    runOnUiThread { status.text = "Música: es reutilitza el render desat" }
                    cache.read(music[0], music[1], 0, musicFrames)
                } else {
                    Renderer.renderBuffers(engine, evs, musicFrames, { f -> runOnUiThread { status.text = "Renderitzant la música… ${(f * 100).toInt()}%" } }, music)
                    if (keepCache) { try { cache.save(music[0], music[1], musicFrames, sig) } catch (_: Throwable) { } }
                    runOnUiThread { refreshCacheInfo() }
                }
                val voice = recorder.copyRange(vOff, total)
                val rep = VoiceMixer.process(music, voice, vp) { stage, f -> runOnUiThread { status.text = "${(f * 100).toInt()}% · $stage" } }
                val (bits, fl) = fmts[fmtSel].second
                val file = outFile("veu_mix")
                WavWriter(file, sr, bits, fl).use { w ->
                    val tl = DoubleArray(4096); val tr = DoubleArray(4096); var pos = 0
                    while (pos < total) {
                        val n = min(4096, total - pos)
                        System.arraycopy(music[0], pos, tl, 0, n); System.arraycopy(music[1], pos, tr, 0, n)
                        w.write(tl, tr, n); pos += n
                    }
                }
                finalMix = music
                runOnUiThread { voiceReport.text = rep.text; status.text = "Mescla feta: ${file.absolutePath}" }
            } catch (e: Throwable) {
                runOnUiThread { status.text = "Error en la mescla: ${e.message ?: e.javaClass.simpleName}" }
            } finally { busy = false; resumeAfterRender(was) }
        }
    }

    /** Previa de 10 s del renderitzat final, no destructiva: treballa sobre còpies i no escriu cap fitxer. */
    private fun makePreview() {
        if (busy) return
        if (recorder.frames == 0L) { status.text = "Primer grava la veu"; return }
        busy = true; player.stop()
        val was = pauseForRender()
        val sr = engine.sr; val len = 10 * sr
        val vOff = voiceOffset()
        val musicFrames = (outF() - inF()).toInt() + tailFrames()
        val t0 = (previewStart * 0.5 * sr).toInt().coerceIn(0, max(0, musicFrames - 1))
        val evs = rangeEvents()
        thread {
            try {
                val mw = arrayOf(DoubleArray(len), DoubleArray(len))
                val sig = signature(evs, musicFrames)
                if (keepCache && cache.valid(sig)) cache.read(mw[0], mw[1], t0, len)
                else {
                    val upTo = min(musicFrames, t0 + len)
                    val tmp = Renderer.renderBuffers(engine, evs, upTo, { f -> runOnUiThread { status.text = "Previa: renderitzant la música… ${(f * 100).toInt()}%" } })
                    val n = max(0, min(len, upTo - t0))
                    for (k in 0..1) System.arraycopy(tmp[k], t0, mw[k], 0, n)
                }
                val vw = recorder.copyRange(vOff + t0, len)
                val rep = VoiceMixer.process(mw, vw, vp) { stage, f -> runOnUiThread { status.text = "Previa ${(f * 100).toInt()}% · $stage" } }
                previewMix = mw
                runOnUiThread { voiceReport.text = "PREVIA (10 s des de %.1f s; les estadístiques es calculen només sobre aquest tros)\n".format(t0 / sr.toDouble()) + rep.text; status.text = "Previa llesta: prem «Escoltar previa»" }
            } catch (e: Throwable) {
                runOnUiThread { status.text = "Error en la previa: ${e.message ?: e.javaClass.simpleName}" }
            } finally { busy = false; resumeAfterRender(was) }
        }
    }
}
