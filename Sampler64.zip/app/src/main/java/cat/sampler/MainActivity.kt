package cat.sampler

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioDeviceInfo
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.documentfile.provider.DocumentFile
import org.json.JSONObject
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min

/** Estat persistent: tots els controls (clau estable -> valor) i 4 snapshots manuals. */
class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("sampler64", Context.MODE_PRIVATE)
    val state = LinkedHashMap<String, String>()
    private val h = Handler(Looper.getMainLooper())
    private val saver = Runnable { saveNow() }

    init {
        try { val j = JSONObject(sp.getString("state", "{}")!!); for (k in j.keys()) state[k] = j.getString(k) } catch (_: Throwable) { }
    }

    fun get(k: String): String? = state[k]
    fun put(k: String, v: String?) {
        if (v == null) state.remove(k) else state[k] = v
        h.removeCallbacks(saver); h.postDelayed(saver, 600)
    }
    fun saveNow() { h.removeCallbacks(saver); sp.edit().putString("state", JSONObject(state as Map<*, *>).toString()).apply() }
    fun saveSnapshot(i: Int) {
        sp.edit().putString("snap$i", JSONObject(state as Map<*, *>).toString())
            .putString("snapT$i", SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date())).apply()
    }
    fun snapshot(i: Int): JSONObject? = try { sp.getString("snap$i", null)?.let { JSONObject(it) } } catch (_: Throwable) { null }
    fun snapshotTime(i: Int): String? = sp.getString("snapT$i", null)
    fun clearState() { state.clear(); sp.edit().remove("state").apply() }
}

class MainActivity : ComponentActivity() {
    // ---- paleta
    private val BG = Color.parseColor("#0E1116"); private val PANEL = Color.parseColor("#141922"); private val CARD = Color.parseColor("#1A202B")
    private val CARD2 = Color.parseColor("#252D3B"); private val TXT = Color.parseColor("#ECEFF4"); private val SUB = Color.parseColor("#9AA5B8")
    private val ORANGE = Color.parseColor("#FF9F1C"); private val TEAL = Color.parseColor("#2EC4B6"); private val VIOLET = Color.parseColor("#8B7BFF")
    private val PINK = Color.parseColor("#FF4D8D"); private val BLUE = Color.parseColor("#4DA3FF"); private val RED = Color.parseColor("#E5484D"); private val GREEN = Color.parseColor("#30A46C")

    private val engine = Engine(48000)
    private val audio = AudioOut(engine)
    private lateinit var midi: MidiIn
    private lateinit var status: TextView
    private lateinit var store: Store
    private val setters = HashMap<String, (String) -> Unit>()
    private var scope = ""
    private var accent = ORANGE

    private val fmts = listOf("16 bit int" to (16 to false), "24 bit int" to (24 to false), "32 bit int" to (32 to false),
        "32 bit float" to (32 to true), "64 bit float (IEEE)" to (64 to true))
    private val rates = listOf(44100, 48000, 88200, 96000, 192000)
    private var fmtSel = 4
    private var rateSel = 1
    private var target = -1
    private var events: List<Ev> = emptyList()
    private var live: LiveRecorder? = null
    private lateinit var seqInfo: TextView
    private lateinit var audioBtn: Button
    private val dirLabels = HashMap<String, TextView>()

    // pista de veu
    private val vp = VoiceParams()
    private val recorder = VoiceRecorder()
    private val player = MixPlayer()
    private var devs: List<AudioDeviceInfo> = emptyList()
    private val devNames = ArrayList<String>()
    private lateinit var devAdapter: ArrayAdapter<String>
    private lateinit var devSpinner: Spinner
    private lateinit var voiceInfo: TextView
    private lateinit var voiceReport: TextView
    private var dispIn = 0.0
    private var latencyMs = 0
    private var syncSeq = true
    private var finalMix: Array<DoubleArray>? = null
    @Volatile private var busy = false

    // vúmetres
    private lateinit var meterL: MeterView
    private lateinit var meterR: MeterView
    private lateinit var meterGr: MeterView
    private lateinit var meterIn: MeterView
    private val ui = Handler(Looper.getMainLooper())
    private var dispL = 0.0
    private var dispR = 0.0
    private var dispGr = 0.0

    // biblioteca d'IR
    private var irFiles: List<DocumentFile> = emptyList()
    private val irNames = ArrayList<String>()
    private lateinit var irAdapter: ArrayAdapter<String>
    private lateinit var irSpinner: Spinner
    private var loadedIr: Uri? = null

    private val tick = object : Runnable {
        override fun run() {
            val pk = engine.takePeaks()
            dispL = max(pk[0], dispL * 0.93); dispR = max(pk[1], dispR * 0.93)
            showOut(meterL, dispL); showOut(meterR, dispR)
            val g = engine.comp.grDb
            dispGr = if (g > dispGr) g else dispGr * 0.85 + g * 0.15
            meterGr.level = dispGr / 24.0; meterGr.text = "-%.1f dB".format(dispGr); meterGr.invalidate()
            seqInfo.text = seqText()
            dispIn = max(recorder.takePeak(), dispIn * 0.93); showOut(meterIn, dispIn)
            voiceInfo.text = if (recorder.recording) "● Gravant veu: %.1f s".format(recorder.frames / engine.sr.toDouble())
                             else "Veu gravada: %.1f s".format(recorder.frames / engine.sr.toDouble())
            ui.postDelayed(this, 33)
        }
    }

    private fun seqText(): String {
        val len = (events.lastOrNull()?.frame ?: 0L) / engine.sr.toDouble()
        return if (engine.playing) "▶ %.1f / %.1f s".format(engine.playFrame / engine.sr.toDouble(), len)
        else "Seqüència: ${events.size} esdeveniments, %.1f s".format(len)
    }

    private fun showOut(m: MeterView, peak: Double) {
        val db = 20 * log10(max(peak, 1e-6))
        m.level = (db + 60) / 60; m.hot = peak >= 1.0
        m.text = if (peak >= 1.0) "CLIP" else "%.1f dB".format(db)
        m.invalidate()
    }

    private val askMic = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startVoice() else status.text = "Cal el permís de micròfon per gravar la veu"
    }
    private val pickMidi = registerForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let { u -> loadMidi(u) } }
    private val pickIr = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { it?.let { u -> scanIrs(u, true) } }
    private val pick = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { it?.let { u -> loadDir(target, u, true) } }

    // ------------------------------------------------------------------ helpers de disseny
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(c: Int, r: Int = 14) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat() }
    private fun lp(w: Int, h: Int, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0, weight: Float = 0f) =
        LinearLayout.LayoutParams(w, h, weight).apply { setMargins(l, t, r, b) }
    private fun tv(text: CharSequence, size: Float = 14f, color: Int = TXT, bold: Boolean = false) =
        TextView(this).apply { this.text = text; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD }

    private fun card(parent: LinearLayout, title: String): LinearLayout {
        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rounded(CARD, 16); setPadding(dp(14), dp(12), dp(14), dp(14)) }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL }
        head.addView(View(this).apply { background = rounded(accent, 3) }, lp(dp(5), dp(20), r = dp(10)))
        head.addView(tv(title, 15f, accent, true))
        c.addView(head)
        parent.addView(c, lp(-1, -2, b = dp(12)))
        return c
    }

    private fun mkBtn(text: String, color: Int, f: () -> Unit) = Button(this).apply {
        this.text = text; isAllCaps = false; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; textSize = 14f
        background = rounded(color, 14); minHeight = dp(46); minimumHeight = dp(46); setPadding(dp(12), 0, dp(12), 0)
        setOnClickListener { f() }
    }
    private fun btn(p: LinearLayout, text: String, color: Int = CARD2, f: () -> Unit): Button =
        mkBtn(text, color, f).also { p.addView(it, lp(-1, -2, t = dp(8))) }
    private fun act(text: String, color: Int, f: () -> Unit) = Triple(text, color, f)
    private fun btnRow(p: LinearLayout, vararg items: Triple<String, Int, () -> Unit>) {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((i, item) in items.withIndex()) r.addView(mkBtn(item.first, item.second, item.third), lp(0, -2, l = if (i > 0) dp(8) else 0, weight = 1f))
        p.addView(r, lp(-1, -2, t = dp(8)))
    }

    private fun slider(p: LinearLayout, label: String, max: Int, def: Int, fmt: (Int) -> String = { it.toString() }, cb: (Int) -> Unit): SeekBar {
        val key = scope + label
        val init = (store.get(key)?.toIntOrNull() ?: def).coerceIn(0, max)
        val value = tv(fmt(init), 13f, accent, true)
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        head.addView(tv(label, 13f, SUB), lp(0, -2, weight = 1f)); head.addView(value)
        val sb = SeekBar(this).apply {
            this.max = max; progress = init
            progressTintList = ColorStateList.valueOf(accent); thumbTintList = ColorStateList.valueOf(accent)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, v: Int, u: Boolean) { value.text = fmt(v); store.put(key, v.toString()); cb(v) }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }
        setters[key] = { v -> v.toIntOrNull()?.let { sb.progress = it.coerceIn(0, max) } }
        p.addView(head, lp(-1, -2, t = dp(8))); p.addView(sb)
        cb(init)
        return sb
    }

    private fun chk(p: LinearLayout, label: String, def: Boolean, cb: (Boolean) -> Unit): CheckBox {
        val key = scope + label
        val init = store.get(key)?.let { it == "1" } ?: def
        val c = CheckBox(this).apply {
            text = label; setTextColor(TXT); buttonTintList = ColorStateList.valueOf(accent); isChecked = init
            setOnCheckedChangeListener { _, v -> store.put(key, if (v) "1" else "0"); cb(v) }
        }
        setters[key] = { v -> c.isChecked = (v == "1") }
        p.addView(c); cb(init)
        return c
    }

    private fun spin(p: LinearLayout, items: List<String>, def: Int, cb: (Int) -> Unit): Spinner {
        val key = scope + "spin:" + items.first()
        val init = (store.get(key)?.toIntOrNull() ?: def).coerceIn(0, items.size - 1)
        val s = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
            background = rounded(CARD2, 10); setSelection(init)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(a: AdapterView<*>?, v: View?, pos: Int, id: Long) { store.put(key, pos.toString()); cb(pos) }
                override fun onNothingSelected(a: AdapterView<*>?) {}
            }
        }
        setters[key] = { v -> v.toIntOrNull()?.let { s.setSelection(it.coerceIn(0, items.size - 1)) } }
        p.addView(s, lp(-1, -2, t = dp(8))); cb(init)
        return s
    }

    private fun dirLabel(p: LinearLayout, key: String) {
        val l = tv(dirName(key), 12f, SUB); dirLabels[key] = l; p.addView(l, lp(-1, -2, t = dp(4)))
    }
    private fun dirName(key: String): String {
        val u = store.get(key) ?: return "📁 (cap directori)"
        return "📁 " + (try { DocumentFile.fromTreeUri(this, Uri.parse(u))?.name } catch (_: Throwable) { null } ?: "?")
    }

    // ------------------------------------------------------------------ construcció de la interfície
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        store = Store(this)
        window.decorView.setBackgroundColor(BG)

        // panell fix superior: títol, àudio, vúmetres i estat
        val top = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(PANEL); setPadding(dp(14), dp(8), dp(14), dp(6)) }
        val title = SpannableStringBuilder("SAMPLER64").apply { setSpan(ForegroundColorSpan(ORANGE), 7, 9, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE) }
        val headRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL }
        headRow.addView(tv(title, 20f, TXT, true), lp(0, -2, weight = 1f))
        audioBtn = mkBtn("ÀUDIO: OFF", CARD2) { toggleAudio() }
        headRow.addView(audioBtn, lp(-2, dp(40)))
        top.addView(headRow, lp(-1, -2))
        meterL = MeterView(this, "OUT L"); meterR = MeterView(this, "OUT R"); meterGr = MeterView(this, "GR", gr = true); meterIn = MeterView(this, "MIC")
        for (m in listOf(meterL, meterR, meterGr, meterIn)) top.addView(m, lp(-1, -2))
        status = tv("Llest. Connecta un teclat MIDI o fes servir el teclat en pantalla.", 12f, SUB)
        top.addView(status, lp(-1, -2, t = dp(2)))

        // pestanyes
        val tabs = listOf("TOCAR" to ORANGE, "PISTES" to TEAL, "EFECTES" to VIOLET, "VEU" to PINK, "SISTEMA" to BLUE)
        val tabBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(dp(8), dp(6), dp(8), dp(6)); setBackgroundColor(PANEL) }
        val pagesBox = FrameLayout(this)
        val pages = ArrayList<ScrollView>(); val tabBtns = ArrayList<Button>()
        fun select(i: Int) {
            for (j in pages.indices) {
                pages[j].visibility = if (j == i) View.VISIBLE else View.GONE
                tabBtns[j].background = rounded(if (j == i) tabs[j].second else CARD2, 10)
                tabBtns[j].setTextColor(if (j == i) Color.BLACK else SUB)
            }
            store.put("tab", i.toString())
        }
        for ((i, t) in tabs.withIndex()) {
            val b = mkBtn(t.first, CARD2) { select(i) }.apply { textSize = 12f; minHeight = dp(40); minimumHeight = dp(40); setPadding(0, 0, 0, 0) }
            tabBtns.add(b); tabBar.addView(b, lp(0, -2, l = if (i > 0) dp(6) else 0, weight = 1f))
        }
        fun page(color: Int): LinearLayout {
            accent = color
            val inner = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(12), dp(12), dp(24)) }
            val sv = ScrollView(this).apply { addView(inner); visibility = View.GONE }
            pages.add(sv); pagesBox.addView(sv, FrameLayout.LayoutParams(-1, -1))
            return inner
        }

        // ================= PÀGINA TOCAR
        var pg = page(ORANGE)
        scope = "kb."
        var c = card(pg, "Teclat en pantalla")
        var kbTrack = 0
        spin(c, (1..Engine.TRACKS).map { "Teclat → pista $it" }, 0) { kbTrack = it }
        val piano = PianoView(this) { n, down ->
            val ch = engine.tracks[kbTrack].channel
            engine.midi((if (down) 0x90 else 0x80) or ch, n, if (down) 100 else 0)
        }
        val scv = HorizontalScrollView(this).apply { addView(piano); setBackgroundColor(BG) }
        c.addView(scv, lp(-1, -2, t = dp(8)))
        slider(c, "Desplaça el teclat (7 octaves)", 100, 0) { scv.scrollTo(((piano.width - scv.width).coerceAtLeast(0)) * it / 100, 0) }

        scope = "seq."
        c = card(pg, "Seqüència MIDI")
        btnRow(c, act("● Gravar", RED) {
            engine.seqStart = engine.frames; engine.seq = ArrayList(); status.text = "Gravant MIDI…"
        }, act("■ Aturar", CARD2) {
            events = engine.seq?.toList() ?: emptyList(); engine.seq = null; saveSeq()
            status.text = "Seqüència: ${events.size} esdeveniments"
        })
        btnRow(c, act("▶ Reproduir", GREEN) {
            if (events.isEmpty()) status.text = "No hi ha seqüència (grava'n una o carrega un .mid)"
            else { startAudio(); engine.playSeq = events; engine.playCmd = 1 }
        }, act("■ Parar", CARD2) { engine.playCmd = 2 })
        chk(c, "Repetir en bucle", false) { engine.loop = it }
        btn(c, "Carregar fitxer MIDI (.mid)") { pickMidi.launch(arrayOf("audio/midi", "audio/mid", "audio/x-midi", "application/x-midi", "*/*")) }
        seqInfo = tv("Seqüència: buida", 13f, SUB); c.addView(seqInfo, lp(-1, -2, t = dp(6)))
        btn(c, "Renderitzar seqüència → WAV (offline)", ORANGE) {
            val (bits, fl) = fmts[fmtSel].second
            val f = outFile("render"); val rate = rates[rateSel]
            thread {
                val irSec = engine.reverb.raw?.let { it.ch[0].size / it.rate.toDouble() } ?: 0.0
                Renderer.render(engine, events, rate, f, bits, fl, 3.0 + irSec) { p -> runOnUiThread { status.text = "Renderitzant ${(p * 100).toInt()}%" } }
                runOnUiThread { status.text = "Fet: ${f.absolutePath}" }
            }
        }
        btn(c, "● / ■ Gravar la sortida en viu (WAV)", RED) {
            val l = live
            if (l == null) {
                val (bits, fl) = fmts[fmtSel].second
                val f = outFile("live")
                live = LiveRecorder(f, engine.sr, bits, fl).also { audio.rec = it }
                status.text = "Gravant en viu → ${f.name} (a ${engine.sr} Hz)"
            } else {
                audio.rec = null; thread { l.finish(); runOnUiThread { status.text = "Gravació tancada" } }; live = null
            }
        }

        // ================= PÀGINA PISTES
        pg = page(TEAL)
        scope = "all."
        c = card(pg, "Mostres")
        btn(c, "📁 Directori de mostres → TOTES les pistes", TEAL) { target = -1; pick.launch(null) }
        dirLabel(c, "dir.all")
        c.addView(tv("Noms de fitxer: C3.wav, F#4.wav, 60.wav… (C4 = 60). Sense nota al nom, es reparteixen per ordre alfabètic.", 11f, SUB), lp(-1, -2, t = dp(4)))
        for (i in 0 until Engine.TRACKS) {
            val t = engine.tracks[i]
            scope = "t$i."
            c = card(pg, "PISTA ${i + 1}")
            spin(c, (1..16).map { "Canal MIDI $it" }, i) { t.channel = it }
            slider(c, "Volum", 100, 80, { "$it %" }) { t.vol = it / 100.0 }
            slider(c, "Pan", 200, 100, { val v = it - 100; if (v == 0) "centre" else if (v < 0) "E ${-v}" else "D $v" }) { t.pan = (it - 100) / 100.0 }
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val a = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; val b2 = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            chk(a, "Mute", false) { t.mute = it }; chk(b2, "Transients ON", false) { t.fx.on = it }
            row.addView(a, lp(0, -2, weight = 1f)); row.addView(b2, lp(0, -2, weight = 1f)); c.addView(row, lp(-1, -2, t = dp(4)))
            val fxBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
            btn(c, "Transients / saturació (pista ${i + 1}) ▾", CARD2) { fxBox.visibility = if (fxBox.visibility == View.GONE) View.VISIBLE else View.GONE }
            spin(fxBox, listOf("Detecció: Flat", "Detecció: Human", "Detecció: Sybil"), 1) { t.fx.detect = it }
            slider(fxBox, "Sharpen (atac)", 200, 100, { "${it - 100} %" }) { t.fx.sharpen = (it - 100) / 100.0 }
            slider(fxBox, "Sustain (cua)", 200, 100, { "${it - 100} %" }) { t.fx.sustain = (it - 100) / 100.0 }
            slider(fxBox, "Speed (detector)", 100, 50, { "$it %" }) { t.fx.speed = it / 100.0 }
            spin(fxBox, listOf("Saturació: BIT", "Saturació: RECT", "Saturació: FUZZ", "Saturació: SIN", "Saturació: BASS", "Saturació: TUBE"), 3) { t.fx.shape = it }
            slider(fxBox, "Drive (0 = saturació apagada)", 100, 0, { "$it %" }) { t.fx.drive = it / 100.0 }
            slider(fxBox, "Sortida de l'insert", 24, 12, { "${it - 12} dB" }) { t.fx.outDb = it - 12.0 }
            c.addView(fxBox)
            btn(c, "📁 Directori de mostres per a aquesta pista") { target = i; pick.launch(null) }
            dirLabel(c, "dir.t$i")
        }

        // ================= PÀGINA EFECTES
        pg = page(VIOLET)
        scope = "rev."
        c = card(pg, "Reverb de convolució")
        btn(c, "📁 Directori de convolucions (.wir / .wav)", VIOLET) { pickIr.launch(null) }
        dirLabel(c, "dir.ir")
        irAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, irNames)
        irSpinner = Spinner(this).apply {
            adapter = irAdapter; background = rounded(CARD2, 10)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(a: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                    irFiles.getOrNull(pos)?.let { store.put("ir.file", it.uri.toString()); loadIr(it) }
                }
                override fun onNothingSelected(a: AdapterView<*>?) {}
            }
        }
        c.addView(irSpinner, lp(-1, -2, t = dp(8)))
        chk(c, "Reverb activada", true) { engine.reverb.enabled = it }
        slider(c, "Nivell de reverb", 100, 25, { "$it %" }) { engine.reverb.mix = it / 100.0 }

        scope = "comp."
        c = card(pg, "Compressor UREI 1176 · 64 bit")
        spin(c, listOf("4:1", "8:1", "12:1", "20:1", "ALL"), 0) { engine.comp.ratioIdx = it }
        slider(c, "Input", 30, 0, { "+$it dB" }) { engine.comp.inputDb = it.toDouble() }
        slider(c, "Output", 40, 20, { "${it - 20} dB" }) { engine.comp.outputDb = it - 20.0 }
        slider(c, "Attack", 78, 18, { "${20 + it * 10} µs" }) { engine.comp.attackUs = 20.0 + it * 10 }
        slider(c, "Release", 105, 25, { "${50 + it * 10} ms" }) { engine.comp.releaseMs = 50.0 + it * 10 }

        // ================= PÀGINA VEU
        pg = page(PINK)
        scope = "voz."
        c = card(pg, "Entrada i gravació")
        devAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, devNames)
        devSpinner = Spinner(this).apply { adapter = devAdapter; background = rounded(CARD2, 10) }
        btn(c, "Actualitza dispositius d'entrada (interfície USB)") { refreshDevs() }
        c.addView(devSpinner, lp(-1, -2, t = dp(8))); refreshDevs()
        chk(c, "Gravar sincronitzat amb la seqüència", true) { syncSeq = it }
        slider(c, "Compensació de latència", 300, 0, { "$it ms" }) { latencyMs = it }
        btnRow(c, act("● Gravar veu", RED) {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startVoice()
            else askMic.launch(Manifest.permission.RECORD_AUDIO)
        }, act("■ Aturar", CARD2) { stopVoice() })
        voiceInfo = tv("Veu gravada: 0.0 s", 13f, SUB); c.addView(voiceInfo, lp(-1, -2, t = dp(6)))

        c = card(pg, "Neteja de la veu")
        chk(c, "Mouth noise (clics de boca)", true) { vp.declick = it }
        chk(c, "Lowend (passa-alts + plosives)", true) { vp.lowend = it }
        chk(c, "Clean (reducció de soroll)", true) { vp.clean = it }
        slider(c, "Reducció de soroll", 18, 6, { "${6 + it} dB" }) { vp.cleanDb = 6.0 + it }
        chk(c, "Breath (respiracions)", true) { vp.breath = it }
        chk(c, "Gate", true) { vp.gate = it }
        slider(c, "Rang del gate", 34, 14, { "${6 + it} dB" }) { vp.gateDb = 6.0 + it }
        chk(c, "Sibilance (de-esser)", true) { vp.deess = it }
        slider(c, "De-esser: reducció màxima", 12, 7, { "${3 + it} dB" }) { vp.deessMax = 3.0 + it }
        chk(c, "Dynamics (nivellador de veu)", true) { vp.dynamics = it }

        c = card(pg, "AIR · vida per a la banda alta del micro")
        c.addView(tv("Recrea els aguts que un micro fosc no capta: genera harmònics a partir de 2,5–7 kHz i hi afegeix un shelf suau. No excita el soroll de les pauses.", 11f, SUB))
        chk(c, "AIR activat", true) { vp.air = it }
        slider(c, "Harmònics (generació d'aguts)", 100, 60, { "$it %" }) { vp.airHarm = it / 100.0 }
        slider(c, "Shelf d'aguts (9 kHz)", 9, 3, { "+$it dB" }) { vp.airShelf = it.toDouble() }
        slider(c, "Freqüència d'inici dels aguts", 16, 6, { "${(6000 + it * 500) / 1000.0} kHz" }) { vp.airFreq = 6000.0 + it * 500 }

        c = card(pg, "Mescla amb la música")
        slider(c, "Prevalença de la veu", 100, 50, { if (it < 15) "$it % · integrada" else if (it > 85) "$it % · dominant" else "$it %" }) { vp.prevalence = it / 100.0 }
        slider(c, "Sonoritat final objectiu", 16, 10, { "${-24 + it} LUFS" }) { vp.targetLufs = -24.0 + it }
        btn(c, "⚙ Analitzar i mesclar → WAV", PINK) { processVoice() }
        btnRow(c, act("▶ Escoltar", GREEN) {
            val m = finalMix
            if (m == null) status.text = "Encara no hi ha mescla final"
            else player.play(m[0], m[1], engine.sr) { runOnUiThread { status.text = "Escolta acabada" } }
        }, act("■ Parar", CARD2) { player.stop() })
        voiceReport = tv("", 12f, TXT); c.addView(voiceReport, lp(-1, -2, t = dp(8)))

        // ================= PÀGINA SISTEMA
        pg = page(BLUE)
        scope = "sys."
        c = card(pg, "Format de la gravació WAV")
        spin(c, fmts.map { it.first }, fmtSel) { fmtSel = it }
        spin(c, rates.map { "$it Hz" }, rateSel) { rateSel = it }

        c = card(pg, "Snapshots (paràmetres + directoris)")
        c.addView(tv("L'app desa sola tot l'estat en sortir i el recupera en obrir-la. Aquí pots guardar-ne còpies manuals.", 11f, SUB))
        for (i in 1..4) {
            val info = tv(snapText(i), 12f, SUB)
            c.addView(info, lp(-1, -2, t = dp(10)))
            btnRow(c, act("Desa $i", BLUE) { store.saveSnapshot(i); info.text = snapText(i); status.text = "Snapshot $i desat" },
                act("Carrega $i", CARD2) {
                    val j = store.snapshot(i)
                    if (j == null) status.text = "El snapshot $i és buit" else { applySnapshot(j); status.text = "Snapshot $i carregat" }
                })
        }
        c = card(pg, "Estat de l'app")
        c.addView(tv("Memòria disponible per a veu: ~${maxVoiceFrames() / engine.sr} s", 12f, SUB))
        btn(c, "Restaura els valors per defecte", RED) { store.clearState(); File(filesDir, "seq.bin").delete(); recreate() }

        // ---- muntatge final
        val rootView = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG) }
        rootView.addView(top, lp(-1, -2)); rootView.addView(tabBar, lp(-1, -2)); rootView.addView(pagesBox, lp(-1, 0, weight = 1f))
        setContentView(rootView)
        select((store.get("tab")?.toIntOrNull() ?: 0).coerceIn(0, tabs.size - 1))

        // ---- recuperació de l'estat anterior
        setters["dir.all"] = { v -> loadDir(-1, Uri.parse(v), false) }
        for (i in 0 until Engine.TRACKS) setters["dir.t$i"] = { v -> loadDir(i, Uri.parse(v), false) }
        setters["dir.ir"] = { v -> scanIrs(Uri.parse(v), false) }
        setters["ir.file"] = { v ->
            val idx = irFiles.indexOfFirst { it.uri.toString() == v }
            if (idx >= 0) { irSpinner.setSelection(idx); loadIr(irFiles[idx]) } else store.put("ir.file", v)
        }
        loadSeq()
        thread { try { recorder.loadFrom(File(filesDir, "voice.f32")) } catch (_: Throwable) { } }
        restoreDirs()
        midi = MidiIn(this, engine).also { it.start() }
        if (store.get("sys.audio") == "1") startAudio()
        ui.post(tick)
    }

    override fun onPause() { store.saveNow(); super.onPause() }
    override fun onStop() { store.saveNow(); super.onStop() }
    override fun onDestroy() { ui.removeCallbacks(tick); store.saveNow(); audio.stop(); super.onDestroy() }

    // ------------------------------------------------------------------ àudio
    private fun startAudio() { audio.start(); audioBtn.text = "ÀUDIO: ON"; audioBtn.background = rounded(GREEN, 14); store.put("sys.audio", "1") }
    private fun toggleAudio() {
        if (audio.running) { audio.stop(); audioBtn.text = "ÀUDIO: OFF"; audioBtn.background = rounded(CARD2, 14); store.put("sys.audio", "0") }
        else startAudio()
    }

    // ------------------------------------------------------------------ persistència
    private fun snapText(i: Int) = "Snapshot $i · " + (store.snapshotTime(i) ?: "buit")

    private fun applySnapshot(j: JSONObject) {
        val m = LinkedHashMap<String, String>()
        for (k in j.keys()) m[k] = j.getString(k)
        fun prio(k: String) = when { k == "dir.all" -> 0; k.startsWith("dir.t") -> 1; k.startsWith("dir.") -> 2; k == "ir.file" -> 4; else -> 3 }
        for (k in m.keys.sortedBy { prio(it) }) {
            val v = m[k]!!
            if (k == "tab" || k == "sys.audio") continue
            store.put(k, v)
            setters[k]?.invoke(v)
        }
    }

    private fun restoreDirs() {
        val all = store.get("dir.all"); val per = (0 until Engine.TRACKS).map { it to store.get("dir.t$it") }; val ir = store.get("dir.ir")
        thread {
            try {
                all?.let { val (bank, _) = loadBank(Uri.parse(it)); engine.tracks.forEach { t -> t.bank = bank } }
                for ((i, u) in per) u?.let { val (bank, _) = loadBank(Uri.parse(it)); engine.tracks[i].bank = bank }
                runOnUiThread { status.text = "Estat anterior restaurat" }
            } catch (e: Throwable) { runOnUiThread { status.text = "No s'ha pogut llegir un directori desat (torna a triar-lo)" } }
            ir?.let { runOnUiThread { scanIrs(Uri.parse(it), false) } }
        }
    }

    private fun saveSeq() {
        try {
            DataOutputStream(File(filesDir, "seq.bin").outputStream().buffered()).use { o ->
                o.writeInt(events.size)
                for (e in events) { o.writeLong(e.frame); o.writeByte(e.st); o.writeByte(e.a); o.writeByte(e.b) }
            }
        } catch (_: Throwable) { }
    }

    private fun loadSeq() {
        val f = File(filesDir, "seq.bin"); if (!f.exists()) return
        try {
            DataInputStream(f.inputStream().buffered()).use { i ->
                val n = i.readInt(); val l = ArrayList<Ev>(n)
                repeat(n) { l.add(Ev(i.readLong(), i.readUnsignedByte(), i.readUnsignedByte(), i.readUnsignedByte())) }
                events = l
            }
        } catch (_: Throwable) { }
    }

    // ------------------------------------------------------------------ MIDI, fitxers, mostres, IR
    private fun loadMidi(uri: Uri) {
        status.text = "Llegint MIDI…"
        thread {
            try {
                val ev = MidiFile.parse(contentResolver.openInputStream(uri)!!.use { it.readBytes() }, engine.sr)
                runOnUiThread {
                    events = ev; saveSeq()
                    val notes = ev.count { (it.st and 0xF0) == 0x90 && it.b > 0 }
                    status.text = "MIDI carregat: $notes notes, %.1f s (canals 1–7 → pistes segons el seu canal)".format((ev.lastOrNull()?.frame ?: 0L) / engine.sr.toDouble())
                }
            } catch (e: Throwable) { runOnUiThread { status.text = "Error MIDI: ${e.message ?: e.javaClass.simpleName}" } }
        }
    }

    private fun outFile(tag: String) = File(getExternalFilesDir(Environment.DIRECTORY_MUSIC), "${tag}_${System.currentTimeMillis()}.wav")

    private fun loadBank(uri: Uri): Pair<SampleBank, Int> {
        val list = DocumentFile.fromTreeUri(this, uri)!!.listFiles()
            .filter { it.name?.endsWith(".wav", true) == true }
            .mapNotNull { f -> try { f.name!! to WavReader.read(contentResolver.openInputStream(f.uri)!!.use { it.readBytes() }) } catch (e: Throwable) { null } }
        return SampleBank().also { it.build(list) } to list.size
    }

    private fun loadDir(t: Int, uri: Uri, userPicked: Boolean) {
        if (userPicked) try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Throwable) { }
        status.text = "Carregant mostres…"
        val key = if (t < 0) "dir.all" else "dir.t$t"
        store.put(key, uri.toString())
        if (t < 0) for (i in 0 until Engine.TRACKS) { store.put("dir.t$i", null); dirLabels["dir.t$i"]?.text = dirName("dir.t$i") }
        dirLabels[key]?.text = dirName(key)
        thread {
            try {
                val (bank, n) = loadBank(uri)
                if (t < 0) engine.tracks.forEach { it.bank = bank } else engine.tracks[t].bank = bank
                runOnUiThread { status.text = "$n mostres carregades (${if (t < 0) "totes les pistes" else "pista ${t + 1}"})" }
            } catch (e: Throwable) { runOnUiThread { status.text = "No es pot llegir el directori: torna a triar-lo" } }
        }
    }

    private fun scanIrs(uri: Uri, userPicked: Boolean) {
        if (userPicked) try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Throwable) { }
        store.put("dir.ir", uri.toString()); dirLabels["dir.ir"]?.text = dirName("dir.ir")
        status.text = "Cercant IR…"
        thread {
            val out = ArrayList<DocumentFile>()
            fun walk(d: DocumentFile, depth: Int) {
                for (f in d.listFiles()) {
                    if (f.isDirectory) { if (depth < 2) walk(f, depth + 1) }
                    else { val n = f.name?.lowercase() ?: continue; if (n.endsWith(".wir") || n.endsWith(".wav")) out.add(f) }
                }
            }
            try { DocumentFile.fromTreeUri(this, uri)?.let { walk(it, 0) } } catch (_: Throwable) { }
            out.sortBy { it.name }
            runOnUiThread {
                irFiles = out
                irNames.clear(); irNames.addAll(out.map { it.name ?: "?" }); irAdapter.notifyDataSetChanged()
                status.text = "${out.size} IR trobades"
                if (out.isNotEmpty()) {
                    val want = store.get("ir.file")
                    val idx = out.indexOfFirst { it.uri.toString() == want }.let { if (it < 0) 0 else it }
                    irSpinner.setSelection(idx, false); loadIr(out[idx])
                }
            }
        }
    }

    private fun loadIr(f: DocumentFile) {
        if (f.uri == loadedIr) return
        loadedIr = f.uri
        runOnUiThread { status.text = "Carregant IR ${f.name}…" }
        thread {
            try {
                val raw = IrLoader.load(contentResolver.openInputStream(f.uri)!!.use { it.readBytes() }, f.name ?: "IR")
                engine.reverb.load(raw)
                val sec = raw.ch[0].size / raw.rate.toDouble()
                runOnUiThread { status.text = "IR: ${raw.name} · ${raw.ch.size} can. · ${raw.rate} Hz · %.2f s".format(sec) }
            } catch (e: Throwable) {
                loadedIr = null
                runOnUiThread { status.text = "Error carregant IR: ${e.message ?: e.javaClass.simpleName}" }
            }
        }
    }

    // ------------------------------------------------------------------ pista de veu
    private fun refreshDevs() {
        devs = AudioDevices.inputs(this)
        devNames.clear(); devNames.add("Entrada per defecte del sistema")
        devNames.addAll(devs.map { AudioDevices.label(it) })
        devAdapter.notifyDataSetChanged()
    }

    private fun maxVoiceFrames(): Long = (Runtime.getRuntime().maxMemory() * 0.6 / 44).toLong()

    private fun startVoice() {
        if (busy) return
        startAudio()
        val dev = devs.getOrNull(devSpinner.selectedItemPosition - 1)
        val err = recorder.start(dev, engine.sr, maxVoiceFrames())
        if (err != null) { status.text = err; return }
        if (syncSeq && events.isNotEmpty()) { engine.playSeq = events; engine.playCmd = 1 }
        status.text = "Gravant veu (màxim ${maxVoiceFrames() / engine.sr} s)…"
    }

    private fun stopVoice() {
        recorder.stop(); engine.playCmd = 2
        status.text = "Veu gravada: %.1f s".format(recorder.frames / engine.sr.toDouble())
        thread { try { recorder.saveTo(File(filesDir, "voice.f32")) } catch (_: Throwable) { } }
    }

    private fun processVoice() {
        if (busy) return
        if (recorder.recording) stopVoice()
        if (recorder.frames == 0L) { status.text = "Primer grava la veu"; return }
        busy = true; finalMix = null; player.stop()
        val sr = engine.sr
        val lat = (latencyMs * sr / 1000).coerceAtMost(recorder.frames.toInt())
        val irSec = engine.reverb.raw?.let { it.ch[0].size / it.rate.toDouble() } ?: 0.0
        val seqEnd = events.lastOrNull()?.frame ?: 0L
        val voiceLen = recorder.frames.toInt() - lat
        val total = max(voiceLen.toLong(), seqEnd + ((3.0 + irSec) * sr).toLong()).toInt()
        thread {
            try {
                if (total.toLong() * 8 * 6 > Runtime.getRuntime().maxMemory() * 0.85) {
                    runOnUiThread { status.text = "Massa llarg per a la memòria d'aquest dispositiu (${total / sr} s, màxim ~${(Runtime.getRuntime().maxMemory() * 0.85 / 48 / sr).toLong()} s)" }
                    return@thread
                }
                val raw = recorder.toDoubles()
                val voice = DoubleArray(total)
                System.arraycopy(raw, lat, voice, 0, min(voiceLen, total))
                val music = Renderer.renderBuffers(engine, events, total) { f -> runOnUiThread { status.text = "Renderitzant la música… ${(f * 100).toInt()}%" } }
                val rep = VoiceMixer.process(music, voice, vp) { stage, f -> runOnUiThread { status.text = "${(f * 100).toInt()}% · $stage" } }
                val (bits, fl) = fmts[fmtSel].second
                val file = outFile("veu_mix")
                WavWriter(file, sr, bits, fl).use { w ->
                    val tl = DoubleArray(4096); val tr = DoubleArray(4096); var pos = 0
                    while (pos < total) {
                        val n = min(4096, total - pos)
                        System.arraycopy(music[0], pos, tl, 0, n); System.arraycopy(music[1], pos, tr, 0, n)
                        w.write(tl, tr, n); pos += n
                    }
                }
                finalMix = music
                runOnUiThread { voiceReport.text = rep.text; status.text = "Mescla feta: ${file.absolutePath}" }
            } catch (e: Throwable) {
                runOnUiThread { status.text = "Error en la mescla: ${e.message ?: e.javaClass.simpleName}" }
            } finally { busy = false }
        }
    }
}
