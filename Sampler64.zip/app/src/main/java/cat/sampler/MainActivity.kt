package cat.sampler

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.documentfile.provider.DocumentFile
import kotlin.concurrent.thread
import kotlin.math.log10
import kotlin.math.max

class MainActivity : ComponentActivity() {
    private val engine = Engine(48000)
    private val audio = AudioOut(engine)
    private lateinit var midi: MidiIn
    private lateinit var status: TextView

    private val fmts = listOf("16 bit int" to (16 to false), "24 bit int" to (24 to false), "32 bit int" to (32 to false),
        "32 bit float" to (32 to true), "64 bit float (IEEE)" to (64 to true))
    private val rates = listOf(44100, 48000, 88200, 96000, 192000)
    private var fmtSel = 4
    private var rateSel = 1
    private var target = -1                       // pista destí del directori (-1 = totes)
    private var events: List<Ev> = emptyList()
    private var live: LiveRecorder? = null
    private lateinit var seqInfo: TextView

    // vúmetres
    private lateinit var meterL: MeterView
    private lateinit var meterR: MeterView
    private lateinit var meterGr: MeterView
    private val ui = Handler(Looper.getMainLooper())
    private var dispL = 0.0
    private var dispR = 0.0
    private var dispGr = 0.0

    // biblioteca d'IR
    private var irFiles: List<DocumentFile> = emptyList()
    private val irNames = ArrayList<String>()
    private lateinit var irAdapter: ArrayAdapter<String>
    private lateinit var irSpinner: Spinner
    private var loadedIr: Uri? = null

    private val tick = object : Runnable {
        override fun run() {
            val pk = engine.takePeaks()
            dispL = max(pk[0], dispL * 0.93)
            dispR = max(pk[1], dispR * 0.93)
            showOut(meterL, dispL); showOut(meterR, dispR)
            val g = engine.comp.grDb
            dispGr = if (g > dispGr) g else dispGr * 0.85 + g * 0.15
            meterGr.level = dispGr / 24.0
            meterGr.text = "-%.1f dB".format(dispGr)
            meterGr.invalidate()
            seqInfo.text = seqText()
            ui.postDelayed(this, 33)
        }
    }

    private fun seqText(): String {
        val len = (events.lastOrNull()?.frame ?: 0L) / engine.sr.toDouble()
        return if (engine.playing) "▶ %.1f / %.1f s".format(engine.playFrame / engine.sr.toDouble(), len)
        else "Seqüència: ${events.size} esdeveniments, %.1f s".format(len)
    }

    private fun loadMidi(uri: Uri) {
        status.text = "Llegint MIDI…"
        thread {
            try {
                val ev = MidiFile.parse(contentResolver.openInputStream(uri)!!.use { it.readBytes() }, engine.sr)
                runOnUiThread {
                    events = ev
                    val notes = ev.count { (it.st and 0xF0) == 0x90 && it.b > 0 }
                    status.text = "MIDI carregat: $notes notes, %.1f s (canals 1–7 → pistes segons el seu canal)".format((ev.lastOrNull()?.frame ?: 0L) / engine.sr.toDouble())
                }
            } catch (e: Throwable) {
                runOnUiThread { status.text = "Error MIDI: ${e.message ?: e.javaClass.simpleName}" }
            }
        }
    }

    private fun showOut(m: MeterView, peak: Double) {
        val db = 20 * log10(max(peak, 1e-6))
        m.level = (db + 60) / 60
        m.hot = peak >= 1.0
        m.text = if (peak >= 1.0) "CLIP" else "%.1f dB".format(db)
        m.invalidate()
    }

    private val pickMidi = registerForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let { u -> loadMidi(u) } }

    private val pickIr = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { it?.let { u -> scanIrs(u) } }

    private val pick = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { it?.let { u -> loadDir(target, u) } }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 24) }
        meterL = MeterView(this, "OUT L"); meterR = MeterView(this, "OUT R"); meterGr = MeterView(this, "GR", gr = true)
        val meters = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 8, 24, 4) }
        for (m in listOf(meterL, meterR, meterGr)) meters.addView(m, LinearLayout.LayoutParams(-1, -2))
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        page.addView(meters, LinearLayout.LayoutParams(-1, -2))
        page.addView(ScrollView(this).apply { addView(root) }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(page)
        status = TextView(this).apply { text = "Llest. Connecta un teclat MIDI o fes servir el teclat en pantalla." }
        root.addView(status)

        btn(root, "Àudio ON") { audio.start() }

        var kbTrack = 0
        spin(root, (1..Engine.TRACKS).map { "Teclat en pantalla → pista $it" }, 0) { kbTrack = it }
        val piano = PianoView(this) { n, down ->
            val ch = engine.tracks[kbTrack].channel
            engine.midi((if (down) 0x90 else 0x80) or ch, n, if (down) 100 else 0)
        }
        val scv = HorizontalScrollView(this).apply { addView(piano) }
        root.addView(scv)
        slider(root, "Desplaça el teclat (7 octaves)", 100, 0) {
            scv.scrollTo(((piano.width - scv.width).coerceAtLeast(0)) * it / 100, 0)
        }
        btn(root, "Directori de mostres → TOTES les pistes") { target = -1; pick.launch(null) }

        for (i in 0 until Engine.TRACKS) {
            val t = engine.tracks[i]
            root.addView(TextView(this).apply { text = "\nPISTA ${i + 1}" })
            spin(root, (1..16).map { "Canal MIDI $it" }, i) { t.channel = it }
            slider(root, "Volum", 100, 80) { t.vol = it / 100.0 }
            slider(root, "Pan (esquerra – dreta)", 200, 100) { t.pan = (it - 100) / 100.0 }
            root.addView(CheckBox(this).apply { text = "Mute"; setOnCheckedChangeListener { _, c -> t.mute = c } })
            root.addView(CheckBox(this).apply { text = "Transients ON"; setOnCheckedChangeListener { _, c -> t.fx.on = c } })
            val fxBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
            btn(root, "Ajustos de transients / saturació (pista ${i + 1}) ▾") {
                fxBox.visibility = if (fxBox.visibility == View.GONE) View.VISIBLE else View.GONE
            }
            spin(fxBox, listOf("Detecció: Flat", "Detecció: Human", "Detecció: Sybil"), 1) { t.fx.detect = it }
            slider(fxBox, "Sharpen (atac, -100…+100 %)", 200, 100) { t.fx.sharpen = (it - 100) / 100.0 }
            slider(fxBox, "Sustain (cua, -100…+100 %)", 200, 100) { t.fx.sustain = (it - 100) / 100.0 }
            slider(fxBox, "Speed (detector)", 100, 50) { t.fx.speed = it / 100.0 }
            spin(fxBox, listOf("Saturació: BIT", "Saturació: RECT", "Saturació: FUZZ", "Saturació: SIN", "Saturació: BASS", "Saturació: TUBE"), 3) { t.fx.shape = it }
            slider(fxBox, "Drive (0 = saturació apagada)", 100, 0) { t.fx.drive = it / 100.0 }
            slider(fxBox, "Sortida de l'insert (-12…+12 dB)", 24, 12) { t.fx.outDb = it - 12.0 }
            root.addView(fxBox)
            btn(root, "Directori de mostres per a la pista ${i + 1}") { target = i; pick.launch(null) }
        }

        root.addView(TextView(this).apply { text = "\nReverb de convolució (IR)" })
        btn(root, "Directori de convolucions (.wir / .wav)") { pickIr.launch(null) }
        irAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, irNames)
        irSpinner = Spinner(this).apply {
            adapter = irAdapter
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(a: AdapterView<*>?, v: View?, pos: Int, id: Long) { irFiles.getOrNull(pos)?.let { loadIr(it) } }
                override fun onNothingSelected(a: AdapterView<*>?) {}
            }
        }
        root.addView(irSpinner)
        root.addView(CheckBox(this).apply { text = "Reverb activada"; isChecked = true; setOnCheckedChangeListener { _, c -> engine.reverb.enabled = c } })
        slider(root, "Nivell de reverb (%)", 100, 25) { engine.reverb.mix = it / 100.0 }

        root.addView(TextView(this).apply { text = "\nCompressor UREI 1176 (64 bit)" })
        spin(root, listOf("4:1", "8:1", "12:1", "20:1", "ALL") , 0) { engine.comp.ratioIdx = it }
        slider(root, "Input (dB)", 30, 0) { engine.comp.inputDb = it.toDouble() }
        slider(root, "Output (dB, -20…+20)", 40, 20) { engine.comp.outputDb = it - 20.0 }
        slider(root, "Attack 20–800 µs", 78, 18) { engine.comp.attackUs = 20.0 + it * 10 }
        slider(root, "Release 50–1100 ms", 105, 25) { engine.comp.releaseMs = 50.0 + it * 10 }

        root.addView(TextView(this).apply { text = "\nGravació WAV" })
        spin(root, fmts.map { it.first }, fmtSel) { fmtSel = it }
        spin(root, rates.map { "$it Hz" }, rateSel) { rateSel = it }

        btn(root, "● Gravar seqüència MIDI") {
            engine.seqStart = engine.frames; engine.seq = ArrayList()
            status.text = "Gravant MIDI…"
        }
        btn(root, "■ Aturar seqüència") {
            events = engine.seq?.toList() ?: emptyList(); engine.seq = null
            status.text = "Seqüència: ${events.size} esdeveniments"
        }
        btn(root, "▶ Reproduir seqüència") {
            if (events.isEmpty()) { status.text = "No hi ha seqüència (grava'n una o carrega un .mid)"; return@btn }
            audio.start()
            engine.playSeq = events; engine.playCmd = 1
        }
        btn(root, "■ Parar reproducció") { engine.playCmd = 2 }
        root.addView(CheckBox(this).apply { text = "Repetir en bucle"; setOnCheckedChangeListener { _, c -> engine.loop = c } })
        btn(root, "Carregar fitxer MIDI (.mid)") { pickMidi.launch(arrayOf("audio/midi", "audio/mid", "audio/x-midi", "application/x-midi", "*/*")) }
        seqInfo = TextView(this).apply { text = "Seqüència: buida" }
        root.addView(seqInfo)
        btn(root, "Renderitzar seqüència → WAV (offline)") {
            val (bits, fl) = fmts[fmtSel].second
            val f = outFile("render"); val rate = rates[rateSel]
            thread {
                val irSec = engine.reverb.raw?.let { it.ch[0].size / it.rate.toDouble() } ?: 0.0
                Renderer.render(engine, events, rate, f, bits, fl, 3.0 + irSec) { p ->
                    runOnUiThread { status.text = "Renderitzant ${(p * 100).toInt()}%" }
                }
                runOnUiThread { status.text = "Fet: ${f.absolutePath}" }
            }
        }
        btn(root, "● / ■ Gravar sortida en viu (WAV)") {
            val l = live
            if (l == null) {
                val (bits, fl) = fmts[fmtSel].second
                val f = outFile("live")
                live = LiveRecorder(f, engine.sr, bits, fl).also { audio.rec = it }
                status.text = "Gravant en viu → ${f.name} (a ${engine.sr} Hz)"
            } else {
                audio.rec = null; thread { l.finish(); runOnUiThread { status.text = "Gravació tancada" } }; live = null
            }
        }

        midi = MidiIn(this, engine).also { it.start() }
        ui.post(tick)
    }

    override fun onDestroy() { ui.removeCallbacks(tick); audio.stop(); super.onDestroy() }

    private fun outFile(tag: String) = java.io.File(
        getExternalFilesDir(Environment.DIRECTORY_MUSIC), "${tag}_${System.currentTimeMillis()}.wav")

    private fun loadDir(t: Int, uri: Uri) {
        contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        status.text = "Carregant…"
        thread {
            val list = DocumentFile.fromTreeUri(this, uri)!!.listFiles()
                .filter { it.name?.endsWith(".wav", true) == true }
                .mapNotNull { f ->
                    try { f.name!! to WavReader.read(contentResolver.openInputStream(f.uri)!!.use { it.readBytes() }) }
                    catch (e: Throwable) { null }
                }
            val bank = SampleBank().also { it.build(list) }
            if (t < 0) engine.tracks.forEach { it.bank = bank } else engine.tracks[t].bank = bank
            runOnUiThread { status.text = "${list.size} mostres carregades (${if (t < 0) "totes les pistes" else "pista ${t + 1}"})" }
        }
    }

    private fun scanIrs(uri: Uri) {
        contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        status.text = "Cercant IR…"
        thread {
            val out = ArrayList<DocumentFile>()
            fun walk(d: DocumentFile, depth: Int) {
                for (f in d.listFiles()) {
                    if (f.isDirectory) { if (depth < 2) walk(f, depth + 1) }
                    else {
                        val n = f.name?.lowercase() ?: continue
                        if (n.endsWith(".wir") || n.endsWith(".wav")) out.add(f)
                    }
                }
            }
            DocumentFile.fromTreeUri(this, uri)?.let { walk(it, 0) }
            out.sortBy { it.name }
            runOnUiThread {
                irFiles = out
                irNames.clear(); irNames.addAll(out.map { it.name ?: "?" })
                irAdapter.notifyDataSetChanged()
                status.text = "${out.size} IR trobades"
                if (out.isNotEmpty()) { irSpinner.setSelection(0, false); loadIr(out[0]) }
            }
        }
    }

    private fun loadIr(f: DocumentFile) {
        if (f.uri == loadedIr) return
        loadedIr = f.uri
        runOnUiThread { status.text = "Carregant IR ${f.name}…" }
        thread {
            try {
                val raw = IrLoader.load(contentResolver.openInputStream(f.uri)!!.use { it.readBytes() }, f.name ?: "IR")
                engine.reverb.load(raw)
                val sec = raw.ch[0].size / raw.rate.toDouble()
                runOnUiThread { status.text = "IR: ${raw.name} · ${raw.ch.size} can. · ${raw.rate} Hz · %.2f s".format(sec) }
            } catch (e: Throwable) {
                loadedIr = null
                runOnUiThread { status.text = "Error carregant IR: ${e.message ?: e.javaClass.simpleName}" }
            }
        }
    }

    private fun btn(p: LinearLayout, text: String, f: () -> Unit) =
        p.addView(Button(this).apply { this.text = text; setOnClickListener { f() } })

    private fun slider(p: LinearLayout, text: String, max: Int, init: Int, cb: (Int) -> Unit) {
        p.addView(TextView(this).apply { this.text = text })
        p.addView(SeekBar(this).apply {
            this.max = max; progress = init; cb(init)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, v: Int, u: Boolean) = cb(v)
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        })
    }

    private fun spin(p: LinearLayout, items: List<String>, sel: Int, cb: (Int) -> Unit) {
        p.addView(Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
            setSelection(sel)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(a: AdapterView<*>?, v: View?, pos: Int, id: Long) = cb(pos)
                override fun onNothingSelected(a: AdapterView<*>?) {}
            }
        })
    }
}
