package cat.sampler

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioDeviceInfo
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.documentfile.provider.DocumentFile
import kotlin.concurrent.thread
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min

class MainActivity : ComponentActivity() {
    private val engine = Engine(48000)
    private val audio = AudioOut(engine)
    private lateinit var midi: MidiIn
    private lateinit var status: TextView

    private val fmts = listOf("16 bit int" to (16 to false), "24 bit int" to (24 to false), "32 bit int" to (32 to false),
        "32 bit float" to (32 to true), "64 bit float (IEEE)" to (64 to true))
    private val rates = listOf(44100, 48000, 88200, 96000, 192000)
    private var fmtSel = 4
    private var rateSel = 1
    private var target = -1                       // pista destí del directori (-1 = totes)
    private var events: List<Ev> = emptyList()
    private var live: LiveRecorder? = null
    private lateinit var seqInfo: TextView

    // pista de veu
    private val vp = VoiceParams()
    private val recorder = VoiceRecorder()
    private val player = MixPlayer()
    private var devs: List<AudioDeviceInfo> = emptyList()
    private val devNames = ArrayList<String>()
    private lateinit var devAdapter: ArrayAdapter<String>
    private lateinit var devSpinner: Spinner
    private lateinit var voiceInfo: TextView
    private lateinit var voiceReport: TextView
    private lateinit var meterIn: MeterView
    private var dispIn = 0.0
    private var latencyMs = 0
    private var syncSeq = true
    private var finalMix: Array<DoubleArray>? = null
    @Volatile private var busy = false

    // vúmetres
    private lateinit var meterL: MeterView
    private lateinit var meterR: MeterView
    private lateinit var meterGr: MeterView
    private val ui = Handler(Looper.getMainLooper())
    private var dispL = 0.0
    private var dispR = 0.0
    private var dispGr = 0.0

    // biblioteca d'IR
    private var irFiles: List<DocumentFile> = emptyList()
    private val irNames = ArrayList<String>()
    private lateinit var irAdapter: ArrayAdapter<String>
    private lateinit var irSpinner: Spinner
    private var loadedIr: Uri? = null

    private val tick = object : Runnable {
        override fun run() {
            val pk = engine.takePeaks()
            dispL = max(pk[0], dispL * 0.93)
            dispR = max(pk[1], dispR * 0.93)
            showOut(meterL, dispL); showOut(meterR, dispR)
            val g = engine.comp.grDb
            dispGr = if (g > dispGr) g else dispGr * 0.85 + g * 0.15
            meterGr.level = dispGr / 24.0
            meterGr.text = "-%.1f dB".format(dispGr)
            meterGr.invalidate()
            seqInfo.text = seqText()
            dispIn = max(recorder.takePeak(), dispIn * 0.93); showOut(meterIn, dispIn)
            voiceInfo.text = if (recorder.recording) "● Gravant veu: %.1f s".format(recorder.frames / engine.sr.toDouble())
                             else "Veu gravada: %.1f s".format(recorder.frames / engine.sr.toDouble())
            ui.postDelayed(this, 33)
        }
    }

    private fun seqText(): String {
        val len = (events.lastOrNull()?.frame ?: 0L) / engine.sr.toDouble()
        return if (engine.playing) "▶ %.1f / %.1f s".format(engine.playFrame / engine.sr.toDouble(), len)
        else "Seqüència: ${events.size} esdeveniments, %.1f s".format(len)
    }

    private fun loadMidi(uri: Uri) {
        status.text = "Llegint MIDI…"
        thread {
            try {
                val ev = MidiFile.parse(contentResolver.openInputStream(uri)!!.use { it.readBytes() }, engine.sr)
                runOnUiThread {
                    events = ev
                    val notes = ev.count { (it.st and 0xF0) == 0x90 && it.b > 0 }
                    status.text = "MIDI carregat: $notes notes, %.1f s (canals 1–7 → pistes segons el seu canal)".format((ev.lastOrNull()?.frame ?: 0L) / engine.sr.toDouble())
                }
            } catch (e: Throwable) {
                runOnUiThread { status.text = "Error MIDI: ${e.message ?: e.javaClass.simpleName}" }
            }
        }
    }

    private fun showOut(m: MeterView, peak: Double) {
        val db = 20 * log10(max(peak, 1e-6))
        m.level = (db + 60) / 60
        m.hot = peak >= 1.0
        m.text = if (peak >= 1.0) "CLIP" else "%.1f dB".format(db)
        m.invalidate()
    }

    private val askMic = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startVoice() else status.text = "Cal el permís de micròfon per gravar la veu"
    }

    private val pickMidi = registerForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let { u -> loadMidi(u) } }

    private val pickIr = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { it?.let { u -> scanIrs(u) } }

    private val pick = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { it?.let { u -> loadDir(target, u) } }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 24) }
        meterL = MeterView(this, "OUT L"); meterR = MeterView(this, "OUT R"); meterGr = MeterView(this, "GR", gr = true); meterIn = MeterView(this, "MIC")
        val meters = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 8, 24, 4) }
        for (m in listOf(meterL, meterR, meterGr, meterIn)) meters.addView(m, LinearLayout.LayoutParams(-1, -2))
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        page.addView(meters, LinearLayout.LayoutParams(-1, -2))
        page.addView(ScrollView(this).apply { addView(root) }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(page)
        status = TextView(this).apply { text = "Llest. Connecta un teclat MIDI o fes servir el teclat en pantalla." }
        root.addView(status)

        btn(root, "Àudio ON") { audio.start() }

        var kbTrack = 0
        spin(root, (1..Engine.TRACKS).map { "Teclat en pantalla → pista $it" }, 0) { kbTrack = it }
        val piano = PianoView(this) { n, down ->
            val ch = engine.tracks[kbTrack].channel
            engine.midi((if (down) 0x90 else 0x80) or ch, n, if (down) 100 else 0)
        }
        val scv = HorizontalScrollView(this).apply { addView(piano) }
        root.addView(scv)
        slider(root, "Desplaça el teclat (7 octaves)", 100, 0) {
            scv.scrollTo(((piano.width - scv.width).coerceAtLeast(0)) * it / 100, 0)
        }
        btn(root, "Directori de mostres → TOTES les pistes") { target = -1; pick.launch(null) }

        for (i in 0 until Engine.TRACKS) {
            val t = engine.tracks[i]
            root.addView(TextView(this).apply { text = "\nPISTA ${i + 1}" })
            spin(root, (1..16).map { "Canal MIDI $it" }, i) { t.channel = it }
            slider(root, "Volum", 100, 80) { t.vol = it / 100.0 }
            slider(root, "Pan (esquerra – dreta)", 200, 100) { t.pan = (it - 100) / 100.0 }
            root.addView(CheckBox(this).apply { text = "Mute"; setOnCheckedChangeListener { _, c -> t.mute = c } })
            root.addView(CheckBox(this).apply { text = "Transients ON"; setOnCheckedChangeListener { _, c -> t.fx.on = c } })
            val fxBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
            btn(root, "Ajustos de transients / saturació (pista ${i + 1}) ▾") {
                fxBox.visibility = if (fxBox.visibility == View.GONE) View.VISIBLE else View.GONE
            }
            spin(fxBox, listOf("Detecció: Flat", "Detecció: Human", "Detecció: Sybil"), 1) { t.fx.detect = it }
            slider(fxBox, "Sharpen (atac, -100…+100 %)", 200, 100) { t.fx.sharpen = (it - 100) / 100.0 }
            slider(fxBox, "Sustain (cua, -100…+100 %)", 200, 100) { t.fx.sustain = (it - 100) / 100.0 }
            slider(fxBox, "Speed (detector)", 100, 50) { t.fx.speed = it / 100.0 }
            spin(fxBox, listOf("Saturació: BIT", "Saturació: RECT", "Saturació: FUZZ", "Saturació: SIN", "Saturació: BASS", "Saturació: TUBE"), 3) { t.fx.shape = it }
            slider(fxBox, "Drive (0 = saturació apagada)", 100, 0) { t.fx.drive = it / 100.0 }
            slider(fxBox, "Sortida de l'insert (-12…+12 dB)", 24, 12) { t.fx.outDb = it - 12.0 }
            root.addView(fxBox)
            btn(root, "Directori de mostres per a la pista ${i + 1}") { target = i; pick.launch(null) }
        }

        root.addView(TextView(this).apply { text = "\nReverb de convolució (IR)" })
        btn(root, "Directori de convolucions (.wir / .wav)") { pickIr.launch(null) }
        irAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, irNames)
        irSpinner = Spinner(this).apply {
            adapter = irAdapter
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(a: AdapterView<*>?, v: View?, pos: Int, id: Long) { irFiles.getOrNull(pos)?.let { loadIr(it) } }
                override fun onNothingSelected(a: AdapterView<*>?) {}
            }
        }
        root.addView(irSpinner)
        root.addView(CheckBox(this).apply { text = "Reverb activada"; isChecked = true; setOnCheckedChangeListener { _, c -> engine.reverb.enabled = c } })
        slider(root, "Nivell de reverb (%)", 100, 25) { engine.reverb.mix = it / 100.0 }

        root.addView(TextView(this).apply { text = "\nCompressor UREI 1176 (64 bit)" })
        spin(root, listOf("4:1", "8:1", "12:1", "20:1", "ALL") , 0) { engine.comp.ratioIdx = it }
        slider(root, "Input (dB)", 30, 0) { engine.comp.inputDb = it.toDouble() }
        slider(root, "Output (dB, -20…+20)", 40, 20) { engine.comp.outputDb = it - 20.0 }
        slider(root, "Attack 20–800 µs", 78, 18) { engine.comp.attackUs = 20.0 + it * 10 }
        slider(root, "Release 50–1100 ms", 105, 25) { engine.comp.releaseMs = 50.0 + it * 10 }

        root.addView(TextView(this).apply { text = "\nGravació WAV" })
        spin(root, fmts.map { it.first }, fmtSel) { fmtSel = it }
        spin(root, rates.map { "$it Hz" }, rateSel) { rateSel = it }

        btn(root, "● Gravar seqüència MIDI") {
            engine.seqStart = engine.frames; engine.seq = ArrayList()
            status.text = "Gravant MIDI…"
        }
        btn(root, "■ Aturar seqüència") {
            events = engine.seq?.toList() ?: emptyList(); engine.seq = null
            status.text = "Seqüència: ${events.size} esdeveniments"
        }
        btn(root, "▶ Reproduir seqüència") {
            if (events.isEmpty()) { status.text = "No hi ha seqüència (grava'n una o carrega un .mid)"; return@btn }
            audio.start()
            engine.playSeq = events; engine.playCmd = 1
        }
        btn(root, "■ Parar reproducció") { engine.playCmd = 2 }
        root.addView(CheckBox(this).apply { text = "Repetir en bucle"; setOnCheckedChangeListener { _, c -> engine.loop = c } })
        btn(root, "Carregar fitxer MIDI (.mid)") { pickMidi.launch(arrayOf("audio/midi", "audio/mid", "audio/x-midi", "application/x-midi", "*/*")) }
        seqInfo = TextView(this).apply { text = "Seqüència: buida" }
        root.addView(seqInfo)
        btn(root, "Renderitzar seqüència → WAV (offline)") {
            val (bits, fl) = fmts[fmtSel].second
            val f = outFile("render"); val rate = rates[rateSel]
            thread {
                val irSec = engine.reverb.raw?.let { it.ch[0].size / it.rate.toDouble() } ?: 0.0
                Renderer.render(engine, events, rate, f, bits, fl, 3.0 + irSec) { p ->
                    runOnUiThread { status.text = "Renderitzant ${(p * 100).toInt()}%" }
                }
                runOnUiThread { status.text = "Fet: ${f.absolutePath}" }
            }
        }
        btn(root, "● / ■ Gravar sortida en viu (WAV)") {
            val l = live
            if (l == null) {
                val (bits, fl) = fmts[fmtSel].second
                val f = outFile("live")
                live = LiveRecorder(f, engine.sr, bits, fl).also { audio.rec = it }
                status.text = "Gravant en viu → ${f.name} (a ${engine.sr} Hz)"
            } else {
                audio.rec = null; thread { l.finish(); runOnUiThread { status.text = "Gravació tancada" } }; live = null
            }
        }

        // ---------------- PISTA DE VEU
        root.addView(TextView(this).apply { text = "\nPISTA DE VEU · gravació + neteja + mescla automàtica" })
        devAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, devNames)
        devSpinner = Spinner(this).apply { adapter = devAdapter }
        btn(root, "Actualitza dispositius d'entrada (interfície USB)") { refreshDevs() }
        root.addView(devSpinner); refreshDevs()
        root.addView(CheckBox(this).apply { text = "Gravar sincronitzat amb la seqüència (la música sona mentre graves)"; isChecked = true; setOnCheckedChangeListener { _, c -> syncSeq = c } })
        slider(root, "Compensació de latència (ms)", 300, 0) { latencyMs = it }
        btn(root, "● Gravar veu") {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startVoice()
            else askMic.launch(Manifest.permission.RECORD_AUDIO)
        }
        btn(root, "■ Aturar gravació de veu") { stopVoice() }
        voiceInfo = TextView(this).apply { text = "Veu gravada: 0.0 s" }
        root.addView(voiceInfo)
        fun mod(label: String, set: (Boolean) -> Unit) = root.addView(CheckBox(this).apply { text = label; isChecked = true; setOnCheckedChangeListener { _, c -> set(c) } })
        mod("Mouth noise (clics de boca)") { vp.declick = it }
        mod("Lowend (passa-alts + plosives)") { vp.lowend = it }
        mod("Clean (reducció de soroll)") { vp.clean = it }
        mod("Breath (respiracions)") { vp.breath = it }
        mod("Gate") { vp.gate = it }
        mod("Sibilance (de-esser)") { vp.deess = it }
        mod("Dynamics (nivellador de veu)") { vp.dynamics = it }
        slider(root, "Reducció de soroll (dB)", 18, 6) { vp.cleanDb = 6.0 + it }
        slider(root, "Rang del gate (dB)", 34, 14) { vp.gateDb = 6.0 + it }
        slider(root, "De-esser: reducció màxima (dB)", 12, 7) { vp.deessMax = 3.0 + it }
        slider(root, "Prevalença de la veu (0 = integrada · 100 = dominant)", 100, 50) { vp.prevalence = it / 100.0 }
        slider(root, "Sonoritat final objectiu (–24…–8 LUFS)", 16, 10) { vp.targetLufs = -24.0 + it }
        btn(root, "Analitzar i mesclar → WAV") { processVoice() }
        btn(root, "▶ Escoltar la mescla final") {
            val m = finalMix
            if (m == null) status.text = "Encara no hi ha mescla final"
            else player.play(m[0], m[1], engine.sr) { runOnUiThread { status.text = "Escolta acabada" } }
        }
        btn(root, "■ Parar escolta") { player.stop() }
        voiceReport = TextView(this).apply { text = "" }
        root.addView(voiceReport)

        midi = MidiIn(this, engine).also { it.start() }
        ui.post(tick)
    }

    override fun onDestroy() { ui.removeCallbacks(tick); audio.stop(); super.onDestroy() }

    private fun outFile(tag: String) = java.io.File(
        getExternalFilesDir(Environment.DIRECTORY_MUSIC), "${tag}_${System.currentTimeMillis()}.wav")

    private fun loadDir(t: Int, uri: Uri) {
        contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        status.text = "Carregant…"
        thread {
            val list = DocumentFile.fromTreeUri(this, uri)!!.listFiles()
                .filter { it.name?.endsWith(".wav", true) == true }
                .mapNotNull { f ->
                    try { f.name!! to WavReader.read(contentResolver.openInputStream(f.uri)!!.use { it.readBytes() }) }
                    catch (e: Throwable) { null }
                }
            val bank = SampleBank().also { it.build(list) }
            if (t < 0) engine.tracks.forEach { it.bank = bank } else engine.tracks[t].bank = bank
            runOnUiThread { status.text = "${list.size} mostres carregades (${if (t < 0) "totes les pistes" else "pista ${t + 1}"})" }
        }
    }

    private fun scanIrs(uri: Uri) {
        contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        status.text = "Cercant IR…"
        thread {
            val out = ArrayList<DocumentFile>()
            fun walk(d: DocumentFile, depth: Int) {
                for (f in d.listFiles()) {
                    if (f.isDirectory) { if (depth < 2) walk(f, depth + 1) }
                    else {
                        val n = f.name?.lowercase() ?: continue
                        if (n.endsWith(".wir") || n.endsWith(".wav")) out.add(f)
                    }
                }
            }
            DocumentFile.fromTreeUri(this, uri)?.let { walk(it, 0) }
            out.sortBy { it.name }
            runOnUiThread {
                irFiles = out
                irNames.clear(); irNames.addAll(out.map { it.name ?: "?" })
                irAdapter.notifyDataSetChanged()
                status.text = "${out.size} IR trobades"
                if (out.isNotEmpty()) { irSpinner.setSelection(0, false); loadIr(out[0]) }
            }
        }
    }

    private fun loadIr(f: DocumentFile) {
        if (f.uri == loadedIr) return
        loadedIr = f.uri
        runOnUiThread { status.text = "Carregant IR ${f.name}…" }
        thread {
            try {
                val raw = IrLoader.load(contentResolver.openInputStream(f.uri)!!.use { it.readBytes() }, f.name ?: "IR")
                engine.reverb.load(raw)
                val sec = raw.ch[0].size / raw.rate.toDouble()
                runOnUiThread { status.text = "IR: ${raw.name} · ${raw.ch.size} can. · ${raw.rate} Hz · %.2f s".format(sec) }
            } catch (e: Throwable) {
                loadedIr = null
                runOnUiThread { status.text = "Error carregant IR: ${e.message ?: e.javaClass.simpleName}" }
            }
        }
    }

    private fun refreshDevs() {
        devs = AudioDevices.inputs(this)
        devNames.clear(); devNames.add("Entrada per defecte del sistema")
        devNames.addAll(devs.map { AudioDevices.label(it) })
        devAdapter.notifyDataSetChanged()
    }

    /** Frames màxims segons la memòria disponible (la mescla necessita ~5 vectors de doubles). */
    private fun maxVoiceFrames(): Long = (Runtime.getRuntime().maxMemory() * 0.6 / 44).toLong()

    private fun startVoice() {
        if (busy) return
        audio.start()
        val dev = devs.getOrNull(devSpinner.selectedItemPosition - 1)
        val err = recorder.start(dev, engine.sr, maxVoiceFrames())
        if (err != null) { status.text = err; return }
        if (syncSeq && events.isNotEmpty()) { engine.playSeq = events; engine.playCmd = 1 }
        status.text = "Gravant veu (màxim ${maxVoiceFrames() / engine.sr} s)…"
    }

    private fun stopVoice() {
        recorder.stop()
        engine.playCmd = 2
        status.text = "Veu gravada: %.1f s".format(recorder.frames / engine.sr.toDouble())
    }

    private fun processVoice() {
        if (busy) return
        if (recorder.recording) stopVoice()
        if (recorder.frames == 0L) { status.text = "Primer grava la veu"; return }
        busy = true; finalMix = null; player.stop()
        val sr = engine.sr
        val lat = (latencyMs * sr / 1000).coerceAtMost(recorder.frames.toInt())
        val irSec = engine.reverb.raw?.let { it.ch[0].size / it.rate.toDouble() } ?: 0.0
        val seqEnd = events.lastOrNull()?.frame ?: 0L
        val voiceLen = recorder.frames.toInt() - lat
        val total = max(voiceLen.toLong(), seqEnd + ((3.0 + irSec) * sr).toLong()).toInt()
        thread {
            try {
                val need = total.toLong() * 8 * 6
                if (need > Runtime.getRuntime().maxMemory() * 0.85) {
                    runOnUiThread { status.text = "Massa llarg per a la memòria d'aquest dispositiu (${total / sr} s, màxim ~${(Runtime.getRuntime().maxMemory() * 0.85 / 48 / sr).toLong()} s)" }
                    return@thread
                }
                val raw = recorder.toDoubles()
                val voice = DoubleArray(total)
                System.arraycopy(raw, lat, voice, 0, min(voiceLen, total))
                val music = Renderer.renderBuffers(engine, events, total) { f -> runOnUiThread { status.text = "Renderitzant la música… ${(f * 100).toInt()}%" } }
                val rep = VoiceMixer.process(music, voice, vp) { stage, f -> runOnUiThread { status.text = "${(f * 100).toInt()}% · $stage" } }
                val (bits, fl) = fmts[fmtSel].second
                val file = outFile("veu_mix")
                WavWriter(file, sr, bits, fl).use { w ->
                    val tl = DoubleArray(4096); val tr = DoubleArray(4096); var pos = 0
                    while (pos < total) {
                        val n = min(4096, total - pos)
                        System.arraycopy(music[0], pos, tl, 0, n); System.arraycopy(music[1], pos, tr, 0, n)
                        w.write(tl, tr, n); pos += n
                    }
                }
                finalMix = music
                runOnUiThread { voiceReport.text = rep.text; status.text = "Mescla feta: ${file.absolutePath}" }
            } catch (e: Throwable) {
                runOnUiThread { status.text = "Error en la mescla: ${e.message ?: e.javaClass.simpleName}" }
            } finally { busy = false }
        }
    }

    private fun btn(p: LinearLayout, text: String, f: () -> Unit) =
        p.addView(Button(this).apply { this.text = text; setOnClickListener { f() } })

    private fun slider(p: LinearLayout, text: String, max: Int, init: Int, cb: (Int) -> Unit) {
        p.addView(TextView(this).apply { this.text = text })
        p.addView(SeekBar(this).apply {
            this.max = max; progress = init; cb(init)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, v: Int, u: Boolean) = cb(v)
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        })
    }

    private fun spin(p: LinearLayout, items: List<String>, sel: Int, cb: (Int) -> Unit) {
        p.addView(Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
            setSelection(sel)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(a: AdapterView<*>?, v: View?, pos: Int, id: Long) = cb(pos)
                override fun onNothingSelected(a: AdapterView<*>?) {}
            }
        })
    }
}
