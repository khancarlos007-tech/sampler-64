package cat.sampler

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View

/** Teclat de 7 octaves (C1..B7 = MIDI 24..107), multitàctil amb glissando. */
class PianoView(ctx: Context, private val onNote: (Int, Boolean) -> Unit) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val wk = 44f * d
    private val bw = 28f * d
    private val h = 190f * d
    private val white = ArrayList<Pair<Int, RectF>>()
    private val black = ArrayList<Pair<Int, RectF>>()
    private val down = HashMap<Int, Int>()          // pointerId → nota
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        val off = intArrayOf(0, 2, 4, 5, 7, 9, 11)
        for (o in 0 until 7) for (w in 0 until 7) {
            val i = o * 7 + w
            white.add((24 + o * 12 + off[w]) to RectF(i * wk, 0f, (i + 1) * wk, h))
            if (w in intArrayOf(0, 1, 3, 4, 5)) {
                val x = (i + 1) * wk - bw / 2
                black.add((24 + o * 12 + off[w] + 1) to RectF(x, 0f, x + bw, h * 0.6f))
            }
        }
    }

    override fun onMeasure(w: Int, hh: Int) = setMeasuredDimension((49 * wk).toInt(), h.toInt())

    private fun noteAt(x: Float, y: Float): Int? {
        black.firstOrNull { it.second.contains(x, y) }?.let { return it.first }
        return white.firstOrNull { it.second.contains(x, y) }?.first
    }

    override fun onDraw(c: Canvas) {
        val on = down.values.toSet()
        for ((n, r) in white) {
            p.style = Paint.Style.FILL; p.color = if (n in on) 0xFF9CC9FF.toInt() else 0xFFFFFFFF.toInt(); c.drawRect(r, p)
            p.style = Paint.Style.STROKE; p.color = 0xFF000000.toInt(); c.drawRect(r, p)
            if (n % 12 == 0) { p.style = Paint.Style.FILL; p.textSize = 11f * d; c.drawText("C${n / 12 - 1}", r.left + 4 * d, r.bottom - 6 * d, p) }
        }
        for ((n, r) in black) { p.style = Paint.Style.FILL; p.color = if (n in on) 0xFF3D7BD9.toInt() else 0xFF111111.toInt(); c.drawRect(r, p) }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        parent?.requestDisallowInterceptTouchEvent(true)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex
                noteAt(e.getX(i), e.getY(i))?.let { down[e.getPointerId(i)] = it; onNote(it, true) }
            }
            MotionEvent.ACTION_MOVE -> for (i in 0 until e.pointerCount) {
                val id = e.getPointerId(i); val n = noteAt(e.getX(i), e.getY(i)); val old = down[id]
                if (n != old) { old?.let { onNote(it, false) }; if (n != null) { down[id] = n; onNote(n, true) } else down.remove(id) }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                val i = e.actionIndex
                val id = e.getPointerId(i)
                if (e.actionMasked == MotionEvent.ACTION_CANCEL) { down.values.forEach { onNote(it, false) }; down.clear() }
                else down.remove(id)?.let { onNote(it, false) }
            }
        }
        invalidate()
        return true
    }
}
