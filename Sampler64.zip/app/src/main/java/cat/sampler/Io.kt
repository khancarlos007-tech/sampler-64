package cat.sampler

import android.content.Context
import android.media.*
import android.media.midi.*
import android.os.Handler
import android.os.Looper
import android.os.Process
import java.io.File
import java.util.concurrent.LinkedBlockingQueue
import kotlin.math.max

/** Sortida d'àudio: el motor treballa en double; només a l'últim pas es passa a float32 pel HAL. */
class AudioOut(private val engine: Engine) {
    @Volatile private var run = false
    @Volatile var rec: LiveRecorder? = null
    private var blockSize = 128
    private var bufMul = 2
    private var lowLat = true
    private var th: Thread? = null
    val running get() = run
    val blockFrames get() = blockSize

    /**
     * Mode d'àudio. 0 = mínima latència (blocs de 128, búfer petit), 1 = equilibrat (256, búfer 4 blocs),
     * 2 = segur (512, búfer 8 blocs, sense mode de baixa latència): més retard però molt menys talls amb efectes pesats.
     * Per aplicar-lo cal aturar i tornar a engegar l'àudio.
     */
    fun configure(mode: Int) {
        when (mode) {
            0 -> { blockSize = 128; bufMul = 2; lowLat = true }
            1 -> { blockSize = 256; bufMul = 4; lowLat = false }
            else -> { blockSize = 512; bufMul = 8; lowLat = false }
        }
    }

    /** Protecció contra retallada dura del DAC: genoll suau a partir de 0,7 amb asímptota a 1,0. Només a la sortida en viu. */
    @Volatile var protect = true
    @Volatile var diagLoadMax = 0.0      // fracció del temps del bloc gastada pel motor: 1.0 = sense marge
    @Volatile var diagLoadAvg = 0.0
    @Volatile var diagOvers = 0L         // mostres que superaven 0 dBFS abans de la protecció
    @Volatile var diagUnderruns = 0
    fun resetDiag() { diagLoadMax = 0.0; diagLoadAvg = 0.0; diagOvers = 0 }
    private fun soft(x: Double): Double {
        val a = kotlin.math.abs(x); if (a <= 0.7) return x
        val y = 0.7 + 0.3 * kotlin.math.tanh((a - 0.7) / 0.3)
        return if (x < 0) -y else y
    }

    fun start() {
        if (run) return
        val sr = engine.sr
        val bs = blockSize
        val min = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_FLOAT)
        val at = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                .setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build())
            .setBufferSizeInBytes(max(min, bs * 8 * bufMul))
            .setPerformanceMode(if (lowLat) AudioTrack.PERFORMANCE_MODE_LOW_LATENCY else AudioTrack.PERFORMANCE_MODE_NONE).build()
        run = true
        th = Thread {
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
            val l = DoubleArray(bs); val r = DoubleArray(bs); val o = FloatArray(bs * 2)
            at.play()
            val budget = bs * 1e9 / sr; var nb = 0
            while (run) {
                val t0 = System.nanoTime()
                engine.render(l, r, bs)
                val load = (System.nanoTime() - t0) / budget
                diagLoadAvg += (load - diagLoadAvg) * 0.01
                if (load > diagLoadMax) diagLoadMax = load
                rec?.push(l, r, bs)                      // el fitxer rep els 64 bits íntegres
                var ov = 0
                for (i in 0 until bs) {
                    var a = l[i]; var b = r[i]
                    if (kotlin.math.abs(a) > 1.0 || kotlin.math.abs(b) > 1.0) ov++
                    if (protect) { a = soft(a); b = soft(b) }
                    o[2 * i] = a.toFloat(); o[2 * i + 1] = b.toFloat()
                }
                if (ov > 0) diagOvers += ov
                at.write(o, 0, bs * 2, AudioTrack.WRITE_BLOCKING)
                if (++nb % 64 == 0) diagUnderruns = at.underrunCount
            }
            at.stop(); at.release()
        }.also { it.start() }
    }

    /** Atura el fil d'àudio i n'espera la fi (així mai dos fils renderitzen alhora el mateix motor). */
    fun stop() { run = false; try { th?.join(500) } catch (_: Throwable) { }; th = null }
}

/** Grava el bus master en viu; l'escriptura a disc va en un fil apart. */
class LiveRecorder(file: File, rate: Int, bits: Int, float: Boolean) {
    private val q = LinkedBlockingQueue<Array<DoubleArray>>()
    private val th = Thread {
        WavWriter(file, rate, bits, float).use { w ->
            while (true) {
                val b = q.take()
                if (b[0].isEmpty()) break
                w.write(b[0], b[1], b[0].size)
            }
        }
    }.also { it.start() }

    fun push(l: DoubleArray, r: DoubleArray, n: Int) { q.add(arrayOf(l.copyOf(n), r.copyOf(n))) }
    fun finish() { q.add(arrayOf(DoubleArray(0), DoubleArray(0))); th.join() }
}

/** Entrada MIDI (USB / Bluetooth) via android.media.midi. Canals 1–7 → pistes 1–7. */
class MidiIn(ctx: Context, private val engine: Engine) {
    private val mm = ctx.getSystemService(Context.MIDI_SERVICE) as MidiManager
    private val h = Handler(Looper.getMainLooper())

    private val recv = object : MidiReceiver() {
        override fun onSend(m: ByteArray, offset: Int, count: Int, ts: Long) {
            var i = offset; val end = offset + count
            while (i < end) {
                val s = m[i].toInt() and 0xFF
                if (s < 0x80) { i++; continue }
                val len = when (s and 0xF0) { 0xC0, 0xD0 -> 2; 0xF0 -> 1; else -> 3 }
                if (len == 3 && i + 2 < end) engine.midi(s, m[i + 1].toInt() and 0x7F, m[i + 2].toInt() and 0x7F)
                i += len
            }
        }
    }

    fun start() {
        mm.devices.forEach(::open)
        mm.registerDeviceCallback(object : MidiManager.DeviceCallback() {
            override fun onDeviceAdded(d: MidiDeviceInfo) { open(d) }
        }, h)
    }

    private fun open(info: MidiDeviceInfo) {
        if (info.outputPortCount == 0) return
        mm.openDevice(info, { dev -> dev?.openOutputPort(0)?.connect(recv) }, h)
    }
}
