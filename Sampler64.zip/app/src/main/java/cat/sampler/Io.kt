package cat.sampler

import android.content.Context
import android.media.*
import android.media.midi.*
import android.os.Handler
import android.os.Looper
import android.os.Process
import java.io.File
import java.util.concurrent.LinkedBlockingQueue
import kotlin.math.max

/** Sortida d'àudio: el motor treballa en double; només a l'últim pas es passa a float32 pel HAL. */
class AudioOut(private val engine: Engine) {
    @Volatile private var run = false
    @Volatile var rec: LiveRecorder? = null
    private val B = 128

    fun start() {
        if (run) return
        val sr = engine.sr
        val min = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_FLOAT)
        val at = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                .setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build())
            .setBufferSizeInBytes(max(min, B * 8 * 2))
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY).build()
        run = true
        Thread {
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
            val l = DoubleArray(B); val r = DoubleArray(B); val o = FloatArray(B * 2)
            at.play()
            while (run) {
                engine.render(l, r, B)
                rec?.push(l, r, B)                       // el fitxer rep els 64 bits íntegres
                for (i in 0 until B) { o[2 * i] = l[i].toFloat(); o[2 * i + 1] = r[i].toFloat() }
                at.write(o, 0, B * 2, AudioTrack.WRITE_BLOCKING)
            }
            at.stop(); at.release()
        }.start()
    }

    fun stop() { run = false }
}

/** Grava el bus master en viu; l'escriptura a disc va en un fil apart. */
class LiveRecorder(file: File, rate: Int, bits: Int, float: Boolean) {
    private val q = LinkedBlockingQueue<Array<DoubleArray>>()
    private val th = Thread {
        WavWriter(file, rate, bits, float).use { w ->
            while (true) {
                val b = q.take()
                if (b[0].isEmpty()) break
                w.write(b[0], b[1], b[0].size)
            }
        }
    }.also { it.start() }

    fun push(l: DoubleArray, r: DoubleArray, n: Int) { q.add(arrayOf(l.copyOf(n), r.copyOf(n))) }
    fun finish() { q.add(arrayOf(DoubleArray(0), DoubleArray(0))); th.join() }
}

/** Entrada MIDI (USB / Bluetooth) via android.media.midi. Canals 1–7 → pistes 1–7. */
class MidiIn(ctx: Context, private val engine: Engine) {
    private val mm = ctx.getSystemService(Context.MIDI_SERVICE) as MidiManager
    private val h = Handler(Looper.getMainLooper())

    private val recv = object : MidiReceiver() {
        override fun onSend(m: ByteArray, offset: Int, count: Int, ts: Long) {
            var i = offset; val end = offset + count
            while (i < end) {
                val s = m[i].toInt() and 0xFF
                if (s < 0x80) { i++; continue }
                val len = when (s and 0xF0) { 0xC0, 0xD0 -> 2; 0xF0 -> 1; else -> 3 }
                if (len == 3 && i + 2 < end) engine.midi(s, m[i + 1].toInt() and 0x7F, m[i + 2].toInt() and 0x7F)
                i += len
            }
        }
    }

    fun start() {
        mm.devices.forEach(::open)
        mm.registerDeviceCallback(object : MidiManager.DeviceCallback() {
            override fun onDeviceAdded(d: MidiDeviceInfo) { open(d) }
        }, h)
    }

    private fun open(info: MidiDeviceInfo) {
        if (info.outputPortCount == 0) return
        mm.openDevice(info, { dev -> dev?.openOutputPort(0)?.connect(recv) }, h)
    }
}
