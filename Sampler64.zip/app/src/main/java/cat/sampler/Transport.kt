package cat.sampler

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.math.ceil
import kotlin.math.max

/**
 * Línia de temps del transport: cursor, rang IN/OUT i zoom. Amb zoom > 1 mostra una finestra al voltant del cursor,
 * de manera que arrossegar dóna una resolució de fins a 1/40 de la durada total.
 */
class TimelineView(ctx: Context) : View(ctx) {
    var total = 1L
    var cursor = 0L
    var markIn = 0L
    var markOut = 1L
    var zoom = 1.0
    var sr = 48000
    var onSeek: ((Long) -> Unit)? = null
    private var vs = 0L
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rc = RectF()
    private val steps = doubleArrayOf(0.01, 0.05, 0.1, 0.25, 0.5, 1.0, 2.0, 5.0, 10.0, 15.0, 30.0, 60.0, 120.0, 300.0)

    override fun onMeasure(w: Int, h: Int) = setMeasuredDimension(MeasureSpec.getSize(w), (92 * d).toInt())

    private fun win() = max(sr / 10L, (total / zoom).toLong())
    private fun xOf(f: Long) = ((f - vs).toDouble() / win() * width).toFloat()

    override fun onDraw(c: Canvas) {
        val w = win()
        if (cursor < vs || cursor > vs + w) vs = cursor - w / 2
        if (vs + w > total) vs = total - w
        if (vs < 0) vs = 0
        p.style = Paint.Style.FILL
        p.color = 0xFF0A0C10.toInt(); rc.set(0f, 0f, width.toFloat(), height.toFloat()); c.drawRoundRect(rc, 8 * d, 8 * d, p)
        // rang IN–OUT
        val xi = xOf(markIn).coerceIn(0f, width.toFloat()); val xo = xOf(markOut).coerceIn(0f, width.toFloat())
        p.color = 0x33FF9F1C; if (xo > xi) c.drawRect(xi, 0f, xo, height.toFloat(), p)
        // marques de temps
        val stepS = steps.firstOrNull { w / (it * sr) <= 9 } ?: steps.last()
        val stepF = (stepS * sr).toLong().coerceAtLeast(1)
        var f = ceil(vs.toDouble() / stepF).toLong() * stepF
        p.textSize = 10 * d; p.color = 0xFF9AA5B8.toInt()
        while (f <= vs + w) {
            val x = xOf(f); p.strokeWidth = 1f; c.drawLine(x, height * 0.55f, x, height.toFloat() - 14 * d, p)
            val sec = f.toDouble() / sr
            c.drawText(if (stepS < 1) "%.2f".format(sec) else "%d:%02d".format((sec / 60).toInt(), (sec % 60).toInt()), x + 2 * d, height - 3 * d, p)
            f += stepF
        }
        // marcadors IN (verd) i OUT (vermell)
        fun flag(fr: Long, col: Int, label: String, right: Boolean) {
            if (fr < vs || fr > vs + w) return
            val x = xOf(fr); p.color = col; p.strokeWidth = 2 * d
            c.drawLine(x, 0f, x, height.toFloat() - 14 * d, p)
            val path = Path(); val s = 12 * d
            if (right) { path.moveTo(x, 0f); path.lineTo(x + s, s / 2); path.lineTo(x, s) } else { path.moveTo(x, 0f); path.lineTo(x - s, s / 2); path.lineTo(x, s) }
            path.close(); c.drawPath(path, p)
            p.textSize = 10 * d; c.drawText(label, if (right) x + s + 2 * d else x - s - 18 * d, 11 * d, p)
        }
        flag(markIn, 0xFF2ED573.toInt(), "IN", true); flag(markOut, 0xFFFF4D4F.toInt(), "OUT", false)
        // cursor
        val xc = xOf(cursor); p.color = 0xFFFFFFFF.toInt(); p.strokeWidth = 2 * d
        c.drawLine(xc, 0f, xc, height.toFloat() - 14 * d, p); c.drawCircle(xc, height * 0.42f, 5 * d, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        parent?.requestDisallowInterceptTouchEvent(true)
        if (e.actionMasked == MotionEvent.ACTION_DOWN || e.actionMasked == MotionEvent.ACTION_MOVE) {
            val fr = (vs + (e.x / width).toDouble().coerceIn(0.0, 1.0) * win()).toLong().coerceIn(0, total)
            onSeek?.invoke(fr)
        }
        return true
    }
}
