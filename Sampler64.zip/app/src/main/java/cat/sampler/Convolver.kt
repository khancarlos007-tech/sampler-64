package cat.sampler

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.IdentityHashMap
import kotlin.math.*

/** Resposta impulsional crua: 1 canal (mono), 2 (L/R en paral·lel) o 4 (estèreo veritable: LL, LR, RL, RR). */
class RawIr(val ch: Array<DoubleArray>, val rate: Int, val name: String)

object IrLoader {
    /** Llegeix Waves IR-1 (.wir, float32) o qualsevol WAV suportat per WavReader. */
    fun load(bytes: ByteArray, name: String): RawIr {
        val b = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        if (bytes.size > 44 && b.getInt(0) == 0x52497677) return waves(b, bytes.size, name)   // 'wvIR'
        val s = WavReader.read(bytes)
        return RawIr(if (s.r === s.l) arrayOf(s.l) else arrayOf(s.l, s.r), s.rate, name)
    }

    private fun waves(b: ByteBuffer, size: Int, name: String): RawIr {
        var p = 12; var ch = 1; var rate = 44100; var ds = -1; var dl = 0
        while (p + 8 <= size) {
            val id = b.getInt(p); val len = b.getInt(p + 4)
            if (id == 0x20746d66) { ch = b.getShort(p + 10).toInt(); rate = b.getInt(p + 12) }       // 'fmt '
            else if (id == 0x61746164) { ds = p + 8; dl = min(len, size - ds); break }                // 'data'
            if (len < 0) break
            p += 8 + len
        }
        require(ds >= 0 && ch in 1..8 && rate > 0) { "IR .wir no vàlida" }
        val fr = dl / (4 * ch)
        require(fr > 0) { "IR buida" }
        val out = Array(ch) { DoubleArray(fr) }
        for (f in 0 until fr) for (c in 0 until ch) {
            val v = b.getFloat(ds + (f * ch + c) * 4).toDouble()
            out[c][f] = if (v.isNaN() || v.isInfinite()) 0.0 else v
        }
        return RawIr(out, rate, name)
    }
}

/** Resampleig per sinc amb finestra de Hann (±16 mostres; filtra l'alias si es baixa la freqüència). */
object Resampler {
    fun run(x: DoubleArray, from: Int, to: Int): DoubleArray {
        if (from == to) return x
        val ratio = to.toDouble() / from
        val n = (x.size * ratio).toInt()
        val fc = min(1.0, ratio)
        val hw = 16.0 / fc
        val out = DoubleArray(n)
        for (i in 0 until n) {
            val t = i / ratio
            val lo = max(0, ceil(t - hw).toInt())
            val hi = min(x.size - 1, floor(t + hw).toInt())
            var s = 0.0
            for (j in lo..hi) {
                val d = t - j
                val a = PI * fc * d
                val sinc = if (abs(a) < 1e-12) 1.0 else sin(a) / a
                val w = 0.5 + 0.5 * cos(PI * d / hw)
                s += x[j] * fc * sinc * w
            }
            out[i] = s
        }
        return out
    }
}

class FFT(private val n: Int) {
    private val cosT = DoubleArray(n / 2) { cos(2 * PI * it / n) }
    private val sinT = DoubleArray(n / 2) { sin(2 * PI * it / n) }
    private val rev = IntArray(n)

    init {
        var bits = 0
        while ((1 shl bits) < n) bits++
        for (i in 0 until n) {
            var r = 0; var x = i
            for (b in 0 until bits) { r = (r shl 1) or (x and 1); x = x shr 1 }
            rev[i] = r
        }
    }

    fun transform(re: DoubleArray, im: DoubleArray, inverse: Boolean) {
        for (i in 0 until n) {
            val j = rev[i]
            if (j > i) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var len = 2
        while (len <= n) {
            val half = len / 2; val step = n / len
            var i = 0
            while (i < n) {
                var k = 0
                for (j in i until i + half) {
                    val wr = cosT[k]; val wi = if (inverse) sinT[k] else -sinT[k]
                    val xr = re[j + half] * wr - im[j + half] * wi
                    val xi = re[j + half] * wi + im[j + half] * wr
                    re[j + half] = re[j] - xr; im[j + half] = im[j] - xi
                    re[j] += xr; im[j] += xi
                    k += step
                }
                i += len
            }
            len = len shl 1
        }
        if (inverse) { val s = 1.0 / n; for (i in 0 until n) { re[i] *= s; im[i] *= s } }
    }
}

/**
 * Convolució per blocs uniformes (overlap-save, línia de retard d'espectres), tot en double.
 *
 * MULTINUCLI: el fil d'àudio només copia l'entrada, llegeix el bloc anterior i fa 2+2 FFT per bloc. La feina pesada
 * (multiplicar i acumular espectres: K particions x camins) es reparteix entre `nWorkers` fils (unitats w, w+nw, ...),
 * cadascun amb els seus acumuladors parcials. Aprofita el retard de 2 blocs: el resultat del bloc b es necessita al
 * límit del bloc b+2, de manera que els fils tenen un bloc sencer de temps per acabar.
 *  - En viu (`blocking = false`): si un fil no ha acabat a temps, aquell bloc de reverb queda en silenci (es compta a
 *    `misses`), però el fil d'àudio no s'atura mai ni es corromp res.
 *  - En render offline (`blocking = true`): s'espera sempre els fils, així el resultat és exacte.
 * Latència: 2 blocs (2P mostres). L'IR es normalitza per energia (L2) perquè el nivell humit sigui comparable al sec.
 */
class ConvInstance(raw: RawIr, sr: Int, private val P: Int = 512, nWorkers: Int = 2, private val blocking: Boolean = false) {
    private val N = 2 * P
    private val fft = FFT(N)

    private class Spec(val re: Array<DoubleArray>, val im: Array<DoubleArray>)
    private class Path(val i: Int, val o: Int, val s: Spec)

    private val paths = ArrayList<Path>()
    private val K: Int

    init {
        val maxLen = 8 * sr
        val irs = raw.ch.map { c ->
            val r = Resampler.run(c, raw.rate, sr)
            if (r.size > maxLen) r.copyOf(maxLen) else r
        }
        val map: List<Triple<Int, Int, DoubleArray>> = when {
            irs.size >= 4 -> listOf(Triple(0, 0, irs[0]), Triple(0, 1, irs[1]), Triple(1, 0, irs[2]), Triple(1, 1, irs[3]))
            irs.size == 2 -> listOf(Triple(0, 0, irs[0]), Triple(1, 1, irs[1]))
            else -> listOf(Triple(0, 0, irs[0]), Triple(1, 1, irs[0]))
        }
        val e = DoubleArray(2)
        for ((_, o, ir) in map) { var s = 0.0; for (v in ir) s += v * v; e[o] += s }
        val g = 1.0 / sqrt(max(max(e[0], e[1]), 1e-20))
        var maxIr = 1
        for (m in map) maxIr = max(maxIr, m.third.size)
        K = max(1, (maxIr + P - 1) / P)
        val cache = IdentityHashMap<DoubleArray, Spec>()
        for ((i, o, ir) in map) paths.add(Path(i, o, cache.getOrPut(ir) { spectra(ir, g) }))
    }

    private fun spectra(ir: DoubleArray, g: Double): Spec {
        val re = DoubleArray(N); val im = DoubleArray(N)
        val sr = Array(K) { DoubleArray(P + 1) }
        val si = Array(K) { DoubleArray(P + 1) }
        for (k in 0 until K) {
            re.fill(0.0); im.fill(0.0)
            for (i in 0 until P) { val idx = k * P + i; if (idx < ir.size) re[i] = ir[idx] * g }
            fft.transform(re, im, false)
            System.arraycopy(re, 0, sr[k], 0, P + 1)
            System.arraycopy(im, 0, si[k], 0, P + 1)
        }
        return Spec(sr, si)
    }

    private val nw = max(0, nWorkers)
    private val histRe = Array(2) { Array(K) { DoubleArray(P + 1) } }
    private val histIm = Array(2) { Array(K) { DoubleArray(P + 1) } }
    private val partRe = Array(max(1, nw)) { Array(2) { DoubleArray(P + 1) } }
    private val partIm = Array(max(1, nw)) { Array(2) { DoubleArray(P + 1) } }
    private val tr = DoubleArray(N)
    private val ti = DoubleArray(N)
    private val inB = arrayOf(DoubleArray(P), DoubleArray(P))
    private val prevB = arrayOf(DoubleArray(P), DoubleArray(P))
    private var outB = arrayOf(DoubleArray(P), DoubleArray(P))
    private var nextB = arrayOf(DoubleArray(P), DoubleArray(P))
    private var head = 0
    private var pos = 0
    private var job = false
    private val pending = java.util.concurrent.atomic.AtomicInteger(0)
    private val gos = Array(nw) { java.util.concurrent.Semaphore(0) }
    @Volatile private var alive = true
    @Volatile var misses = 0

    init {
        for (w in 0 until nw) Thread({ workerLoop(w) }, "conv-$w").apply { isDaemon = true; start() }
    }

    private fun workerLoop(w: Int) {
        try { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_AUDIO) } catch (_: Throwable) { }
        while (alive) {
            try { gos[w].acquire() } catch (_: InterruptedException) { break }
            if (!alive) break
            try { compute(w) } finally { pending.decrementAndGet() }
        }
    }

    fun close() { alive = false; pending.set(0); for (g in gos) g.release() }

    /** Suma la cua de reverb (retardada 2 blocs) al senyal sec, multiplicada per `mix`. */
    fun process(l: DoubleArray, r: DoubleArray, n: Int, mix: Double) {
        for (i in 0 until n) {
            inB[0][pos] = l[i]; inB[1][pos] = r[i]
            l[i] += outB[0][pos] * mix
            r[i] += outB[1][pos] * mix
            pos++
            if (pos == P) { boundary(); pos = 0 }
        }
    }

    /** Treball d'un fil: unitats (camí, partició) w, w+nw, w+2nw… acumulades als seus parcials. */
    private fun compute(w: Int) {
        val total = paths.size * K; val step = max(1, nw)
        for (o in 0..1) { partRe[w][o].fill(0.0); partIm[w][o].fill(0.0) }
        var u = w
        while (u < total) { val p = paths[u / K]; mac(p, u % K, partRe[w][p.o], partIm[w][p.o]); u += step }
    }

    private fun mac(p: Path, k: Int, ar: DoubleArray, ai: DoubleArray) {
        var slot = head - k
        if (slot < 0) slot += K
        val a = histRe[p.i][slot]; val b = histIm[p.i][slot]
        val c = p.s.re[k]; val d = p.s.im[k]
        for (j in 0..P) {
            ar[j] += a[j] * c[j] - b[j] * d[j]
            ai[j] += a[j] * d[j] + b[j] * c[j]
        }
    }

    private fun finish() {
        val nwe = max(1, nw)
        for (o in 0..1) {
            for (j in 0..P) {
                var a = 0.0; var b = 0.0
                for (w in 0 until nwe) { a += partRe[w][o][j]; b += partIm[w][o][j] }
                tr[j] = a; ti[j] = b
            }
            for (j in 1 until P) { tr[N - j] = tr[j]; ti[N - j] = -ti[j] }
            fft.transform(tr, ti, true)
            System.arraycopy(tr, P, nextB[o], 0, P)
        }
        val t = outB; outB = nextB; nextB = t
    }

    private fun boundary() {
        var ready = true
        if (job) {
            if (pending.get() != 0) {
                if (blocking) { while (pending.get() != 0 && alive) java.util.concurrent.locks.LockSupport.parkNanos(20_000L) }
                else { ready = false; misses++ }
            }
            if (ready) finish() else { outB[0].fill(0.0); outB[1].fill(0.0) }
        } else { outB[0].fill(0.0); outB[1].fill(0.0) }
        head = (head + 1) % K
        for (c in 0..1) {
            System.arraycopy(prevB[c], 0, tr, 0, P)
            System.arraycopy(inB[c], 0, tr, P, P)
            ti.fill(0.0)
            fft.transform(tr, ti, false)
            System.arraycopy(tr, 0, histRe[c][head], 0, P + 1)
            System.arraycopy(ti, 0, histIm[c][head], 0, P + 1)
            System.arraycopy(inB[c], 0, prevB[c], 0, P)
        }
        if (pending.get() == 0) {
            if (nw == 0) compute(0) else { pending.set(nw); for (g in gos) g.release() }
            job = true
        } else job = false                       // fils encara ocupats amb el treball anterior: no es despatxa
    }
}

/** Reverb de convolució al bus master (després de les pistes). */
class Reverb(private val sr: Int) {
    @Volatile var mix = 0.25
    @Volatile var enabled = true
    @Volatile var raw: RawIr? = null
    @Volatile var partition = 512        // 512 (21 ms), 1024 (43 ms) o 2048 (85 ms): més gran = menys CPU i més retard
    @Volatile var workers = 2            // fils de treball en viu
    @Volatile var blocking = false       // true als renders offline: espera sempre els fils (resultat exacte)
    @Volatile private var inst: ConvInstance? = null
    val misses: Int get() = inst?.misses ?: 0

    /** Costós (resampleig + FFT de l'IR): cridar fora del fil d'àudio. */
    fun load(r: RawIr) {
        val nw = if (blocking) max(1, min(4, Runtime.getRuntime().availableProcessors() - 1)) else workers
        val i = ConvInstance(r, sr, partition, nw, blocking)
        val old = inst
        raw = r
        inst = i
        old?.close()
    }

    fun reload() { raw?.let { load(it) } }
    fun close() { inst?.close(); inst = null }

    fun process(l: DoubleArray, r: DoubleArray, n: Int) {
        if (!enabled) return
        inst?.process(l, r, n, mix)
    }
}
