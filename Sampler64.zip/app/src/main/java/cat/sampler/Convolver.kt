package cat.sampler

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.IdentityHashMap
import kotlin.math.*

/** Resposta impulsional crua: 1 canal (mono), 2 (L/R en paral·lel) o 4 (estèreo veritable: LL, LR, RL, RR). */
class RawIr(val ch: Array<DoubleArray>, val rate: Int, val name: String)

object IrLoader {
    /** Llegeix Waves IR-1 (.wir, float32) o qualsevol WAV suportat per WavReader. */
    fun load(bytes: ByteArray, name: String): RawIr {
        val b = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        if (bytes.size > 44 && b.getInt(0) == 0x52497677) return waves(b, bytes.size, name)   // 'wvIR'
        val s = WavReader.read(bytes)
        return RawIr(if (s.r === s.l) arrayOf(s.l) else arrayOf(s.l, s.r), s.rate, name)
    }

    private fun waves(b: ByteBuffer, size: Int, name: String): RawIr {
        var p = 12; var ch = 1; var rate = 44100; var ds = -1; var dl = 0
        while (p + 8 <= size) {
            val id = b.getInt(p); val len = b.getInt(p + 4)
            if (id == 0x20746d66) { ch = b.getShort(p + 10).toInt(); rate = b.getInt(p + 12) }       // 'fmt '
            else if (id == 0x61746164) { ds = p + 8; dl = min(len, size - ds); break }                // 'data'
            if (len < 0) break
            p += 8 + len
        }
        require(ds >= 0 && ch in 1..8 && rate > 0) { "IR .wir no vàlida" }
        val fr = dl / (4 * ch)
        require(fr > 0) { "IR buida" }
        val out = Array(ch) { DoubleArray(fr) }
        for (f in 0 until fr) for (c in 0 until ch) {
            val v = b.getFloat(ds + (f * ch + c) * 4).toDouble()
            out[c][f] = if (v.isNaN() || v.isInfinite()) 0.0 else v
        }
        return RawIr(out, rate, name)
    }
}

/** Resampleig per sinc amb finestra de Hann (±16 mostres; filtra l'alias si es baixa la freqüència). */
object Resampler {
    fun run(x: DoubleArray, from: Int, to: Int): DoubleArray {
        if (from == to) return x
        val ratio = to.toDouble() / from
        val n = (x.size * ratio).toInt()
        val fc = min(1.0, ratio)
        val hw = 16.0 / fc
        val out = DoubleArray(n)
        for (i in 0 until n) {
            val t = i / ratio
            val lo = max(0, ceil(t - hw).toInt())
            val hi = min(x.size - 1, floor(t + hw).toInt())
            var s = 0.0
            for (j in lo..hi) {
                val d = t - j
                val a = PI * fc * d
                val sinc = if (abs(a) < 1e-12) 1.0 else sin(a) / a
                val w = 0.5 + 0.5 * cos(PI * d / hw)
                s += x[j] * fc * sinc * w
            }
            out[i] = s
        }
        return out
    }
}

class FFT(private val n: Int) {
    private val cosT = DoubleArray(n / 2) { cos(2 * PI * it / n) }
    private val sinT = DoubleArray(n / 2) { sin(2 * PI * it / n) }
    private val rev = IntArray(n)

    init {
        var bits = 0
        while ((1 shl bits) < n) bits++
        for (i in 0 until n) {
            var r = 0; var x = i
            for (b in 0 until bits) { r = (r shl 1) or (x and 1); x = x shr 1 }
            rev[i] = r
        }
    }

    fun transform(re: DoubleArray, im: DoubleArray, inverse: Boolean) {
        for (i in 0 until n) {
            val j = rev[i]
            if (j > i) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var len = 2
        while (len <= n) {
            val half = len / 2; val step = n / len
            var i = 0
            while (i < n) {
                var k = 0
                for (j in i until i + half) {
                    val wr = cosT[k]; val wi = if (inverse) sinT[k] else -sinT[k]
                    val xr = re[j + half] * wr - im[j + half] * wi
                    val xi = re[j + half] * wi + im[j + half] * wr
                    re[j + half] = re[j] - xr; im[j + half] = im[j] - xi
                    re[j] += xr; im[j] += xi
                    k += step
                }
                i += len
            }
            len = len shl 1
        }
        if (inverse) { val s = 1.0 / n; for (i in 0 until n) { re[i] *= s; im[i] *= s } }
    }
}

/**
 * Convolució per blocs uniformes (overlap-save, línia de retard de espectres), tot en double.
 * La feina de cada bloc es reparteix en 16 llesques perquè la càrrega de CPU sigui constant
 * i no hi hagi pics al fil d'àudio. Latència: 2 blocs (1024 mostres).
 * L'IR es normalitza per energia (L2) perquè el nivell humit sigui comparable al sec.
 */
class ConvInstance(raw: RawIr, sr: Int) {
    private val P = 512
    private val N = 2 * P
    private val SL = 16
    private val SLEN = P / SL
    private val fft = FFT(N)

    private class Spec(val re: Array<DoubleArray>, val im: Array<DoubleArray>)
    private class Path(val i: Int, val o: Int, val s: Spec)

    private val paths = ArrayList<Path>()
    private val K: Int

    init {
        val maxLen = 8 * sr
        val irs = raw.ch.map { c ->
            val r = Resampler.run(c, raw.rate, sr)
            if (r.size > maxLen) r.copyOf(maxLen) else r
        }
        val map: List<Triple<Int, Int, DoubleArray>> = when {
            irs.size >= 4 -> listOf(Triple(0, 0, irs[0]), Triple(0, 1, irs[1]), Triple(1, 0, irs[2]), Triple(1, 1, irs[3]))
            irs.size == 2 -> listOf(Triple(0, 0, irs[0]), Triple(1, 1, irs[1]))
            else -> listOf(Triple(0, 0, irs[0]), Triple(1, 1, irs[0]))
        }
        val e = DoubleArray(2)
        for ((_, o, ir) in map) { var s = 0.0; for (v in ir) s += v * v; e[o] += s }
        val g = 1.0 / sqrt(max(max(e[0], e[1]), 1e-20))
        var maxIr = 1
        for (m in map) maxIr = max(maxIr, m.third.size)
        K = max(1, (maxIr + P - 1) / P)
        val cache = IdentityHashMap<DoubleArray, Spec>()
        for ((i, o, ir) in map) paths.add(Path(i, o, cache.getOrPut(ir) { spectra(ir, g) }))
    }

    private fun spectra(ir: DoubleArray, g: Double): Spec {
        val re = DoubleArray(N); val im = DoubleArray(N)
        val sr = Array(K) { DoubleArray(P + 1) }
        val si = Array(K) { DoubleArray(P + 1) }
        for (k in 0 until K) {
            re.fill(0.0); im.fill(0.0)
            for (i in 0 until P) { val idx = k * P + i; if (idx < ir.size) re[i] = ir[idx] * g }
            fft.transform(re, im, false)
            System.arraycopy(re, 0, sr[k], 0, P + 1)
            System.arraycopy(im, 0, si[k], 0, P + 1)
        }
        return Spec(sr, si)
    }

    private val histRe = Array(2) { Array(K) { DoubleArray(P + 1) } }
    private val histIm = Array(2) { Array(K) { DoubleArray(P + 1) } }
    private val accRe = Array(2) { DoubleArray(P + 1) }
    private val accIm = Array(2) { DoubleArray(P + 1) }
    private val tr = DoubleArray(N)
    private val ti = DoubleArray(N)
    private val inB = arrayOf(DoubleArray(P), DoubleArray(P))
    private val prevB = arrayOf(DoubleArray(P), DoubleArray(P))
    private var outB = arrayOf(DoubleArray(P), DoubleArray(P))
    private var nextB = arrayOf(DoubleArray(P), DoubleArray(P))
    private var head = 0
    private var pos = 0
    private var sl = 0
    private var job = false

    /** Suma la cua de reverb (retardada 2 blocs) al senyal sec, multiplicada per `mix`. */
    fun process(l: DoubleArray, r: DoubleArray, n: Int, mix: Double) {
        for (i in 0 until n) {
            if (job && sl < SL && (pos and (SLEN - 1)) == 0) slice()
            inB[0][pos] = l[i]; inB[1][pos] = r[i]
            l[i] += outB[0][pos] * mix
            r[i] += outB[1][pos] * mix
            pos++
            if (pos == P) { boundary(); pos = 0 }
        }
    }

    private fun slice() {
        val total = paths.size * K
        val per = (total + SL - 1) / SL
        val u0 = sl * per
        val u1 = min(total, u0 + per)
        for (u in u0 until u1) mac(paths[u / K], u % K)
        sl++
    }

    private fun mac(p: Path, k: Int) {
        var slot = head - k
        if (slot < 0) slot += K
        val a = histRe[p.i][slot]; val b = histIm[p.i][slot]
        val c = p.s.re[k]; val d = p.s.im[k]
        val ar = accRe[p.o]; val ai = accIm[p.o]
        for (j in 0..P) {
            ar[j] += a[j] * c[j] - b[j] * d[j]
            ai[j] += a[j] * d[j] + b[j] * c[j]
        }
    }

    private fun boundary() {
        if (job) {
            while (sl < SL) slice()
            for (o in 0..1) {
                for (j in 0..P) { tr[j] = accRe[o][j]; ti[j] = accIm[o][j] }
                for (j in 1 until P) { tr[N - j] = accRe[o][j]; ti[N - j] = -accIm[o][j] }
                fft.transform(tr, ti, true)
                System.arraycopy(tr, P, nextB[o], 0, P)
            }
            val t = outB; outB = nextB; nextB = t
        }
        head = (head + 1) % K
        for (c in 0..1) {
            System.arraycopy(prevB[c], 0, tr, 0, P)
            System.arraycopy(inB[c], 0, tr, P, P)
            ti.fill(0.0)
            fft.transform(tr, ti, false)
            System.arraycopy(tr, 0, histRe[c][head], 0, P + 1)
            System.arraycopy(ti, 0, histIm[c][head], 0, P + 1)
            System.arraycopy(inB[c], 0, prevB[c], 0, P)
        }
        for (o in 0..1) { accRe[o].fill(0.0); accIm[o].fill(0.0) }
        sl = 0
        job = true
    }
}

/** Reverb de convolució al bus master (abans del compressor). */
class Reverb(private val sr: Int) {
    @Volatile var mix = 0.25
    @Volatile var enabled = true
    @Volatile var raw: RawIr? = null
    @Volatile private var inst: ConvInstance? = null

    /** Costós (resampleig + FFT de l'IR): cridar fora del fil d'àudio. */
    fun load(r: RawIr) {
        val i = ConvInstance(r, sr)
        raw = r
        inst = i
    }

    fun process(l: DoubleArray, r: DoubleArray, n: Int) {
        if (!enabled) return
        inst?.process(l, r, n, mix)
    }
}
